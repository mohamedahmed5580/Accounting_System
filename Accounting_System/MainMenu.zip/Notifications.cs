﻿using Microsoft.Win32;
using Pharmacy.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static DevExpress.Data.Helpers.ExpressiveSortInfo;
using System.Xml.Linq;
namespace Accounting_System
{
    public partial class Notifications : Form
    {
        public static Notifications instance;
        public static TimeZoneInfo egyptTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Egypt Standard Time");
        public static DateTime egyptTime = TimeZoneInfo.ConvertTime(DateTime.Now, egyptTimeZone);

        public Notifications()
        {
            InitializeComponent();
            instance = this;
        }
        private void GetNotifications()
        {
            using (SqlConnection con = new SqlConnection(DataAccessLayer.Con()))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand("SELECT id, Name,Hours,Minutes,Timing, Date FROM Notifications", con))
                {
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        dgw.Rows.Clear(); // Clear any existing rows in the DataGridView

                        while (rdr.Read())
                        {
                            // Add rows to the DataGridView with the retrieved data
                            dgw.Rows.Add(
                                rdr["id"].ToString(),         // First column: ID
                                rdr["Name"].ToString(),       // Second column: Name
                                rdr["Hours"].ToString(),       // Third  column: hours
                                rdr["Minutes"].ToString(),       // Third  column: hours
                                rdr["Timing"].ToString(),       // Third  column: hours
                                Convert.ToDateTime(rdr["Date"]).ToString("yyyy-MM-dd") // Fours column: Date (formatted)
                            );
                        }
                    }
                }
            }
            comboBox1.Text = egyptTime.ToString("tt");
        }
        // Set up the timer to check for notifications every minute
       
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Step 1: Insert the data into the DataGridView
            // dgw.Rows.Add(txtCompanyName.Text, dateTimePicker1.Value.ToString());

            try
            {
                using (SqlConnection con = new SqlConnection(DataAccessLayer.Con()))
                {
                    con.Open();


                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Notifications (Name, Hours,Minutes,Timing, Date) VALUES (@Name, @Hours,@Minutes,@Timing, @Date)", con))
                    {
                        // Insert values from the DataGridView row
                        cmd.Parameters.AddWithValue("@Name", txtCompanyName.Text); // Name from the first cell

                        // Ensure Hours is a valid integer
                        int hours;
                        if (int.TryParse(textBox1.Text, out hours))
                        {
                            cmd.Parameters.AddWithValue("@Hours", hours); // Valid integer value
                        }
                        else
                        {
                            MessageBox.Show("Invalid value for Hours. Please enter a valid number.");
                            return;
                        }
                        int Minutes;
                        if (int.TryParse(textBox2.Text, out Minutes))
                        {
                            cmd.Parameters.AddWithValue("@Minutes", Minutes); // Valid integer value
                        }
                        else
                        {
                            MessageBox.Show("Invalid value for Hours. Please enter a valid number.");
                            return;
                        }
                        try
                        {
                            cmd.Parameters.AddWithValue("@Timing", comboBox1.SelectedItem); // Valid integer value

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("خطأ في اختيار التوقيت");

                        }

                        // Ensure the Date is handled properly
                        DateTime dateValue;
                        if (DateTime.TryParse(dateTimePicker1.Text.ToString(), out dateValue))
                        {
                            cmd.Parameters.AddWithValue("@Date", dateValue); // Valid date value
                        }
                        else
                        {
                            MessageBox.Show("Invalid date format.");
                            return;
                        }

                        // Execute the query
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("تم حفظ التاريخ بنجاح");

                    }
                }

            }
            catch
            {
                MessageBox.Show("Invalid date format.");

            }
            // Step 2: Insert the data into the database
            GetNotifications();

        }


        private void Notifications_Load(object sender, EventArgs e)
        {

            GetNotifications();
            notificationTimer.Start();
            notificationTimer.Tick += notificationTimer_Tick;

        }
        private void notificationTimer_Tick(object sender, EventArgs e)
        {
            CheckForNotifications();
        }
        private void CheckForNotifications()
        {

            //label11.Text= int.Parse(egyptTime.ToString("mm")).ToString();
            using (SqlConnection con = new SqlConnection(DataAccessLayer.Con()))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand("SELECT Name,Hours,Minutes,Timing,Date FROM Notifications ORDER BY id DESC", con))
                {
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            string notificationName = rdr["Name"].ToString();
                            string notificationHours = rdr["Hours"].ToString(); // Assuming the format is 'HH:mm'
                            string notificationMinutes = rdr["Minutes"].ToString(); // Assuming the format is 'HH:mm'
                            string notificationTiming = (rdr["Timing"]).ToString(); // Assuming the format is 'HH:mm'
                            string notificationdate = Convert.ToDateTime(rdr["Date"]).ToString("yyyy-MM-dd"); // Assuming the format is 'HH:mm'
                            DateTime egyptTime = TimeZoneInfo.ConvertTime(DateTime.Now, egyptTimeZone);
                            label9.Text = ((int.Parse(egyptTime.ToString("HH"))-12).ToString()).ToString();
                            label11.Text = ((int.Parse(egyptTime.ToString("mm"))).ToString() == notificationMinutes.ToString()).ToString();
                            label12.Text = egyptTime.ToString();

                            // Check if the current time matches the notification time
                            if (int.Parse(egyptTime.ToString("HH"))>=12)
                            {
                                if ((int.Parse(egyptTime.ToString("HH")) - 12).ToString() == notificationHours && (int.Parse(egyptTime.ToString("mm"))).ToString() == notificationMinutes.ToString() && egyptTime.ToString("tt") == notificationTiming && egyptTime.ToString("yyyy-MM-dd") == notificationdate)
                                {
                                    // Show the notification    
                                    ShowNotification("تذكير", $"الاشعار: {notificationName}");
                                }
                            }
                            else
                            {
                                 if (int.Parse(egyptTime.ToString("HH")).ToString() == notificationHours && (int.Parse(egyptTime.ToString("mm"))).ToString() == notificationMinutes.ToString() && egyptTime.ToString("tt") == notificationTiming && egyptTime.ToString("yyyy-MM-dd") == notificationdate)
                                 {
                                    // Show the notification    
                                    ShowNotification("تذكير", $"الاشعار: {notificationName}");
                                 }
                            }

                        }
                    }
                }
            }
        

    }

        private void ShowNotification(string title, string message)
        {
            // Display a balloon tip notification
            notifyIcon1.BalloonTipTitle = title;
            notifyIcon1.BalloonTipText = message;
            notifyIcon1.BalloonTipIcon = ToolTipIcon.Info; // You can set it to Info, Warning, or Error
            notifyIcon1.ShowBalloonTip(10000); // Display for 3 seconds
            notificationTimer.Stop();


        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateNotification();
        }
        private void UpdateNotification()
        {
            using (SqlConnection con = new SqlConnection(DataAccessLayer.Con()))
            {
                con.Open();


                using (SqlCommand cmd = new SqlCommand("UPDATE Notifications SET Name = @Name,Hours=@Hours,Minutes=@Minutes,Timing=@Timing, Date = @Date WHERE id = @id", con))
                {
                    // Assuming id is in the first column (Cells[0]) and needs to be updated
                    cmd.Parameters.AddWithValue("@id", txtID.Text); // ID of the record
                    cmd.Parameters.AddWithValue("@Name", txtCompanyName.Text.ToString()); // Name from the second cell
                    cmd.Parameters.AddWithValue("@Hours", textBox1.Text); // Name from the second cell
                    cmd.Parameters.AddWithValue("@Minutes", textBox2.Text); // name from the second cell
                    cmd.Parameters.AddWithValue("@Timing", comboBox1.Text.ToString()); // Name from the second cell
                    cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(dateTimePicker1.Value)); // Date from the third cell

                    // Execute the query
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("تمت عملية التعديل بنجاح");

                }

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteNotification();
        }
        private void DeleteNotification()
        {
            if (dgw.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dgw.SelectedRows[0];

                // Get the id from the first column (assuming the id is stored there)
                int id = Convert.ToInt32(selectedRow.Cells[0].Value);

                using (SqlConnection con = new SqlConnection(DataAccessLayer.Con()))
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Notifications WHERE id = @id", con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        // Execute the query
                        cmd.ExecuteNonQuery();
                    }
                }

                // Remove the row from DataGridView
                dgw.Rows.Remove(selectedRow);
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtCompanyName.Text = "";
            textBox1.Text = "";
            dateTimePicker1.ResetText();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ShowNotification(textBox1.Text, txtCompanyName.Text);
/*            AddApplicationToStartup();
*/      }

        public static void AddApplicationToStartup()
        {
            string appName = "URTECH";
            string appPath = Application.ExecutablePath; // Path of the running application

            RegistryKey rk = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            if (rk.GetValue(appName) == null)
            {
                rk.SetValue(appName, appPath);
            }
        }

        public static void RemoveApplicationFromStartup()
        {
            string appName = "URTECH";

            RegistryKey rk = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            if (rk.GetValue(appName) != null)
            {
                rk.DeleteValue(appName);
            }
        }

        private void dgw_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
  

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check if the key pressed is not a control key (like backspace) and is not a digit
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // If it's not a number, ignore the input
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void label9_Click(object sender, EventArgs e)
        {
           
        }

        private void label11_Click(object sender, EventArgs e)
        {
            //label11.Text= int.Parse(egyptTime.ToString("mm")).ToString();
           
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Notifications_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*Notifications notifn = null; // Initialize notifn to null
            if (notifn == null || notifn.IsDisposed)
            {
                notifn = new Notifications(); // Create a new instance and assign it to notifn
                notifn.Show();
                notifn.Hide(); // Hide the form to keep it in the background
            }
            else
            {
                notifn.Show(); // If the form is already open, just show it
            }
*/


        }

        private void Notifications_Move(object sender, EventArgs e)
        {
            if (this.WindowState==FormWindowState.Minimized)
            {
                this.Hide();
            }
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Notifications_FormClosed(object sender, FormClosedEventArgs e)
        {
            


        }

        private void dgw_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (dgw.Rows.Count > 0)
                {
                    DataGridViewRow dr = dgw.SelectedRows[0];
                    txtID.Text = dr.Cells[0].Value.ToString();
                    txtCompanyName.Text = dr.Cells[1].Value.ToString();
                    textBox1.Text = dr.Cells[2].Value.ToString();
                    textBox2.Text = dr.Cells[3].Value.ToString();
                    comboBox1.Text = dr.Cells[4].Value.ToString();
                    dateTimePicker1.Value =Convert.ToDateTime( dr.Cells[5].Value);
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    btnSave.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
            }
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gunaImageButton1_Click(object sender, EventArgs e)
        {
            this.Hide();

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
