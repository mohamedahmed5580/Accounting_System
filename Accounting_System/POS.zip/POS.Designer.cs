﻿namespace Accounting_System
{
    partial class POS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label Label5;
            System.Windows.Forms.Label Label6;
            System.Windows.Forms.Label Label49;
            System.Windows.Forms.Label Label51;
            System.Windows.Forms.Label Label25;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle163 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle164 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle167 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle168 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle169 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle165 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle166 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle170 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle171 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle177 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle178 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle179 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle180 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle195 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle196 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle197 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle181 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle182 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle183 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle184 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle185 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle186 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle187 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle188 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle189 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle190 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle191 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle192 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle193 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle194 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle198 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle199 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle214 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle215 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle216 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle200 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle201 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle202 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle203 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle204 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle205 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle206 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle207 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle208 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle209 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle210 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle211 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle212 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle213 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POS));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle172 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle173 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle174 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle175 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle176 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Timer2 = new System.Windows.Forms.Timer(this.components);
            this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.txtCostPrice = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.txtMargin = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnMaximise = new System.Windows.Forms.Button();
            this.btnKeyboard = new System.Windows.Forms.Button();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtInvoiceNo = new System.Windows.Forms.TextBox();
            this.txtSalesman = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtVATAmount = new System.Windows.Forms.TextBox();
            this.txtDiscountAmount = new System.Windows.Forms.TextBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtSellingPrice = new System.Windows.Forms.TextBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.Label23 = new System.Windows.Forms.Label();
            this.txtDiscountPer = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.txtVAT = new System.Windows.Forms.TextBox();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.txtGrandTotal = new System.Windows.Forms.TextBox();
            this.Label31 = new System.Windows.Forms.Label();
            this.txtPaymentDue = new System.Windows.Forms.TextBox();
            this.txtTotalPayment = new System.Windows.Forms.TextBox();
            this.Label34 = new System.Windows.Forms.Label();
            this.Label35 = new System.Windows.Forms.Label();
            this.txtCommissionPer = new System.Windows.Forms.TextBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCheck = new System.Windows.Forms.TextBox();
            this.btnListReset1 = new System.Windows.Forms.Button();
            this.dtpPaymentDate = new System.Windows.Forms.DateTimePicker();
            this.btnListUpdate1 = new System.Windows.Forms.Button();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.cmbPaymentMode = new System.Windows.Forms.ComboBox();
            this.btnRemove1 = new System.Windows.Forms.Button();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.DataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSalesmanID = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.lblUser1 = new System.Windows.Forms.Label();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.lblUserType = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtCID = new System.Windows.Forms.TextBox();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.txtCustomerType = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtTotalQty = new System.Windows.Forms.TextBox();
            this.txtSM_ID = new System.Windows.Forms.TextBox();
            this.lblSet = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.dgw = new System.Windows.Forms.DataGridView();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btnListReset = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSelectionInv = new System.Windows.Forms.Button();
            this.btnListUpdate = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnGetData = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnScanItems = new System.Windows.Forms.Button();
            this.Plimit = new System.Windows.Forms.TextBox();
            this.DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Label5 = new System.Windows.Forms.Label();
            Label6 = new System.Windows.Forms.Label();
            Label49 = new System.Windows.Forms.Label();
            Label51 = new System.Windows.Forms.Label();
            Label25 = new System.Windows.Forms.Label();
            this.GroupBox4.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.Panel4.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).BeginInit();
            this.Panel2.SuspendLayout();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // Label5
            // 
            Label5.BackColor = System.Drawing.Color.DarkSlateGray;
            Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            Label5.ForeColor = System.Drawing.Color.White;
            Label5.Location = new System.Drawing.Point(528, 27);
            Label5.Name = "Label5";
            Label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            Label5.Size = new System.Drawing.Size(93, 27);
            Label5.TabIndex = 268;
            Label5.Text = "رقم الفاتورة :";
            Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label6
            // 
            Label6.BackColor = System.Drawing.Color.DarkSlateGray;
            Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            Label6.ForeColor = System.Drawing.Color.White;
            Label6.Location = new System.Drawing.Point(591, 25);
            Label6.Name = "Label6";
            Label6.Size = new System.Drawing.Size(88, 26);
            Label6.TabIndex = 312;
            Label6.Text = "الضرائب%";
            Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label49
            // 
            Label49.BackColor = System.Drawing.Color.DarkSlateGray;
            Label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            Label49.ForeColor = System.Drawing.Color.White;
            Label49.Location = new System.Drawing.Point(791, 23);
            Label49.Name = "Label49";
            Label49.Size = new System.Drawing.Size(84, 26);
            Label49.TabIndex = 314;
            Label49.Text = "المجموع ";
            Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label51
            // 
            Label51.BackColor = System.Drawing.Color.DarkSlateGray;
            Label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            Label51.ForeColor = System.Drawing.Color.White;
            Label51.Location = new System.Drawing.Point(725, 23);
            Label51.Name = "Label51";
            Label51.Size = new System.Drawing.Size(67, 26);
            Label51.TabIndex = 319;
            Label51.Text = "الخصم%";
            Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label25
            // 
            Label25.BackColor = System.Drawing.Color.DarkSlateGray;
            Label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            Label25.ForeColor = System.Drawing.Color.White;
            Label25.Location = new System.Drawing.Point(423, 25);
            Label25.Name = "Label25";
            Label25.Size = new System.Drawing.Size(109, 26);
            Label25.TabIndex = 326;
            Label25.Text = "إجمالي المبلغ";
            Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Timer2
            // 
            this.Timer2.Enabled = true;
            this.Timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // ToolTip1
            // 
            this.ToolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.ToolTip1_Popup);
            // 
            // Timer1
            // 
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick_1);
            // 
            // TextBox1
            // 
            this.TextBox1.Font = new System.Drawing.Font("Tahoma", 9F);
            this.TextBox1.Location = new System.Drawing.Point(915, 25);
            this.TextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(80, 26);
            this.TextBox1.TabIndex = 410;
            this.TextBox1.Visible = false;
            // 
            // txtCostPrice
            // 
            this.txtCostPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostPrice.Location = new System.Drawing.Point(701, 0);
            this.txtCostPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCostPrice.Name = "txtCostPrice";
            this.txtCostPrice.ReadOnly = true;
            this.txtCostPrice.Size = new System.Drawing.Size(84, 23);
            this.txtCostPrice.TabIndex = 2;
            this.txtCostPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCostPrice.Visible = false;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(803, 4);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(31, 17);
            this.Label10.TabIndex = 96;
            this.Label10.Text = "وحدة";
            this.Label10.Visible = false;
            // 
            // txtMargin
            // 
            this.txtMargin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMargin.Location = new System.Drawing.Point(744, 0);
            this.txtMargin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMargin.Name = "txtMargin";
            this.txtMargin.ReadOnly = true;
            this.txtMargin.Size = new System.Drawing.Size(84, 23);
            this.txtMargin.TabIndex = 4;
            this.txtMargin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMargin.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(880, 42);
            this.btnClose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(35, 34);
            this.btnClose.TabIndex = 402;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Visible = false;
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnMinimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimize.Location = new System.Drawing.Point(808, 42);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(35, 34);
            this.btnMinimize.TabIndex = 403;
            this.btnMinimize.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Visible = false;
            // 
            // btnMaximise
            // 
            this.btnMaximise.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximise.BackColor = System.Drawing.Color.Transparent;
            this.btnMaximise.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnMaximise.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnMaximise.FlatAppearance.BorderSize = 0;
            this.btnMaximise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximise.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaximise.Location = new System.Drawing.Point(844, 42);
            this.btnMaximise.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMaximise.Name = "btnMaximise";
            this.btnMaximise.Size = new System.Drawing.Size(35, 34);
            this.btnMaximise.TabIndex = 404;
            this.btnMaximise.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMaximise.UseVisualStyleBackColor = false;
            this.btnMaximise.Visible = false;
            // 
            // btnKeyboard
            // 
            this.btnKeyboard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKeyboard.BackColor = System.Drawing.Color.Transparent;
            this.btnKeyboard.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnKeyboard.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnKeyboard.FlatAppearance.BorderSize = 0;
            this.btnKeyboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKeyboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKeyboard.Location = new System.Drawing.Point(775, 42);
            this.btnKeyboard.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnKeyboard.Name = "btnKeyboard";
            this.btnKeyboard.Size = new System.Drawing.Size(35, 34);
            this.btnKeyboard.TabIndex = 405;
            this.btnKeyboard.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnKeyboard.UseVisualStyleBackColor = false;
            this.btnKeyboard.Visible = false;
            // 
            // GroupBox4
            // 
            this.GroupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox4.BackColor = System.Drawing.Color.White;
            this.GroupBox4.Controls.Add(this.Plimit);
            this.GroupBox4.Controls.Add(this.button5);
            this.GroupBox4.Controls.Add(this.TextBox2);
            this.GroupBox4.Controls.Add(this.Button1);
            this.GroupBox4.Controls.Add(this.dtpInvoiceDate);
            this.GroupBox4.Controls.Add(this.Label2);
            this.GroupBox4.Controls.Add(this.txtInvoiceNo);
            this.GroupBox4.Controls.Add(this.txtSalesman);
            this.GroupBox4.Controls.Add(this.Label4);
            this.GroupBox4.Controls.Add(this.Label15);
            this.GroupBox4.Controls.Add(this.btnSelect);
            this.GroupBox4.Controls.Add(Label5);
            this.GroupBox4.Controls.Add(this.txtCustomerName);
            this.GroupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.GroupBox4.Location = new System.Drawing.Point(927, 7);
            this.GroupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.GroupBox4.Size = new System.Drawing.Size(669, 98);
            this.GroupBox4.TabIndex = 0;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "معلومات الفاتورة :";
            // 
            // TextBox2
            // 
            this.TextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.TextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBox2.BackColor = System.Drawing.Color.Honeydew;
            this.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TextBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.TextBox2.Location = new System.Drawing.Point(147, -20);
            this.TextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(181, 30);
            this.TextBox2.TabIndex = 331;
            this.TextBox2.Visible = false;
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.CustomFormat = "dd/MM/yyyy";
            this.dtpInvoiceDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(357, 58);
            this.dtpInvoiceDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(165, 30);
            this.dtpInvoiceDate.TabIndex = 1;
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(257, 27);
            this.Label2.Name = "Label2";
            this.Label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label2.Size = new System.Drawing.Size(95, 27);
            this.Label2.TabIndex = 7;
            this.Label2.Text = "اسم العميل :";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtInvoiceNo.Location = new System.Drawing.Point(357, 27);
            this.txtInvoiceNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.ReadOnly = true;
            this.txtInvoiceNo.Size = new System.Drawing.Size(165, 30);
            this.txtInvoiceNo.TabIndex = 0;
            // 
            // txtSalesman
            // 
            this.txtSalesman.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtSalesman.Location = new System.Drawing.Point(119, 57);
            this.txtSalesman.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSalesman.Name = "txtSalesman";
            this.txtSalesman.ReadOnly = true;
            this.txtSalesman.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSalesman.Size = new System.Drawing.Size(133, 30);
            this.txtSalesman.TabIndex = 4;
            // 
            // Label4
            // 
            this.Label4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label4.ForeColor = System.Drawing.Color.White;
            this.Label4.Location = new System.Drawing.Point(528, 58);
            this.Label4.Name = "Label4";
            this.Label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label4.Size = new System.Drawing.Size(93, 27);
            this.Label4.TabIndex = 335;
            this.Label4.Text = "تاريخ الفاتورة :";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label15
            // 
            this.Label15.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label15.ForeColor = System.Drawing.Color.White;
            this.Label15.Location = new System.Drawing.Point(257, 58);
            this.Label15.Name = "Label15";
            this.Label15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label15.Size = new System.Drawing.Size(95, 25);
            this.Label15.TabIndex = 337;
            this.Label15.Text = "البائع :";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtCustomerName.Location = new System.Drawing.Point(119, 27);
            this.txtCustomerName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.ReadOnly = true;
            this.txtCustomerName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtCustomerName.Size = new System.Drawing.Size(133, 30);
            this.txtCustomerName.TabIndex = 1;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.txtCustomerName_TextChanged);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox3.BackColor = System.Drawing.Color.White;
            this.GroupBox3.Controls.Add(this.button7);
            this.GroupBox3.Controls.Add(this.button4);
            this.GroupBox3.Controls.Add(this.ComboBox1);
            this.GroupBox3.Controls.Add(this.txtContactNo);
            this.GroupBox3.Controls.Add(this.btnGetData);
            this.GroupBox3.Controls.Add(this.btnUpdate);
            this.GroupBox3.Controls.Add(this.btnDelete);
            this.GroupBox3.Controls.Add(this.Button3);
            this.GroupBox3.Controls.Add(this.Button2);
            this.GroupBox3.Controls.Add(this.Label8);
            this.GroupBox3.Controls.Add(this.btnNew);
            this.GroupBox3.Controls.Add(this.btnSave);
            this.GroupBox3.Controls.Add(this.txtRemarks);
            this.GroupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.GroupBox3.Location = new System.Drawing.Point(99, 7);
            this.GroupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.GroupBox3.Size = new System.Drawing.Size(821, 103);
            this.GroupBox3.TabIndex = 1;
            this.GroupBox3.TabStop = false;
            // 
            // ComboBox1
            // 
            this.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Items.AddRange(new object[] {
            "تجزءة",
            "جملة"});
            this.ComboBox1.Location = new System.Drawing.Point(560, 62);
            this.ComboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(241, 28);
            this.ComboBox1.TabIndex = 408;
            // 
            // txtContactNo
            // 
            this.txtContactNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtContactNo.Location = new System.Drawing.Point(-3, -18);
            this.txtContactNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.ReadOnly = true;
            this.txtContactNo.Size = new System.Drawing.Size(181, 30);
            this.txtContactNo.TabIndex = 2;
            this.txtContactNo.Visible = false;
            // 
            // Label8
            // 
            this.Label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Label8.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(696, 25);
            this.Label8.Name = "Label8";
            this.Label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label8.Size = new System.Drawing.Size(103, 35);
            this.Label8.TabIndex = 85;
            this.Label8.Text = "رقم الفاتورة اليدوية :";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtRemarks
            // 
            this.txtRemarks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtRemarks.BackColor = System.Drawing.Color.White;
            this.txtRemarks.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(561, 26);
            this.txtRemarks.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtRemarks.Size = new System.Drawing.Size(129, 35);
            this.txtRemarks.TabIndex = 6;
            // 
            // GroupBox5
            // 
            this.GroupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox5.BackColor = System.Drawing.Color.White;
            this.GroupBox5.Controls.Add(this.txtBarcode);
            this.GroupBox5.Controls.Add(this.button6);
            this.GroupBox5.Controls.Add(this.txtTotalAmount);
            this.GroupBox5.Controls.Add(this.txtQty);
            this.GroupBox5.Controls.Add(this.txtProductName);
            this.GroupBox5.Controls.Add(this.txtVATAmount);
            this.GroupBox5.Controls.Add(this.txtDiscountAmount);
            this.GroupBox5.Controls.Add(this.txtAmount);
            this.GroupBox5.Controls.Add(this.txtSellingPrice);
            this.GroupBox5.Controls.Add(this.Label16);
            this.GroupBox5.Controls.Add(this.btnListReset);
            this.GroupBox5.Controls.Add(this.btnRemove);
            this.GroupBox5.Controls.Add(this.btnPrint);
            this.GroupBox5.Controls.Add(this.btnSelectionInv);
            this.GroupBox5.Controls.Add(Label25);
            this.GroupBox5.Controls.Add(this.btnListUpdate);
            this.GroupBox5.Controls.Add(this.Label24);
            this.GroupBox5.Controls.Add(this.Label23);
            this.GroupBox5.Controls.Add(this.txtDiscountPer);
            this.GroupBox5.Controls.Add(Label51);
            this.GroupBox5.Controls.Add(this.Label21);
            this.GroupBox5.Controls.Add(this.btnAdd);
            this.GroupBox5.Controls.Add(Label49);
            this.GroupBox5.Controls.Add(this.txtVAT);
            this.GroupBox5.Controls.Add(Label6);
            this.GroupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.GroupBox5.Location = new System.Drawing.Point(99, 110);
            this.GroupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.GroupBox5.Size = new System.Drawing.Size(1499, 90);
            this.GroupBox5.TabIndex = 2;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "معلومات الأصناف :";
            // 
            // txtBarcode
            // 
            this.txtBarcode.BackColor = System.Drawing.SystemColors.Info;
            this.txtBarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBarcode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtBarcode.Location = new System.Drawing.Point(1247, 49);
            this.txtBarcode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(127, 30);
            this.txtBarcode.TabIndex = 335;
            this.txtBarcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBarcode.TextChanged += new System.EventHandler(this.txtBarcode_TextChanged_1);
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.Color.Honeydew;
            this.txtTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.txtTotalAmount.Location = new System.Drawing.Point(423, 48);
            this.txtTotalAmount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.Size = new System.Drawing.Size(107, 30);
            this.txtTotalAmount.TabIndex = 341;
            this.txtTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQty
            // 
            this.txtQty.BackColor = System.Drawing.Color.White;
            this.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtQty.ForeColor = System.Drawing.Color.Black;
            this.txtQty.Location = new System.Drawing.Point(875, 49);
            this.txtQty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(71, 30);
            this.txtQty.TabIndex = 337;
            this.txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQty.TextChanged += new System.EventHandler(this.txtQty_TextChanged);
            // 
            // txtProductName
            // 
            this.txtProductName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProductName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtProductName.BackColor = System.Drawing.Color.Honeydew;
            this.txtProductName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProductName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtProductName.Location = new System.Drawing.Point(1061, 49);
            this.txtProductName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(186, 30);
            this.txtProductName.TabIndex = 334;
            this.txtProductName.TextChanged += new System.EventHandler(this.txtProductName_TextChanged_1);
            // 
            // txtVATAmount
            // 
            this.txtVATAmount.BackColor = System.Drawing.Color.Honeydew;
            this.txtVATAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVATAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtVATAmount.Location = new System.Drawing.Point(531, 48);
            this.txtVATAmount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtVATAmount.Name = "txtVATAmount";
            this.txtVATAmount.ReadOnly = true;
            this.txtVATAmount.Size = new System.Drawing.Size(149, 30);
            this.txtVATAmount.TabIndex = 340;
            // 
            // txtDiscountAmount
            // 
            this.txtDiscountAmount.BackColor = System.Drawing.Color.Honeydew;
            this.txtDiscountAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDiscountAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtDiscountAmount.Location = new System.Drawing.Point(676, 49);
            this.txtDiscountAmount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiscountAmount.Name = "txtDiscountAmount";
            this.txtDiscountAmount.Size = new System.Drawing.Size(83, 30);
            this.txtDiscountAmount.TabIndex = 339;
            this.txtDiscountAmount.TextChanged += new System.EventHandler(this.txtDiscountAmount_TextChanged);
            // 
            // txtAmount
            // 
            this.txtAmount.BackColor = System.Drawing.Color.Honeydew;
            this.txtAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtAmount.Location = new System.Drawing.Point(759, 49);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ReadOnly = true;
            this.txtAmount.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtAmount.Size = new System.Drawing.Size(115, 30);
            this.txtAmount.TabIndex = 338;
            this.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSellingPrice
            // 
            this.txtSellingPrice.BackColor = System.Drawing.Color.Honeydew;
            this.txtSellingPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSellingPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtSellingPrice.Location = new System.Drawing.Point(947, 49);
            this.txtSellingPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSellingPrice.Name = "txtSellingPrice";
            this.txtSellingPrice.Size = new System.Drawing.Size(114, 30);
            this.txtSellingPrice.TabIndex = 336;
            this.txtSellingPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSellingPrice.TextChanged += new System.EventHandler(this.txtSellingPrice_TextChanged_1);
            // 
            // Label16
            // 
            this.Label16.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label16.ForeColor = System.Drawing.Color.White;
            this.Label16.Location = new System.Drawing.Point(1247, 23);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(131, 26);
            this.Label16.TabIndex = 330;
            this.Label16.Text = "الباركود";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label24
            // 
            this.Label24.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label24.ForeColor = System.Drawing.Color.White;
            this.Label24.Location = new System.Drawing.Point(875, 23);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(72, 26);
            this.Label24.TabIndex = 324;
            this.Label24.Text = "الكمية ";
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label23
            // 
            this.Label23.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label23.ForeColor = System.Drawing.Color.White;
            this.Label23.Location = new System.Drawing.Point(1067, 23);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(187, 26);
            this.Label23.TabIndex = 321;
            this.Label23.Text = "اسم الصنف";
            this.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiscountPer
            // 
            this.txtDiscountPer.BackColor = System.Drawing.Color.Honeydew;
            this.txtDiscountPer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtDiscountPer.Location = new System.Drawing.Point(679, 23);
            this.txtDiscountPer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiscountPer.Multiline = true;
            this.txtDiscountPer.Name = "txtDiscountPer";
            this.txtDiscountPer.Size = new System.Drawing.Size(51, 26);
            this.txtDiscountPer.TabIndex = 6;
            this.txtDiscountPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label21
            // 
            this.Label21.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label21.ForeColor = System.Drawing.Color.White;
            this.Label21.Location = new System.Drawing.Point(947, 23);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(120, 26);
            this.Label21.TabIndex = 87;
            this.Label21.Text = "السعر ";
            this.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtVAT
            // 
            this.txtVAT.BackColor = System.Drawing.Color.Honeydew;
            this.txtVAT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtVAT.Location = new System.Drawing.Point(531, 23);
            this.txtVAT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtVAT.Multiline = true;
            this.txtVAT.Name = "txtVAT";
            this.txtVAT.Size = new System.Drawing.Size(64, 26);
            this.txtVAT.TabIndex = 8;
            this.txtVAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Panel4
            // 
            this.Panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Panel4.BackColor = System.Drawing.Color.Transparent;
            this.Panel4.Controls.Add(this.txtGrandTotal);
            this.Panel4.Controls.Add(this.Label31);
            this.Panel4.Controls.Add(this.txtPaymentDue);
            this.Panel4.Controls.Add(this.txtTotalPayment);
            this.Panel4.Controls.Add(this.Label34);
            this.Panel4.Controls.Add(this.Label35);
            this.Panel4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Panel4.Location = new System.Drawing.Point(-3, 559);
            this.Panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(440, 167);
            this.Panel4.TabIndex = 5;
            // 
            // txtGrandTotal
            // 
            this.txtGrandTotal.BackColor = System.Drawing.Color.Gold;
            this.txtGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGrandTotal.Font = new System.Drawing.Font("Times New Roman", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrandTotal.ForeColor = System.Drawing.Color.Black;
            this.txtGrandTotal.Location = new System.Drawing.Point(7, 6);
            this.txtGrandTotal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGrandTotal.Multiline = true;
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.ReadOnly = true;
            this.txtGrandTotal.Size = new System.Drawing.Size(255, 59);
            this.txtGrandTotal.TabIndex = 0;
            this.txtGrandTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGrandTotal.TextChanged += new System.EventHandler(this.txtGrandTotal_TextChanged);
            // 
            // Label31
            // 
            this.Label31.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label31.ForeColor = System.Drawing.Color.White;
            this.Label31.Location = new System.Drawing.Point(269, 6);
            this.Label31.Name = "Label31";
            this.Label31.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label31.Size = new System.Drawing.Size(130, 59);
            this.Label31.TabIndex = 84;
            this.Label31.Text = "المجموع الكلي :";
            this.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPaymentDue
            // 
            this.txtPaymentDue.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtPaymentDue.Location = new System.Drawing.Point(7, 127);
            this.txtPaymentDue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPaymentDue.Multiline = true;
            this.txtPaymentDue.Name = "txtPaymentDue";
            this.txtPaymentDue.ReadOnly = true;
            this.txtPaymentDue.Size = new System.Drawing.Size(256, 35);
            this.txtPaymentDue.TabIndex = 2;
            this.txtPaymentDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPaymentDue.TextChanged += new System.EventHandler(this.txtPaymentDue_TextChanged);
            // 
            // txtTotalPayment
            // 
            this.txtTotalPayment.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtTotalPayment.Location = new System.Drawing.Point(7, 79);
            this.txtTotalPayment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalPayment.Multiline = true;
            this.txtTotalPayment.Name = "txtTotalPayment";
            this.txtTotalPayment.ReadOnly = true;
            this.txtTotalPayment.Size = new System.Drawing.Size(256, 35);
            this.txtTotalPayment.TabIndex = 1;
            this.txtTotalPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalPayment.TextChanged += new System.EventHandler(this.txtTotalPayment_TextChanged);
            // 
            // Label34
            // 
            this.Label34.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label34.ForeColor = System.Drawing.Color.White;
            this.Label34.Location = new System.Drawing.Point(271, 128);
            this.Label34.Name = "Label34";
            this.Label34.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label34.Size = new System.Drawing.Size(130, 35);
            this.Label34.TabIndex = 79;
            this.Label34.Text = "المتبقي :";
            this.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label35
            // 
            this.Label35.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label35.ForeColor = System.Drawing.Color.White;
            this.Label35.Location = new System.Drawing.Point(272, 80);
            this.Label35.Name = "Label35";
            this.Label35.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label35.Size = new System.Drawing.Size(130, 35);
            this.Label35.TabIndex = 78;
            this.Label35.Text = "المبلغ المدفوع :";
            this.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCommissionPer
            // 
            this.txtCommissionPer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtCommissionPer.Location = new System.Drawing.Point(709, -14);
            this.txtCommissionPer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCommissionPer.Name = "txtCommissionPer";
            this.txtCommissionPer.ReadOnly = true;
            this.txtCommissionPer.Size = new System.Drawing.Size(80, 30);
            this.txtCommissionPer.TabIndex = 318;
            this.txtCommissionPer.Visible = false;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox2.Controls.Add(this.txtCheck);
            this.GroupBox2.Controls.Add(this.btnListReset1);
            this.GroupBox2.Controls.Add(this.dtpPaymentDate);
            this.GroupBox2.Controls.Add(this.btnListUpdate1);
            this.GroupBox2.Controls.Add(this.Label7);
            this.GroupBox2.Controls.Add(this.Label17);
            this.GroupBox2.Controls.Add(this.txtPayment);
            this.GroupBox2.Controls.Add(this.cmbPaymentMode);
            this.GroupBox2.Controls.Add(this.btnRemove1);
            this.GroupBox2.Controls.Add(this.btnAdd1);
            this.GroupBox2.Controls.Add(this.Label12);
            this.GroupBox2.Controls.Add(this.Label13);
            this.GroupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.GroupBox2.Location = new System.Drawing.Point(1180, 559);
            this.GroupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.GroupBox2.Size = new System.Drawing.Size(417, 185);
            this.GroupBox2.TabIndex = 3;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "معلومات الدفعات :";
            this.GroupBox2.Enter += new System.EventHandler(this.GroupBox2_Enter);
            // 
            // txtCheck
            // 
            this.txtCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheck.Location = new System.Drawing.Point(133, 103);
            this.txtCheck.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCheck.Name = "txtCheck";
            this.txtCheck.Size = new System.Drawing.Size(161, 26);
            this.txtCheck.TabIndex = 99;
            this.txtCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCheck.TextChanged += new System.EventHandler(this.txtCheck_TextChanged);
            // 
            // btnListReset1
            // 
            this.btnListReset1.BackColor = System.Drawing.Color.IndianRed;
            this.btnListReset1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnListReset1.ForeColor = System.Drawing.Color.Black;
            this.btnListReset1.Location = new System.Drawing.Point(9, 66);
            this.btnListReset1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnListReset1.Name = "btnListReset1";
            this.btnListReset1.Size = new System.Drawing.Size(115, 32);
            this.btnListReset1.TabIndex = 27;
            this.btnListReset1.Text = "إعادة تعيين";
            this.btnListReset1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListReset1.UseVisualStyleBackColor = true;
            this.btnListReset1.Click += new System.EventHandler(this.btnListReset1_Click_1);
            // 
            // dtpPaymentDate
            // 
            this.dtpPaymentDate.CustomFormat = "dd/MM/yyyy";
            this.dtpPaymentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPaymentDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPaymentDate.Location = new System.Drawing.Point(133, 142);
            this.dtpPaymentDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpPaymentDate.Name = "dtpPaymentDate";
            this.dtpPaymentDate.Size = new System.Drawing.Size(161, 26);
            this.dtpPaymentDate.TabIndex = 2;
            this.dtpPaymentDate.Visible = false;
            // 
            // btnListUpdate1
            // 
            this.btnListUpdate1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnListUpdate1.Enabled = false;
            this.btnListUpdate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnListUpdate1.ForeColor = System.Drawing.Color.Black;
            this.btnListUpdate1.Location = new System.Drawing.Point(9, 103);
            this.btnListUpdate1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnListUpdate1.Name = "btnListUpdate1";
            this.btnListUpdate1.Size = new System.Drawing.Size(115, 32);
            this.btnListUpdate1.TabIndex = 26;
            this.btnListUpdate1.Text = "تعديل";
            this.btnListUpdate1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListUpdate1.UseVisualStyleBackColor = true;
            this.btnListUpdate1.Click += new System.EventHandler(this.btnListUpdate1_Click);
            // 
            // Label7
            // 
            this.Label7.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(307, 142);
            this.Label7.Name = "Label7";
            this.Label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label7.Size = new System.Drawing.Size(101, 32);
            this.Label7.TabIndex = 25;
            this.Label7.Text = "تاريخ الدفع :";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label7.Visible = false;
            // 
            // Label17
            // 
            this.Label17.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label17.ForeColor = System.Drawing.Color.White;
            this.Label17.Location = new System.Drawing.Point(307, 103);
            this.Label17.Name = "Label17";
            this.Label17.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label17.Size = new System.Drawing.Size(99, 32);
            this.Label17.TabIndex = 100;
            this.Label17.Text = "رقم الشيك :";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPayment
            // 
            this.txtPayment.BackColor = System.Drawing.Color.White;
            this.txtPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Location = new System.Drawing.Point(133, 66);
            this.txtPayment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(161, 26);
            this.txtPayment.TabIndex = 1;
            this.txtPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayment.TextChanged += new System.EventHandler(this.txtPayment_TextChanged);
            // 
            // cmbPaymentMode
            // 
            this.cmbPaymentMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPaymentMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPaymentMode.FormattingEnabled = true;
            this.cmbPaymentMode.Items.AddRange(new object[] {
            "نقدا",
            "شيك",
            "بطاقة إئتمان",
            "فيزا كارت",
            "أجل"});
            this.cmbPaymentMode.Location = new System.Drawing.Point(133, 27);
            this.cmbPaymentMode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbPaymentMode.Name = "cmbPaymentMode";
            this.cmbPaymentMode.Size = new System.Drawing.Size(161, 28);
            this.cmbPaymentMode.TabIndex = 0;
            this.cmbPaymentMode.SelectedIndexChanged += new System.EventHandler(this.cmbPaymentMode_SelectedIndexChanged);
            // 
            // btnRemove1
            // 
            this.btnRemove1.BackColor = System.Drawing.Color.Firebrick;
            this.btnRemove1.Enabled = false;
            this.btnRemove1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnRemove1.ForeColor = System.Drawing.Color.Black;
            this.btnRemove1.Location = new System.Drawing.Point(9, 142);
            this.btnRemove1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemove1.Name = "btnRemove1";
            this.btnRemove1.Size = new System.Drawing.Size(115, 32);
            this.btnRemove1.TabIndex = 4;
            this.btnRemove1.Text = "حذف";
            this.btnRemove1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRemove1.UseVisualStyleBackColor = true;
            this.btnRemove1.Click += new System.EventHandler(this.btnRemove1_Click_1);
            // 
            // btnAdd1
            // 
            this.btnAdd1.BackColor = System.Drawing.Color.ForestGreen;
            this.btnAdd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnAdd1.ForeColor = System.Drawing.Color.Black;
            this.btnAdd1.Location = new System.Drawing.Point(9, 30);
            this.btnAdd1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(115, 32);
            this.btnAdd1.TabIndex = 3;
            this.btnAdd1.Text = "إضافة للشبكة";
            this.btnAdd1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd1.UseVisualStyleBackColor = true;
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd1_Click_1);
            // 
            // Label12
            // 
            this.Label12.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label12.ForeColor = System.Drawing.Color.White;
            this.Label12.Location = new System.Drawing.Point(307, 27);
            this.Label12.Name = "Label12";
            this.Label12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label12.Size = new System.Drawing.Size(101, 32);
            this.Label12.TabIndex = 11;
            this.Label12.Text = "طريقة الدفع :";
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label13
            // 
            this.Label13.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label13.ForeColor = System.Drawing.Color.White;
            this.Label13.Location = new System.Drawing.Point(307, 66);
            this.Label13.Name = "Label13";
            this.Label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label13.Size = new System.Drawing.Size(101, 32);
            this.Label13.TabIndex = 22;
            this.Label13.Text = "المبلغ المدفوع :";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label11
            // 
            this.Label11.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.White;
            this.Label11.Location = new System.Drawing.Point(613, -10);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(83, 27);
            this.Label11.TabIndex = 95;
            this.Label11.Text = "كود الصنف";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label11.Visible = false;
            // 
            // txtProductCode
            // 
            this.txtProductCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtProductCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtProductCode.Location = new System.Drawing.Point(523, -14);
            this.txtProductCode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.ReadOnly = true;
            this.txtProductCode.Size = new System.Drawing.Size(84, 30);
            this.txtProductCode.TabIndex = 0;
            this.txtProductCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtProductCode.Visible = false;
            this.txtProductCode.TextChanged += new System.EventHandler(this.txtProductCode_TextChanged);
            // 
            // Label14
            // 
            this.Label14.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label14.ForeColor = System.Drawing.Color.White;
            this.Label14.Location = new System.Drawing.Point(909, -7);
            this.Label14.Name = "Label14";
            this.Label14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label14.Size = new System.Drawing.Size(93, 25);
            this.Label14.TabIndex = 336;
            this.Label14.Text = "رقم المندوب :";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label14.Visible = false;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtCustomerID.Location = new System.Drawing.Point(288, -14);
            this.txtCustomerID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(113, 30);
            this.txtCustomerID.TabIndex = 0;
            this.txtCustomerID.Visible = false;
            this.txtCustomerID.TextChanged += new System.EventHandler(this.txtCustomerID_TextChanged);
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label3.ForeColor = System.Drawing.Color.White;
            this.Label3.Location = new System.Drawing.Point(409, -11);
            this.Label3.Name = "Label3";
            this.Label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label3.Size = new System.Drawing.Size(110, 27);
            this.Label3.TabIndex = 0;
            this.Label3.Text = "رقم العميل :";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label3.Visible = false;
            // 
            // DataGridView2
            // 
            this.DataGridView2.AllowUserToAddRows = false;
            this.DataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle163.BackColor = System.Drawing.Color.FloralWhite;
            this.DataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle163;
            this.DataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.DataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle164.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle164.BackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle164.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle164.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle164.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle164.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle164.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle164;
            this.DataGridView2.ColumnHeadersHeight = 30;
            this.DataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8,
            this.Column15,
            this.Column16});
            this.DataGridView2.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle167.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle167.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle167.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle167.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle167.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle167.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle167.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView2.DefaultCellStyle = dataGridViewCellStyle167;
            this.DataGridView2.EnableHeadersVisualStyles = false;
            this.DataGridView2.GridColor = System.Drawing.Color.White;
            this.DataGridView2.Location = new System.Drawing.Point(815, 569);
            this.DataGridView2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataGridView2.Name = "DataGridView2";
            this.DataGridView2.ReadOnly = true;
            this.DataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle168.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle168.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle168.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle168.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle168.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle168.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle168.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle168;
            this.DataGridView2.RowHeadersWidth = 25;
            this.DataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle169.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle169.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle169.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle169.SelectionForeColor = System.Drawing.Color.White;
            this.DataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle169;
            this.DataGridView2.RowTemplate.Height = 25;
            this.DataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView2.Size = new System.Drawing.Size(364, 175);
            this.DataGridView2.TabIndex = 86;
            this.DataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView2_CellContentClick);
            this.DataGridView2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.DataGridView2_MouseClick);
            // 
            // Column8
            // 
            this.Column8.HeaderText = "طريقة الدفع";
            this.Column8.MinimumWidth = 6;
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column15
            // 
            dataGridViewCellStyle165.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.Column15.DefaultCellStyle = dataGridViewCellStyle165;
            this.Column15.HeaderText = "المبلغ المدفوع";
            this.Column15.MinimumWidth = 6;
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column16
            // 
            dataGridViewCellStyle166.Format = "dd/MM/yyyy";
            this.Column16.DefaultCellStyle = dataGridViewCellStyle166;
            this.Column16.HeaderText = "تاريخ الدفع";
            this.Column16.MinimumWidth = 6;
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // txtSalesmanID
            // 
            this.txtSalesmanID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtSalesmanID.Location = new System.Drawing.Point(792, -16);
            this.txtSalesmanID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSalesmanID.Name = "txtSalesmanID";
            this.txtSalesmanID.ReadOnly = true;
            this.txtSalesmanID.Size = new System.Drawing.Size(111, 30);
            this.txtSalesmanID.TabIndex = 3;
            this.txtSalesmanID.Visible = false;
            this.txtSalesmanID.TextChanged += new System.EventHandler(this.txtSalesmanID_TextChanged);
            // 
            // Label9
            // 
            this.Label9.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(179, -9);
            this.Label9.Name = "Label9";
            this.Label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Label9.Size = new System.Drawing.Size(103, 27);
            this.Label9.TabIndex = 8;
            this.Label9.Text = "رقم الهاتف :";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label9.Visible = false;
            // 
            // lblUser1
            // 
            this.lblUser1.AutoSize = true;
            this.lblUser1.Location = new System.Drawing.Point(729, -5);
            this.lblUser1.Name = "lblUser1";
            this.lblUser1.Size = new System.Drawing.Size(55, 16);
            this.lblUser1.TabIndex = 86;
            this.lblUser1.Text = "Label18";
            this.lblUser1.Visible = false;
            // 
            // Panel2
            // 
            this.Panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Panel2.Controls.Add(this.lblDateTime);
            this.Panel2.Controls.Add(this.Label1);
            this.Panel2.Controls.Add(this.lblUserType);
            this.Panel2.Controls.Add(this.lblUser);
            this.Panel2.Controls.Add(this.txtCID);
            this.Panel2.Controls.Add(this.txtProductID);
            this.Panel2.Controls.Add(this.txtCustomerType);
            this.Panel2.Controls.Add(this.txtID);
            this.Panel2.Controls.Add(this.txtTotalQty);
            this.Panel2.Controls.Add(this.txtSM_ID);
            this.Panel2.Controls.Add(this.lblSet);
            this.Panel2.Location = new System.Drawing.Point(31, 71);
            this.Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(65, 36);
            this.Panel2.TabIndex = 343;
            this.Panel2.Visible = false;
            // 
            // lblDateTime
            // 
            this.lblDateTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDateTime.ForeColor = System.Drawing.Color.NavajoWhite;
            this.lblDateTime.Location = new System.Drawing.Point(-1085, 7);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(120, 27);
            this.lblDateTime.TabIndex = 319;
            this.lblDateTime.Text = "التاريخ والوقت";
            this.lblDateTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDateTime.Visible = false;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Label1.ForeColor = System.Drawing.Color.NavajoWhite;
            this.Label1.Location = new System.Drawing.Point(1008, 2);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(166, 38);
            this.Label1.TabIndex = 319;
            this.Label1.Text = "فاتورة مبيعات";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label1.Visible = false;
            // 
            // lblUserType
            // 
            this.lblUserType.AutoSize = true;
            this.lblUserType.Location = new System.Drawing.Point(257, 18);
            this.lblUserType.Name = "lblUserType";
            this.lblUserType.Size = new System.Drawing.Size(71, 16);
            this.lblUserType.TabIndex = 315;
            this.lblUserType.Text = "User Type";
            this.lblUserType.Visible = false;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(279, 18);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(36, 16);
            this.lblUser.TabIndex = 313;
            this.lblUser.Text = "User";
            this.lblUser.Visible = false;
            // 
            // txtCID
            // 
            this.txtCID.BackColor = System.Drawing.SystemColors.Control;
            this.txtCID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCID.Location = new System.Drawing.Point(69, 9);
            this.txtCID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCID.Name = "txtCID";
            this.txtCID.ReadOnly = true;
            this.txtCID.Size = new System.Drawing.Size(71, 24);
            this.txtCID.TabIndex = 7;
            this.txtCID.Visible = false;
            // 
            // txtProductID
            // 
            this.txtProductID.BackColor = System.Drawing.SystemColors.Control;
            this.txtProductID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductID.Location = new System.Drawing.Point(91, 10);
            this.txtProductID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.ReadOnly = true;
            this.txtProductID.Size = new System.Drawing.Size(71, 24);
            this.txtProductID.TabIndex = 316;
            this.txtProductID.Visible = false;
            // 
            // txtCustomerType
            // 
            this.txtCustomerType.Location = new System.Drawing.Point(196, 12);
            this.txtCustomerType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCustomerType.Name = "txtCustomerType";
            this.txtCustomerType.Size = new System.Drawing.Size(100, 22);
            this.txtCustomerType.TabIndex = 87;
            this.txtCustomerType.Visible = false;
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.SystemColors.Control;
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(231, 9);
            this.txtID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(71, 24);
            this.txtID.TabIndex = 12;
            this.txtID.Visible = false;
            // 
            // txtTotalQty
            // 
            this.txtTotalQty.BackColor = System.Drawing.SystemColors.Control;
            this.txtTotalQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalQty.Location = new System.Drawing.Point(205, 5);
            this.txtTotalQty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalQty.Name = "txtTotalQty";
            this.txtTotalQty.ReadOnly = true;
            this.txtTotalQty.Size = new System.Drawing.Size(71, 24);
            this.txtTotalQty.TabIndex = 8;
            this.txtTotalQty.Visible = false;
            // 
            // txtSM_ID
            // 
            this.txtSM_ID.BackColor = System.Drawing.SystemColors.Control;
            this.txtSM_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSM_ID.Location = new System.Drawing.Point(196, 10);
            this.txtSM_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSM_ID.Name = "txtSM_ID";
            this.txtSM_ID.ReadOnly = true;
            this.txtSM_ID.Size = new System.Drawing.Size(71, 24);
            this.txtSM_ID.TabIndex = 317;
            this.txtSM_ID.Visible = false;
            // 
            // lblSet
            // 
            this.lblSet.AutoSize = true;
            this.lblSet.Location = new System.Drawing.Point(279, 18);
            this.lblSet.Name = "lblSet";
            this.lblSet.Size = new System.Drawing.Size(27, 16);
            this.lblSet.TabIndex = 314;
            this.lblSet.Text = "Set";
            this.lblSet.Visible = false;
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.White;
            this.Panel1.Controls.Add(this.dgw);
            this.Panel1.Controls.Add(this.DataGridView1);
            this.Panel1.Controls.Add(this.dataGridView3);
            this.Panel1.Controls.Add(this.Panel2);
            this.Panel1.Controls.Add(this.lblUser1);
            this.Panel1.Controls.Add(this.Label9);
            this.Panel1.Controls.Add(this.txtSalesmanID);
            this.Panel1.Controls.Add(this.DataGridView2);
            this.Panel1.Controls.Add(this.Label3);
            this.Panel1.Controls.Add(this.txtCustomerID);
            this.Panel1.Controls.Add(this.Label14);
            this.Panel1.Controls.Add(this.txtProductCode);
            this.Panel1.Controls.Add(this.Label11);
            this.Panel1.Controls.Add(this.GroupBox2);
            this.Panel1.Controls.Add(this.txtCommissionPer);
            this.Panel1.Controls.Add(this.Panel4);
            this.Panel1.Controls.Add(this.GroupBox5);
            this.Panel1.Controls.Add(this.GroupBox3);
            this.Panel1.Controls.Add(this.GroupBox4);
            this.Panel1.Controls.Add(this.btnKeyboard);
            this.Panel1.Controls.Add(this.btnMaximise);
            this.Panel1.Controls.Add(this.btnMinimize);
            this.Panel1.Controls.Add(this.btnClose);
            this.Panel1.Controls.Add(this.txtMargin);
            this.Panel1.Controls.Add(this.Label10);
            this.Panel1.Controls.Add(this.txtCostPrice);
            this.Panel1.Controls.Add(this.btnScanItems);
            this.Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1605, 772);
            this.Panel1.TabIndex = 409;
            this.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // dgw
            // 
            this.dgw.AllowUserToAddRows = false;
            this.dgw.AllowUserToDeleteRows = false;
            dataGridViewCellStyle170.BackColor = System.Drawing.Color.Azure;
            this.dgw.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle170;
            this.dgw.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgw.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgw.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle171.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle171.BackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle171.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            dataGridViewCellStyle171.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle171.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle171.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle171.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle171;
            this.dgw.ColumnHeadersHeight = 35;
            this.dgw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgw.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewTextBoxColumn1,
            this.DataGridViewTextBoxColumn2,
            this.DataGridViewTextBoxColumn3,
            this.DataGridViewTextBoxColumn4,
            this.DataGridViewTextBoxColumn5,
            this.DataGridViewTextBoxColumn6,
            this.DataGridViewTextBoxColumn7,
            this.DataGridViewTextBoxColumn8,
            this.DataGridViewTextBoxColumn9,
            this.Column18,
            this.Column19});
            this.dgw.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgw.EnableHeadersVisualStyles = false;
            this.dgw.GridColor = System.Drawing.Color.Gray;
            this.dgw.Location = new System.Drawing.Point(755, 193);
            this.dgw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgw.MultiSelect = false;
            this.dgw.Name = "dgw";
            this.dgw.ReadOnly = true;
            this.dgw.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dgw.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle177.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle177.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle177.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            dataGridViewCellStyle177.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle177.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle177.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle177.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgw.RowHeadersDefaultCellStyle = dataGridViewCellStyle177;
            this.dgw.RowHeadersWidth = 25;
            this.dgw.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle178.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle178.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle178.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle178.SelectionForeColor = System.Drawing.Color.White;
            this.dgw.RowsDefaultCellStyle = dataGridViewCellStyle178;
            this.dgw.RowTemplate.Height = 30;
            this.dgw.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgw.Size = new System.Drawing.Size(595, 210);
            this.dgw.TabIndex = 409;
            this.dgw.Visible = false;
            this.dgw.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgw_CellContentClick_2);
            this.dgw.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgw_MouseClick);
            // 
            // DataGridView1
            // 
            this.DataGridView1.AllowUserToAddRows = false;
            this.DataGridView1.AllowUserToOrderColumns = true;
            this.DataGridView1.AllowUserToResizeColumns = false;
            dataGridViewCellStyle179.BackColor = System.Drawing.Color.Azure;
            this.DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle179;
            this.DataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle180.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle180.BackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle180.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            dataGridViewCellStyle180.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle180.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle180.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle180.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle180;
            this.DataGridView1.ColumnHeadersHeight = 30;
            this.DataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column12,
            this.Column1,
            this.Column17,
            this.Column2,
            this.Column13,
            this.Column14,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column7});
            this.DataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle195.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle195.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle195.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            dataGridViewCellStyle195.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle195.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle195.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle195.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle195;
            this.DataGridView1.EnableHeadersVisualStyles = false;
            this.DataGridView1.GridColor = System.Drawing.Color.Gray;
            this.DataGridView1.Location = new System.Drawing.Point(47, 206);
            this.DataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle196.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle196.BackColor = System.Drawing.Color.Azure;
            dataGridViewCellStyle196.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            dataGridViewCellStyle196.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle196.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle196.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle196.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle196;
            this.DataGridView1.RowHeadersWidth = 25;
            this.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle197.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle197.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle197.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle197.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle197;
            this.DataGridView1.RowTemplate.Height = 28;
            this.DataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(1491, 320);
            this.DataGridView1.TabIndex = 49;
            this.DataGridView1.Tag = "";
            this.DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellContentClick_2);
            // 
            // Column12
            // 
            dataGridViewCellStyle181.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column12.DefaultCellStyle = dataGridViewCellStyle181;
            this.Column12.FillWeight = 97.60427F;
            this.Column12.HeaderText = "كود الصنف";
            this.Column12.MinimumWidth = 6;
            this.Column12.Name = "Column12";
            // 
            // Column1
            // 
            dataGridViewCellStyle182.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle182;
            this.Column1.FillWeight = 98.22199F;
            this.Column1.HeaderText = "اسم الصنف";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            // 
            // Column17
            // 
            dataGridViewCellStyle183.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column17.DefaultCellStyle = dataGridViewCellStyle183;
            this.Column17.FillWeight = 98.7849F;
            this.Column17.HeaderText = "الباركود";
            this.Column17.MinimumWidth = 6;
            this.Column17.Name = "Column17";
            // 
            // Column2
            // 
            dataGridViewCellStyle184.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle184;
            this.Column2.HeaderText = "سعر التكلفة";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Visible = false;
            // 
            // Column13
            // 
            dataGridViewCellStyle185.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column13.DefaultCellStyle = dataGridViewCellStyle185;
            this.Column13.FillWeight = 99.29787F;
            this.Column13.HeaderText = "السعر";
            this.Column13.MinimumWidth = 6;
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            dataGridViewCellStyle186.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column14.DefaultCellStyle = dataGridViewCellStyle186;
            this.Column14.HeaderText = "Margin";
            this.Column14.MinimumWidth = 6;
            this.Column14.Name = "Column14";
            this.Column14.Visible = false;
            // 
            // Column3
            // 
            dataGridViewCellStyle187.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle187.Format = "N1";
            dataGridViewCellStyle187.NullValue = null;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle187;
            this.Column3.FillWeight = 99.76534F;
            this.Column3.HeaderText = "الكمية";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            dataGridViewCellStyle188.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle188;
            this.Column4.FillWeight = 100.1913F;
            this.Column4.HeaderText = "المجموع";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            dataGridViewCellStyle189.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle189;
            this.Column5.FillWeight = 100.5795F;
            this.Column5.HeaderText = "خصم %";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            dataGridViewCellStyle190.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle190;
            this.Column6.FillWeight = 100.9332F;
            this.Column6.HeaderText = "مبلغ الخصم";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            // 
            // Column9
            // 
            dataGridViewCellStyle191.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column9.DefaultCellStyle = dataGridViewCellStyle191;
            this.Column9.FillWeight = 101.2555F;
            this.Column9.HeaderText = "ضرائب %";
            this.Column9.MinimumWidth = 6;
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            dataGridViewCellStyle192.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column10.DefaultCellStyle = dataGridViewCellStyle192;
            this.Column10.FillWeight = 101.5493F;
            this.Column10.HeaderText = "مبلغ الضرائب";
            this.Column10.MinimumWidth = 6;
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            dataGridViewCellStyle193.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column11.DefaultCellStyle = dataGridViewCellStyle193;
            this.Column11.FillWeight = 101.817F;
            this.Column11.HeaderText = "إجمالي المبلغ";
            this.Column11.MinimumWidth = 6;
            this.Column11.Name = "Column11";
            // 
            // Column7
            // 
            dataGridViewCellStyle194.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column7.DefaultCellStyle = dataGridViewCellStyle194;
            this.Column7.HeaderText = "PID";
            this.Column7.MinimumWidth = 6;
            this.Column7.Name = "Column7";
            this.Column7.Visible = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToOrderColumns = true;
            this.dataGridView3.AllowUserToResizeColumns = false;
            dataGridViewCellStyle198.BackColor = System.Drawing.Color.Azure;
            this.dataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle198;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle199.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle199.BackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle199.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle199.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle199.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle199.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle199.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle199;
            this.dataGridView3.ColumnHeadersHeight = 30;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23});
            this.dataGridView3.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle214.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle214.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle214.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle214.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle214.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle214.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle214.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle214;
            this.dataGridView3.EnableHeadersVisualStyles = false;
            this.dataGridView3.GridColor = System.Drawing.Color.Gray;
            this.dataGridView3.Location = new System.Drawing.Point(464, 590);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle215.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle215.BackColor = System.Drawing.Color.Azure;
            dataGridViewCellStyle215.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle215.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle215.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle215.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle215.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle215;
            this.dataGridView3.RowHeadersWidth = 25;
            this.dataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle216.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle216.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle216.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle216.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle216;
            this.dataGridView3.RowTemplate.Height = 28;
            this.dataGridView3.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(311, 71);
            this.dataGridView3.TabIndex = 408;
            this.dataGridView3.Visible = false;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick_1);
            // 
            // dataGridViewTextBoxColumn10
            // 
            dataGridViewCellStyle200.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle200;
            this.dataGridViewTextBoxColumn10.FillWeight = 97.60427F;
            this.dataGridViewTextBoxColumn10.HeaderText = "كود الصنف";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            dataGridViewCellStyle201.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle201;
            this.dataGridViewTextBoxColumn11.FillWeight = 98.22199F;
            this.dataGridViewTextBoxColumn11.HeaderText = "اسم الصنف";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            dataGridViewCellStyle202.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle202;
            this.dataGridViewTextBoxColumn12.FillWeight = 98.7849F;
            this.dataGridViewTextBoxColumn12.HeaderText = "الباركود";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            dataGridViewCellStyle203.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle203;
            this.dataGridViewTextBoxColumn13.HeaderText = "سعر التكلفة";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewCellStyle204.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle204;
            this.dataGridViewTextBoxColumn14.FillWeight = 99.29787F;
            this.dataGridViewTextBoxColumn14.HeaderText = "السعر";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            dataGridViewCellStyle205.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle205;
            this.dataGridViewTextBoxColumn15.HeaderText = "Margin";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Visible = false;
            // 
            // dataGridViewTextBoxColumn16
            // 
            dataGridViewCellStyle206.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle206.Format = "N1";
            dataGridViewCellStyle206.NullValue = null;
            this.dataGridViewTextBoxColumn16.DefaultCellStyle = dataGridViewCellStyle206;
            this.dataGridViewTextBoxColumn16.FillWeight = 99.76534F;
            this.dataGridViewTextBoxColumn16.HeaderText = "الكمية";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            dataGridViewCellStyle207.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle207;
            this.dataGridViewTextBoxColumn17.FillWeight = 100.1913F;
            this.dataGridViewTextBoxColumn17.HeaderText = "المجموع";
            this.dataGridViewTextBoxColumn17.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            dataGridViewCellStyle208.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle208;
            this.dataGridViewTextBoxColumn18.FillWeight = 100.5795F;
            this.dataGridViewTextBoxColumn18.HeaderText = "خصم %";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            dataGridViewCellStyle209.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle209;
            this.dataGridViewTextBoxColumn19.FillWeight = 100.9332F;
            this.dataGridViewTextBoxColumn19.HeaderText = "مبلغ الخصم";
            this.dataGridViewTextBoxColumn19.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            dataGridViewCellStyle210.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle210;
            this.dataGridViewTextBoxColumn20.FillWeight = 101.2555F;
            this.dataGridViewTextBoxColumn20.HeaderText = "ضرائب %";
            this.dataGridViewTextBoxColumn20.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            dataGridViewCellStyle211.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle211;
            this.dataGridViewTextBoxColumn21.FillWeight = 101.5493F;
            this.dataGridViewTextBoxColumn21.HeaderText = "مبلغ الضرائب";
            this.dataGridViewTextBoxColumn21.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            dataGridViewCellStyle212.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn22.DefaultCellStyle = dataGridViewCellStyle212;
            this.dataGridViewTextBoxColumn22.FillWeight = 101.817F;
            this.dataGridViewTextBoxColumn22.HeaderText = "إجمالي المبلغ";
            this.dataGridViewTextBoxColumn22.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            dataGridViewCellStyle213.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn23.DefaultCellStyle = dataGridViewCellStyle213;
            this.dataGridViewTextBoxColumn23.HeaderText = "PID";
            this.dataGridViewTextBoxColumn23.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Visible = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.ForestGreen;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.Black;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(264, 14);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(139, 34);
            this.btnAdd.TabIndex = 13;
            this.btnAdd.Text = "أضافة للشبكة";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Salmon;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(16, 10);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button6.Size = new System.Drawing.Size(69, 34);
            this.button6.TabIndex = 411;
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnListReset
            // 
            this.btnListReset.BackColor = System.Drawing.Color.IndianRed;
            this.btnListReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListReset.ForeColor = System.Drawing.Color.Black;
            this.btnListReset.Image = ((System.Drawing.Image)(resources.GetObject("btnListReset.Image")));
            this.btnListReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListReset.Location = new System.Drawing.Point(100, 14);
            this.btnListReset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnListReset.Name = "btnListReset";
            this.btnListReset.Size = new System.Drawing.Size(156, 34);
            this.btnListReset.TabIndex = 12;
            this.btnListReset.Text = "أعادة تعيين";
            this.btnListReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnListReset.UseVisualStyleBackColor = true;
            this.btnListReset.Click += new System.EventHandler(this.btnListReset_Click_1);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.Firebrick;
            this.btnRemove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemove.Enabled = false;
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.ForeColor = System.Drawing.Color.Black;
            this.btnRemove.Image = ((System.Drawing.Image)(resources.GetObject("btnRemove.Image")));
            this.btnRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRemove.Location = new System.Drawing.Point(100, 49);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(156, 34);
            this.btnRemove.TabIndex = 14;
            this.btnRemove.Text = "حذف";
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.Enabled = false;
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPrint.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.Location = new System.Drawing.Point(23, 47);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnPrint.Size = new System.Drawing.Size(39, 34);
            this.btnPrint.TabIndex = 6;
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Visible = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click_1);
            // 
            // btnSelectionInv
            // 
            this.btnSelectionInv.BackColor = System.Drawing.Color.Gold;
            this.btnSelectionInv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectionInv.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectionInv.Image = ((System.Drawing.Image)(resources.GetObject("btnSelectionInv.Image")));
            this.btnSelectionInv.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSelectionInv.Location = new System.Drawing.Point(1375, 21);
            this.btnSelectionInv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSelectionInv.Name = "btnSelectionInv";
            this.btnSelectionInv.Size = new System.Drawing.Size(48, 62);
            this.btnSelectionInv.TabIndex = 11;
            this.btnSelectionInv.Text = "R";
            this.btnSelectionInv.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSelectionInv.UseVisualStyleBackColor = false;
            this.btnSelectionInv.Click += new System.EventHandler(this.btnSelectionInv_Click);
            // 
            // btnListUpdate
            // 
            this.btnListUpdate.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnListUpdate.Enabled = false;
            this.btnListUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListUpdate.ForeColor = System.Drawing.Color.Black;
            this.btnListUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnListUpdate.Image")));
            this.btnListUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListUpdate.Location = new System.Drawing.Point(264, 50);
            this.btnListUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnListUpdate.Name = "btnListUpdate";
            this.btnListUpdate.Size = new System.Drawing.Size(139, 34);
            this.btnListUpdate.TabIndex = 15;
            this.btnListUpdate.Text = "تعديل W-E";
            this.btnListUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnListUpdate.UseVisualStyleBackColor = true;
            this.btnListUpdate.Click += new System.EventHandler(this.btnListUpdate_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Yellow;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(385, 62);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button7.Size = new System.Drawing.Size(169, 34);
            this.button7.TabIndex = 413;
            this.button7.Text = " حفظ + طباعة  ";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LimeGreen;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Enabled = false;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(244, 23);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button4.Size = new System.Drawing.Size(91, 34);
            this.button4.TabIndex = 409;
            this.button4.Text = " طباعة";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // btnGetData
            // 
            this.btnGetData.BackColor = System.Drawing.Color.Gold;
            this.btnGetData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGetData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnGetData.ForeColor = System.Drawing.Color.Black;
            this.btnGetData.Image = ((System.Drawing.Image)(resources.GetObject("btnGetData.Image")));
            this.btnGetData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetData.Location = new System.Drawing.Point(136, 68);
            this.btnGetData.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnGetData.Name = "btnGetData";
            this.btnGetData.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnGetData.Size = new System.Drawing.Size(124, 31);
            this.btnGetData.TabIndex = 5;
            this.btnGetData.Text = "بحث عن فاتورة";
            this.btnGetData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGetData.UseVisualStyleBackColor = false;
            this.btnGetData.Click += new System.EventHandler(this.btnGetData_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnUpdate.ForeColor = System.Drawing.Color.Black;
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Location = new System.Drawing.Point(16, 66);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnUpdate.Size = new System.Drawing.Size(115, 32);
            this.btnUpdate.TabIndex = 2;
            this.btnUpdate.Text = "تعديل فاتورة";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Firebrick;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(13, 28);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDelete.Size = new System.Drawing.Size(132, 31);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "حذف الفاتورة";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Button3
            // 
            this.Button3.BackColor = System.Drawing.Color.Yellow;
            this.Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button3.Enabled = false;
            this.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Button3.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button3.ForeColor = System.Drawing.Color.White;
            this.Button3.Image = ((System.Drawing.Image)(resources.GetObject("Button3.Image")));
            this.Button3.Location = new System.Drawing.Point(341, 22);
            this.Button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Button3.Name = "Button3";
            this.Button3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Button3.Size = new System.Drawing.Size(39, 34);
            this.Button3.TabIndex = 7;
            this.Button3.UseVisualStyleBackColor = false;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Button2
            // 
            this.Button2.BackColor = System.Drawing.Color.LimeGreen;
            this.Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.ForeColor = System.Drawing.Color.Black;
            this.Button2.Image = ((System.Drawing.Image)(resources.GetObject("Button2.Image")));
            this.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button2.Location = new System.Drawing.Point(265, 64);
            this.Button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Button2.Name = "Button2";
            this.Button2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Button2.Size = new System.Drawing.Size(116, 34);
            this.Button2.TabIndex = 7;
            this.Button2.Text = "حفظ S";
            this.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click_1);
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.Salmon;
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.ForeColor = System.Drawing.Color.Black;
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.Location = new System.Drawing.Point(156, 25);
            this.btnNew.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNew.Name = "btnNew";
            this.btnNew.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnNew.Size = new System.Drawing.Size(83, 34);
            this.btnNew.TabIndex = 0;
            this.btnNew.Text = "جديد";
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LimeGreen;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.Black;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(385, 25);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSave.Size = new System.Drawing.Size(171, 34);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = " حفظ + طباعة  A4";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Gold;
            this.button5.BackgroundImage = global::Accounting_System.Properties.Resources.Actions_user_group_new_icon;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(35, 25);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(36, 30);
            this.button5.TabIndex = 338;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.Gold;
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button1.Image = ((System.Drawing.Image)(resources.GetObject("Button1.Image")));
            this.Button1.Location = new System.Drawing.Point(77, 57);
            this.Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(36, 26);
            this.Button1.TabIndex = 2;
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.Gold;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Image = ((System.Drawing.Image)(resources.GetObject("btnSelect.Image")));
            this.btnSelect.Location = new System.Drawing.Point(77, 27);
            this.btnSelect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(36, 26);
            this.btnSelect.TabIndex = 3;
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnScanItems
            // 
            this.btnScanItems.BackColor = System.Drawing.SystemColors.Control;
            this.btnScanItems.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnScanItems.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnScanItems.ForeColor = System.Drawing.Color.Black;
            this.btnScanItems.Image = ((System.Drawing.Image)(resources.GetObject("btnScanItems.Image")));
            this.btnScanItems.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnScanItems.Location = new System.Drawing.Point(293, 494);
            this.btnScanItems.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnScanItems.Name = "btnScanItems";
            this.btnScanItems.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnScanItems.Size = new System.Drawing.Size(157, 31);
            this.btnScanItems.TabIndex = 7;
            this.btnScanItems.Text = "الماسح الضوئي";
            this.btnScanItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnScanItems.UseVisualStyleBackColor = true;
            this.btnScanItems.Visible = false;
            // 
            // Plimit
            // 
            this.Plimit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.Plimit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.Plimit.BackColor = System.Drawing.Color.Honeydew;
            this.Plimit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Plimit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Plimit.Location = new System.Drawing.Point(334, -14);
            this.Plimit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Plimit.Name = "Plimit";
            this.Plimit.Size = new System.Drawing.Size(181, 30);
            this.Plimit.TabIndex = 339;
            this.Plimit.WordWrap = false;
            // 
            // DataGridViewTextBoxColumn1
            // 
            this.DataGridViewTextBoxColumn1.HeaderText = "PID";
            this.DataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1";
            this.DataGridViewTextBoxColumn1.ReadOnly = true;
            this.DataGridViewTextBoxColumn1.Visible = false;
            // 
            // DataGridViewTextBoxColumn2
            // 
            this.DataGridViewTextBoxColumn2.HeaderText = "كود الصنف";
            this.DataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2";
            this.DataGridViewTextBoxColumn2.ReadOnly = true;
            this.DataGridViewTextBoxColumn2.Visible = false;
            // 
            // DataGridViewTextBoxColumn3
            // 
            this.DataGridViewTextBoxColumn3.HeaderText = "اسم الصنف";
            this.DataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3";
            this.DataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // DataGridViewTextBoxColumn4
            // 
            this.DataGridViewTextBoxColumn4.HeaderText = "الباركود";
            this.DataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4";
            this.DataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // DataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle172.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.DataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle172;
            this.DataGridViewTextBoxColumn5.HeaderText = "سعر التكلفة";
            this.DataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5";
            this.DataGridViewTextBoxColumn5.ReadOnly = true;
            this.DataGridViewTextBoxColumn5.Visible = false;
            // 
            // DataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle173.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.DataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle173;
            this.DataGridViewTextBoxColumn6.HeaderText = "السعر";
            this.DataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6";
            this.DataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // DataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle174.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.DataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle174;
            this.DataGridViewTextBoxColumn7.HeaderText = "الخصم";
            this.DataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7";
            this.DataGridViewTextBoxColumn7.ReadOnly = true;
            this.DataGridViewTextBoxColumn7.Visible = false;
            // 
            // DataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle175.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.DataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle175;
            this.DataGridViewTextBoxColumn8.HeaderText = "الضريبة";
            this.DataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8";
            this.DataGridViewTextBoxColumn8.ReadOnly = true;
            this.DataGridViewTextBoxColumn8.Visible = false;
            // 
            // DataGridViewTextBoxColumn9
            // 
            dataGridViewCellStyle176.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.DataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle176;
            this.DataGridViewTextBoxColumn9.HeaderText = "الكمية المتوفرة";
            this.DataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9";
            this.DataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "سعرالجملة";
            this.Column18.MinimumWidth = 6;
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Visible = false;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "حد السعر";
            this.Column19.MinimumWidth = 6;
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            // 
            // POS
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1605, 772);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.TextBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "POS";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "شاشة البيع";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.POS_Load);
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.Panel4.ResumeLayout(false);
            this.Panel4.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).EndInit();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        internal System.Windows.Forms.Timer Timer2;
        internal System.Windows.Forms.ToolTip ToolTip1;
        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Button btnScanItems;
        internal System.Windows.Forms.TextBox txtCostPrice;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox txtMargin;
        internal System.Windows.Forms.Button btnClose;
        internal System.Windows.Forms.Button btnMinimize;
        internal System.Windows.Forms.Button btnMaximise;
        internal System.Windows.Forms.Button btnKeyboard;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.Button button5;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtInvoiceNo;
        internal System.Windows.Forms.TextBox txtSalesman;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Button btnSelect;
        internal System.Windows.Forms.TextBox txtCustomerName;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.TextBox txtContactNo;
        internal System.Windows.Forms.Button btnGetData;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnUpdate;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Button btnNew;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button btnPrint;
        internal System.Windows.Forms.TextBox txtRemarks;
        internal System.Windows.Forms.GroupBox GroupBox5;
        public System.Windows.Forms.TextBox txtBarcode;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.TextBox txtTotalAmount;
        internal System.Windows.Forms.TextBox txtQty;
        internal System.Windows.Forms.TextBox txtProductName;
        internal System.Windows.Forms.TextBox txtVATAmount;
        internal System.Windows.Forms.TextBox txtDiscountAmount;
        internal System.Windows.Forms.TextBox txtAmount;
        internal System.Windows.Forms.TextBox txtSellingPrice;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Button btnListReset;
        internal System.Windows.Forms.Button btnRemove;
        internal System.Windows.Forms.Button btnSelectionInv;
        internal System.Windows.Forms.Button btnListUpdate;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.TextBox txtDiscountPer;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Button btnAdd;
        internal System.Windows.Forms.TextBox txtVAT;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.TextBox txtGrandTotal;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.TextBox txtPaymentDue;
        internal System.Windows.Forms.TextBox txtTotalPayment;
        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.Label Label35;
        internal System.Windows.Forms.TextBox txtCommissionPer;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.TextBox txtCheck;
        internal System.Windows.Forms.Button btnListReset1;
        internal System.Windows.Forms.DateTimePicker dtpPaymentDate;
        internal System.Windows.Forms.Button btnListUpdate1;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox txtPayment;
        internal System.Windows.Forms.ComboBox cmbPaymentMode;
        internal System.Windows.Forms.Button btnRemove1;
        internal System.Windows.Forms.Button btnAdd1;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox txtProductCode;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox txtCustomerID;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.DataGridView DataGridView2;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        internal System.Windows.Forms.TextBox txtSalesmanID;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label lblUser1;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Label lblDateTime;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label lblUserType;
        internal System.Windows.Forms.Label lblUser;
        internal System.Windows.Forms.TextBox txtCID;
        internal System.Windows.Forms.TextBox txtProductID;
        internal System.Windows.Forms.TextBox txtCustomerType;
        internal System.Windows.Forms.TextBox txtID;
        internal System.Windows.Forms.TextBox txtTotalQty;
        internal System.Windows.Forms.TextBox txtSM_ID;
        internal System.Windows.Forms.Label lblSet;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Button button4;
        internal System.Windows.Forms.Button button6;
        public System.Windows.Forms.DataGridView dataGridView3;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        internal System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        public System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        internal System.Windows.Forms.DataGridView dgw;
        internal System.Windows.Forms.Button button7;
        internal System.Windows.Forms.TextBox Plimit;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
    }
}