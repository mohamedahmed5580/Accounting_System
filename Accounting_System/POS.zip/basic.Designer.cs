﻿namespace Accounting_System
{
    partial class basic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(basic));
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.اToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جهاتالاتصالToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.منادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جهاتالاتصالToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.اعداداتالرسائلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اعداداتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اعداداتالايميلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نسخاحطياتيToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نسخToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الاشعاراتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الاداواتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الالهالحاسبةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المزكرةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.محررالنصوصToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اوفيسToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مديرالمهامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معلوماتالنظامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عنالشركهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الشركىToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المبرمجينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.Label1 = new System.Windows.Forms.Label();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnGetData = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.Label6 = new System.Windows.Forms.Label();
            this.txtReorderPoint = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtFeatures = new System.Windows.Forms.TextBox();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.Browse = new System.Windows.Forms.Button();
            this.cmbSubCategory = new System.Windows.Forms.ComboBox();
            this.BRemove = new System.Windows.Forms.Button();
            this.txtCostPrice = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtSellingPrice = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.txtVAT = new System.Windows.Forms.TextBox();
            this.dgw = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.txtOpeningStock = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.Button5 = new System.Windows.Forms.Button();
            this.dtpManufacturingDate = new System.Windows.Forms.DateTimePicker();
            this.dtpExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.Button6 = new System.Windows.Forms.Button();
            this.Label22 = new System.Windows.Forms.Label();
            this.Label23 = new System.Windows.Forms.Label();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.txtSellingPrice2 = new System.Windows.Forms.TextBox();
            this.Label24 = new System.Windows.Forms.Label();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblUserType = new System.Windows.Forms.Label();
            this.gunaPanel16 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel15 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel13 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel12 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel14 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel10 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel11 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel7 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel6 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel5 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel8 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel4 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel9 = new Guna.UI.WinForms.GunaPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.Timer_Sidebar_Menu = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.btnSalesmanMaster = new System.Windows.Forms.Button();
            this.btnProductMaster = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.btnCreditCustomer = new System.Windows.Forms.Button();
            this.btnPurchaseReturn = new System.Windows.Forms.Button();
            this.btnWallet = new System.Windows.Forms.Button();
            this.btnSalesReturn = new System.Windows.Forms.Button();
            this.btnPurchase = new System.Windows.Forms.Button();
            this.btnBarcodeLabelPrinting = new System.Windows.Forms.Button();
            this.BtnVoucher = new System.Windows.Forms.Button();
            this.btnBankReconciliation = new System.Windows.Forms.Button();
            this.btnPayroll = new System.Windows.Forms.Button();
            this.btnAccountingReports = new System.Windows.Forms.Button();
            this.btnStockAdjustment = new System.Windows.Forms.Button();
            this.btnStockTransfer_Issue = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btnPOSRecord = new System.Windows.Forms.Button();
            this.btnPOSReport = new System.Windows.Forms.Button();
            this.btnWorkPeriod = new System.Windows.Forms.Button();
            this.btnPurchaseOrder = new System.Windows.Forms.Button();
            this.gunaButton11 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton10 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton14 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton15 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton13 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton12 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton28 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton22 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton23 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton24 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton25 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton26 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton27 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton19 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton20 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton21 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton18 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton17 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton16 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton9 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.Orders_Button = new Guna.UI.WinForms.GunaButton();
            this.Home_Button = new Guna.UI.WinForms.GunaButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Menu_Button = new Guna.UI.WinForms.GunaButton();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.مرتجعمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةالعملاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةمناديبالمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.قائمةالاصنافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةالموردينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةدفعاتالموردينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةفواتيرالشراءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.قائمةالخدماتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةفواتيرالخدماتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةعروضالاسعارToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قائمةالرسائلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.قائمةفواتيرالبيعToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبيعاتكلصنفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.احصائياتعامةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.حالةالمخزونToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المشترياتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المصروفاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الأرباحToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.دفتراليوميةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.يوميةالمشترياتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اليوميةالعامةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كشفحسابتاجرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كشفحسابعميلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ارصدةالزبائنالجميعToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كشفحسابمندوبToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كشفمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عمولةمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ميزاالمراجعةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.شروطالائتمانللزبائنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بياناتشروطالائتمانللزبائنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الضرائبToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.التقريرالعامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.Picture = new System.Windows.Forms.PictureBox();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.SideBar = new System.Windows.Forms.FlowLayoutPanel();
            this.gunaButton29 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton30 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton31 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton32 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton33 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton34 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton35 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton36 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton37 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton38 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton39 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton40 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton41 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton43 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton44 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton45 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton46 = new Guna.UI.WinForms.GunaButton();
            this.menuStrip2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgw)).BeginInit();
            this.toolStripContainer1.SuspendLayout();
            this.gunaPanel16.SuspendLayout();
            this.gunaPanel15.SuspendLayout();
            this.gunaPanel13.SuspendLayout();
            this.gunaPanel12.SuspendLayout();
            this.gunaPanel14.SuspendLayout();
            this.gunaPanel10.SuspendLayout();
            this.gunaPanel11.SuspendLayout();
            this.gunaPanel7.SuspendLayout();
            this.gunaPanel6.SuspendLayout();
            this.gunaPanel5.SuspendLayout();
            this.gunaPanel8.SuspendLayout();
            this.gunaPanel4.SuspendLayout();
            this.gunaPanel3.SuspendLayout();
            this.gunaPanel2.SuspendLayout();
            this.gunaPanel9.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture)).BeginInit();
            this.SideBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem27,
            this.toolStripMenuItem33,
            this.toolStripMenuItem25,
            this.toolStripMenuItem29,
            this.toolStripMenuItem23,
            this.toolStripMenuItem21,
            this.toolStripMenuItem19,
            this.toolStripMenuItem17,
            this.toolStripMenuItem15,
            this.toolStripMenuItem9,
            this.toolStripMenuItem7,
            this.toolStripMenuItem5,
            this.toolStripMenuItem1});
            this.menuStrip2.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStrip2.Location = new System.Drawing.Point(498, 44);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(4);
            this.menuStrip2.ShowItemToolTips = true;
            this.menuStrip2.Size = new System.Drawing.Size(1246, 84);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.اToolStripMenuItem,
            this.الاداواتToolStripMenuItem,
            this.عنالشركهToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1924, 28);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // اToolStripMenuItem
            // 
            this.اToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.جهاتالاتصالToolStripMenuItem,
            this.منادToolStripMenuItem,
            this.جهاتالاتصالToolStripMenuItem1,
            this.اعداداتالرسائلToolStripMenuItem,
            this.اعداداتToolStripMenuItem,
            this.اعداداتالايميلToolStripMenuItem,
            this.نسخاحطياتيToolStripMenuItem,
            this.نسخToolStripMenuItem,
            this.المستخدمينToolStripMenuItem,
            this.الاشعاراتToolStripMenuItem});
            this.اToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.اToolStripMenuItem.Name = "اToolStripMenuItem";
            this.اToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.اToolStripMenuItem.RightToLeftAutoMirrorImage = true;
            this.اToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
            this.اToolStripMenuItem.Text = "الاعدادات الرئيسية";
            // 
            // جهاتالاتصالToolStripMenuItem
            // 
            this.جهاتالاتصالToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.جهاتالاتصالToolStripMenuItem.Name = "جهاتالاتصالToolStripMenuItem";
            this.جهاتالاتصالToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.جهاتالاتصالToolStripMenuItem.Text = "ادخال بيانات الشركة";
            this.جهاتالاتصالToolStripMenuItem.Click += new System.EventHandler(this.جهاتالاتصالToolStripMenuItem_Click);
            // 
            // منادToolStripMenuItem
            // 
            this.منادToolStripMenuItem.Name = "منادToolStripMenuItem";
            this.منادToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.منادToolStripMenuItem.Text = "مناديب المبيعات";
            this.منادToolStripMenuItem.Visible = false;
            // 
            // جهاتالاتصالToolStripMenuItem1
            // 
            this.جهاتالاتصالToolStripMenuItem1.Name = "جهاتالاتصالToolStripMenuItem1";
            this.جهاتالاتصالToolStripMenuItem1.Size = new System.Drawing.Size(237, 26);
            this.جهاتالاتصالToolStripMenuItem1.Text = "جهات الاتصال";
            this.جهاتالاتصالToolStripMenuItem1.Visible = false;
            // 
            // اعداداتالرسائلToolStripMenuItem
            // 
            this.اعداداتالرسائلToolStripMenuItem.Name = "اعداداتالرسائلToolStripMenuItem";
            this.اعداداتالرسائلToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.اعداداتالرسائلToolStripMenuItem.Text = "اعدادات الرسائل";
            this.اعداداتالرسائلToolStripMenuItem.Visible = false;
            // 
            // اعداداتToolStripMenuItem
            // 
            this.اعداداتToolStripMenuItem.Name = "اعداداتToolStripMenuItem";
            this.اعداداتToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.اعداداتToolStripMenuItem.Text = "اعدادات السيرفر";
            this.اعداداتToolStripMenuItem.Visible = false;
            // 
            // اعداداتالايميلToolStripMenuItem
            // 
            this.اعداداتالايميلToolStripMenuItem.Name = "اعداداتالايميلToolStripMenuItem";
            this.اعداداتالايميلToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.اعداداتالايميلToolStripMenuItem.Text = "اعدادات الايميل";
            this.اعداداتالايميلToolStripMenuItem.Visible = false;
            // 
            // نسخاحطياتيToolStripMenuItem
            // 
            this.نسخاحطياتيToolStripMenuItem.Name = "نسخاحطياتيToolStripMenuItem";
            this.نسخاحطياتيToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.نسخاحطياتيToolStripMenuItem.Text = "نسخ احتياطي";
            this.نسخاحطياتيToolStripMenuItem.Visible = false;
            // 
            // نسخToolStripMenuItem
            // 
            this.نسخToolStripMenuItem.Name = "نسخToolStripMenuItem";
            this.نسخToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.نسخToolStripMenuItem.Text = "استرجاع نسخه احتياطيه";
            this.نسخToolStripMenuItem.Visible = false;
            // 
            // المستخدمينToolStripMenuItem
            // 
            this.المستخدمينToolStripMenuItem.Name = "المستخدمينToolStripMenuItem";
            this.المستخدمينToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.المستخدمينToolStripMenuItem.Text = "المستخدمين";
            this.المستخدمينToolStripMenuItem.Click += new System.EventHandler(this.المستخدمينToolStripMenuItem_Click);
            // 
            // الاشعاراتToolStripMenuItem
            // 
            this.الاشعاراتToolStripMenuItem.Name = "الاشعاراتToolStripMenuItem";
            this.الاشعاراتToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.الاشعاراتToolStripMenuItem.Text = "الاشعارات";
            this.الاشعاراتToolStripMenuItem.Click += new System.EventHandler(this.الاشعاراتToolStripMenuItem_Click);
            // 
            // الاداواتToolStripMenuItem
            // 
            this.الاداواتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الالهالحاسبةToolStripMenuItem,
            this.المزكرةToolStripMenuItem,
            this.محررالنصوصToolStripMenuItem,
            this.اوفيسToolStripMenuItem,
            this.مديرالمهامToolStripMenuItem,
            this.معلوماتالنظامToolStripMenuItem});
            this.الاداواتToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.الاداواتToolStripMenuItem.Name = "الاداواتToolStripMenuItem";
            this.الاداواتToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.الاداواتToolStripMenuItem.Text = "الاداوات";
            // 
            // الالهالحاسبةToolStripMenuItem
            // 
            this.الالهالحاسبةToolStripMenuItem.Name = "الالهالحاسبةToolStripMenuItem";
            this.الالهالحاسبةToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.الالهالحاسبةToolStripMenuItem.Text = "الاله الحاسبة";
            this.الالهالحاسبةToolStripMenuItem.Click += new System.EventHandler(this.الالهالحاسبةToolStripMenuItem_Click);
            // 
            // المزكرةToolStripMenuItem
            // 
            this.المزكرةToolStripMenuItem.Name = "المزكرةToolStripMenuItem";
            this.المزكرةToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.المزكرةToolStripMenuItem.Text = "المذكرة";
            this.المزكرةToolStripMenuItem.Visible = false;
            // 
            // محررالنصوصToolStripMenuItem
            // 
            this.محررالنصوصToolStripMenuItem.Name = "محررالنصوصToolStripMenuItem";
            this.محررالنصوصToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.محررالنصوصToolStripMenuItem.Text = "محرر النصوص";
            this.محررالنصوصToolStripMenuItem.Visible = false;
            // 
            // اوفيسToolStripMenuItem
            // 
            this.اوفيسToolStripMenuItem.Name = "اوفيسToolStripMenuItem";
            this.اوفيسToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.اوفيسToolStripMenuItem.Text = "اوفيس وورد";
            this.اوفيسToolStripMenuItem.Visible = false;
            // 
            // مديرالمهامToolStripMenuItem
            // 
            this.مديرالمهامToolStripMenuItem.Name = "مديرالمهامToolStripMenuItem";
            this.مديرالمهامToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.مديرالمهامToolStripMenuItem.Text = "مدير المهام";
            this.مديرالمهامToolStripMenuItem.Visible = false;
            // 
            // معلوماتالنظامToolStripMenuItem
            // 
            this.معلوماتالنظامToolStripMenuItem.Name = "معلوماتالنظامToolStripMenuItem";
            this.معلوماتالنظامToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.معلوماتالنظامToolStripMenuItem.Text = "معلومات النظام";
            this.معلوماتالنظامToolStripMenuItem.Visible = false;
            // 
            // عنالشركهToolStripMenuItem
            // 
            this.عنالشركهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الشركىToolStripMenuItem,
            this.المبرمجينToolStripMenuItem});
            this.عنالشركهToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.عنالشركهToolStripMenuItem.Name = "عنالشركهToolStripMenuItem";
            this.عنالشركهToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.عنالشركهToolStripMenuItem.Text = "معلومات عننا";
            this.عنالشركهToolStripMenuItem.Click += new System.EventHandler(this.عنالشركهToolStripMenuItem_Click);
            // 
            // الشركىToolStripMenuItem
            // 
            this.الشركىToolStripMenuItem.Name = "الشركىToolStripMenuItem";
            this.الشركىToolStripMenuItem.Size = new System.Drawing.Size(153, 26);
            this.الشركىToolStripMenuItem.Text = "الشركة";
            this.الشركىToolStripMenuItem.Click += new System.EventHandler(this.الشركىToolStripMenuItem_Click);
            // 
            // المبرمجينToolStripMenuItem
            // 
            this.المبرمجينToolStripMenuItem.Name = "المبرمجينToolStripMenuItem";
            this.المبرمجينToolStripMenuItem.Size = new System.Drawing.Size(153, 26);
            this.المبرمجينToolStripMenuItem.Text = "المبرمجين";
            this.المبرمجينToolStripMenuItem.Click += new System.EventHandler(this.المبرمجينToolStripMenuItem_Click);
            // 
            // OpenFileDialog1
            // 
            this.OpenFileDialog1.FileName = "OpenFileDialog1";
            // 
            // Panel2
            // 
            this.Panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Panel2.Location = new System.Drawing.Point(-5, 5);
            this.Panel2.Margin = new System.Windows.Forms.Padding(4);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(1392, 76);
            this.Panel2.TabIndex = 0;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.White;
            this.Label1.Location = new System.Drawing.Point(631, 27);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(140, 29);
            this.Label1.TabIndex = 0;
            // 
            // Panel3
            // 
            this.Panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel3.Location = new System.Drawing.Point(1239, 88);
            this.Panel3.Margin = new System.Windows.Forms.Padding(4);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(147, 307);
            this.Panel3.TabIndex = 2;
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.ForestGreen;
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.ForeColor = System.Drawing.Color.White;
            this.btnNew.Location = new System.Drawing.Point(12, 13);
            this.btnNew.Margin = new System.Windows.Forms.Padding(4);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(109, 39);
            this.btnNew.TabIndex = 0;
            this.btnNew.Text = "جديد";
            this.btnNew.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(12, 60);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(109, 39);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "حفظ";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.SkyBlue;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(12, 106);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(109, 39);
            this.btnUpdate.TabIndex = 2;
            this.btnUpdate.Text = "تعديل";
            this.btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Firebrick;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(12, 151);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(109, 39);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "حذف";
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnGetData
            // 
            this.btnGetData.BackColor = System.Drawing.Color.Gold;
            this.btnGetData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGetData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetData.Location = new System.Drawing.Point(12, 198);
            this.btnGetData.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetData.Name = "btnGetData";
            this.btnGetData.Size = new System.Drawing.Size(109, 39);
            this.btnGetData.TabIndex = 5;
            this.btnGetData.Text = "بحث";
            this.btnGetData.UseVisualStyleBackColor = false;
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.LightGreen;
            this.Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.Location = new System.Drawing.Point(7, 247);
            this.Button1.Margin = new System.Windows.Forms.Padding(4);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(123, 39);
            this.Button1.TabIndex = 6;
            this.Button1.Text = "مراكز البيع";
            this.Button1.UseVisualStyleBackColor = false;
            // 
            // Panel4
            // 
            this.Panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Panel4.Location = new System.Drawing.Point(-6, 88);
            this.Panel4.Margin = new System.Windows.Forms.Padding(4);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(1235, 666);
            this.Panel4.TabIndex = 0;
            // 
            // Label6
            // 
            this.Label6.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.ForeColor = System.Drawing.Color.White;
            this.Label6.Location = new System.Drawing.Point(544, 17);
            this.Label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(176, 32);
            this.Label6.TabIndex = 12;
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtReorderPoint
            // 
            this.txtReorderPoint.BackColor = System.Drawing.Color.White;
            this.txtReorderPoint.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtReorderPoint.Location = new System.Drawing.Point(382, 156);
            this.txtReorderPoint.Margin = new System.Windows.Forms.Padding(4);
            this.txtReorderPoint.Name = "txtReorderPoint";
            this.txtReorderPoint.Size = new System.Drawing.Size(147, 30);
            this.txtReorderPoint.TabIndex = 9;
            this.txtReorderPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label7
            // 
            this.Label7.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(1064, 386);
            this.Label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(161, 32);
            this.Label7.TabIndex = 13;
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label5
            // 
            this.Label5.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.White;
            this.Label5.Location = new System.Drawing.Point(1056, 224);
            this.Label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(161, 33);
            this.Label5.TabIndex = 11;
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtFeatures
            // 
            this.txtFeatures.BackColor = System.Drawing.Color.White;
            this.txtFeatures.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtFeatures.Location = new System.Drawing.Point(731, 431);
            this.txtFeatures.Margin = new System.Windows.Forms.Padding(4);
            this.txtFeatures.Multiline = true;
            this.txtFeatures.Name = "txtFeatures";
            this.txtFeatures.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtFeatures.Size = new System.Drawing.Size(481, 150);
            this.txtFeatures.TabIndex = 4;
            // 
            // txtProductCode
            // 
            this.txtProductCode.BackColor = System.Drawing.SystemColors.Control;
            this.txtProductCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtProductCode.Location = new System.Drawing.Point(814, 72);
            this.txtProductCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.ReadOnly = true;
            this.txtProductCode.Size = new System.Drawing.Size(229, 30);
            this.txtProductCode.TabIndex = 0;
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.White;
            this.Label3.Location = new System.Drawing.Point(1056, 72);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(161, 32);
            this.Label3.TabIndex = 0;
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(1056, 176);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(161, 32);
            this.Label2.TabIndex = 5;
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label10
            // 
            this.Label10.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.ForeColor = System.Drawing.Color.White;
            this.Label10.Location = new System.Drawing.Point(544, 156);
            this.Label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(176, 32);
            this.Label10.TabIndex = 21;
            this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label4
            // 
            this.Label4.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.White;
            this.Label4.Location = new System.Drawing.Point(1056, 279);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(161, 32);
            this.Label4.TabIndex = 24;
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Location = new System.Drawing.Point(814, 224);
            this.cmbCategory.Margin = new System.Windows.Forms.Padding(4);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(229, 31);
            this.cmbCategory.TabIndex = 2;
            // 
            // Browse
            // 
            this.Browse.BackColor = System.Drawing.Color.DodgerBlue;
            this.Browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Browse.ForeColor = System.Drawing.Color.White;
            this.Browse.Location = new System.Drawing.Point(166, 255);
            this.Browse.Margin = new System.Windows.Forms.Padding(4);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(125, 39);
            this.Browse.TabIndex = 17;
            this.Browse.Text = "من ملف";
            this.Browse.UseVisualStyleBackColor = false;
            // 
            // cmbSubCategory
            // 
            this.cmbSubCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubCategory.Enabled = false;
            this.cmbSubCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.cmbSubCategory.FormattingEnabled = true;
            this.cmbSubCategory.Location = new System.Drawing.Point(814, 279);
            this.cmbSubCategory.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSubCategory.Name = "cmbSubCategory";
            this.cmbSubCategory.Size = new System.Drawing.Size(229, 31);
            this.cmbSubCategory.TabIndex = 3;
            // 
            // BRemove
            // 
            this.BRemove.BackColor = System.Drawing.Color.Firebrick;
            this.BRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BRemove.ForeColor = System.Drawing.Color.White;
            this.BRemove.Location = new System.Drawing.Point(8, 255);
            this.BRemove.Margin = new System.Windows.Forms.Padding(4);
            this.BRemove.Name = "BRemove";
            this.BRemove.Size = new System.Drawing.Size(131, 39);
            this.BRemove.TabIndex = 18;
            this.BRemove.Text = "حذف";
            this.BRemove.UseVisualStyleBackColor = false;
            // 
            // txtCostPrice
            // 
            this.txtCostPrice.BackColor = System.Drawing.Color.White;
            this.txtCostPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtCostPrice.Location = new System.Drawing.Point(382, 17);
            this.txtCostPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtCostPrice.Name = "txtCostPrice";
            this.txtCostPrice.Size = new System.Drawing.Size(147, 30);
            this.txtCostPrice.TabIndex = 5;
            this.txtCostPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtProductName
            // 
            this.txtProductName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtProductName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtProductName.Location = new System.Drawing.Point(814, 176);
            this.txtProductName.Margin = new System.Windows.Forms.Padding(4);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(229, 30);
            this.txtProductName.TabIndex = 1;
            // 
            // txtSellingPrice
            // 
            this.txtSellingPrice.BackColor = System.Drawing.Color.White;
            this.txtSellingPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtSellingPrice.Location = new System.Drawing.Point(382, 69);
            this.txtSellingPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtSellingPrice.Name = "txtSellingPrice";
            this.txtSellingPrice.Size = new System.Drawing.Size(147, 30);
            this.txtSellingPrice.TabIndex = 7;
            this.txtSellingPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label8
            // 
            this.Label8.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(544, 69);
            this.Label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(176, 32);
            this.Label8.TabIndex = 300;
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label9
            // 
            this.Label9.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(544, 261);
            this.Label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(176, 32);
            this.Label9.TabIndex = 301;
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label11
            // 
            this.Label11.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.White;
            this.Label11.Location = new System.Drawing.Point(544, 316);
            this.Label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(176, 32);
            this.Label11.TabIndex = 302;
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.Color.White;
            this.txtDiscount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtDiscount.Location = new System.Drawing.Point(382, 262);
            this.txtDiscount.Margin = new System.Windows.Forms.Padding(4);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(147, 30);
            this.txtDiscount.TabIndex = 6;
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtVAT
            // 
            this.txtVAT.BackColor = System.Drawing.Color.White;
            this.txtVAT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtVAT.Location = new System.Drawing.Point(382, 316);
            this.txtVAT.Margin = new System.Windows.Forms.Padding(4);
            this.txtVAT.Name = "txtVAT";
            this.txtVAT.Size = new System.Drawing.Size(147, 30);
            this.txtVAT.TabIndex = 8;
            this.txtVAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dgw
            // 
            this.dgw.AllowUserToAddRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FloralWhite;
            this.dgw.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgw.BackgroundColor = System.Drawing.Color.White;
            this.dgw.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.CadetBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgw.ColumnHeadersHeight = 24;
            this.dgw.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgw.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgw.EnableHeadersVisualStyles = false;
            this.dgw.Location = new System.Drawing.Point(8, 301);
            this.dgw.Margin = new System.Windows.Forms.Padding(4);
            this.dgw.MultiSelect = false;
            this.dgw.Name = "dgw";
            this.dgw.ReadOnly = true;
            this.dgw.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.CadetBlue;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgw.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgw.RowHeadersVisible = false;
            this.dgw.RowHeadersWidth = 25;
            this.dgw.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.White;
            this.dgw.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgw.RowTemplate.Height = 180;
            this.dgw.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgw.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgw.Size = new System.Drawing.Size(283, 235);
            this.dgw.TabIndex = 322;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Photo";
            this.Column1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(166, 544);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(125, 39);
            this.btnAdd.TabIndex = 19;
            this.btnAdd.Text = "إضافة";
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.Firebrick;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.ForeColor = System.Drawing.Color.White;
            this.btnRemove.Location = new System.Drawing.Point(8, 544);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(125, 39);
            this.btnRemove.TabIndex = 20;
            this.btnRemove.Text = "حذف";
            this.btnRemove.UseVisualStyleBackColor = false;
            // 
            // txtOpeningStock
            // 
            this.txtOpeningStock.BackColor = System.Drawing.Color.White;
            this.txtOpeningStock.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtOpeningStock.Location = new System.Drawing.Point(382, 207);
            this.txtOpeningStock.Margin = new System.Windows.Forms.Padding(4);
            this.txtOpeningStock.Name = "txtOpeningStock";
            this.txtOpeningStock.Size = new System.Drawing.Size(147, 30);
            this.txtOpeningStock.TabIndex = 10;
            this.txtOpeningStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label12
            // 
            this.Label12.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.ForeColor = System.Drawing.Color.White;
            this.Label12.Location = new System.Drawing.Point(544, 207);
            this.Label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(176, 32);
            this.Label12.TabIndex = 325;
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtBarcode
            // 
            this.txtBarcode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtBarcode.Location = new System.Drawing.Point(814, 124);
            this.txtBarcode.Margin = new System.Windows.Forms.Padding(4);
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(229, 30);
            this.txtBarcode.TabIndex = 328;
            // 
            // Label13
            // 
            this.Label13.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.ForeColor = System.Drawing.Color.White;
            this.Label13.Location = new System.Drawing.Point(1056, 124);
            this.Label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(161, 32);
            this.Label13.TabIndex = 329;
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.ForeColor = System.Drawing.Color.Red;
            this.Label14.Location = new System.Drawing.Point(730, 183);
            this.Label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(24, 26);
            this.Label14.TabIndex = 330;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.ForeColor = System.Drawing.Color.Red;
            this.Label15.Location = new System.Drawing.Point(347, 159);
            this.Label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(24, 26);
            this.Label15.TabIndex = 331;
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.ForeColor = System.Drawing.Color.Red;
            this.Label16.Location = new System.Drawing.Point(730, 287);
            this.Label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(24, 26);
            this.Label16.TabIndex = 332;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.ForeColor = System.Drawing.Color.Red;
            this.Label17.Location = new System.Drawing.Point(730, 226);
            this.Label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(24, 26);
            this.Label17.TabIndex = 333;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.ForeColor = System.Drawing.Color.Red;
            this.Label18.Location = new System.Drawing.Point(347, 74);
            this.Label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(24, 26);
            this.Label18.TabIndex = 334;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.ForeColor = System.Drawing.Color.Red;
            this.Label19.Location = new System.Drawing.Point(347, 18);
            this.Label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(24, 26);
            this.Label19.TabIndex = 335;
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label20.ForeColor = System.Drawing.Color.Red;
            this.Label20.Location = new System.Drawing.Point(730, 129);
            this.Label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(24, 26);
            this.Label20.TabIndex = 336;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.Label21.Location = new System.Drawing.Point(316, 209);
            this.Label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(43, 24);
            this.Label21.TabIndex = 337;
            // 
            // TextBox1
            // 
            this.TextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.TextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.TextBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox1.Location = new System.Drawing.Point(768, 13);
            this.TextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(361, 30);
            this.TextBox1.TabIndex = 343;
            // 
            // Button5
            // 
            this.Button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Button5.Location = new System.Drawing.Point(1158, 6);
            this.Button5.Margin = new System.Windows.Forms.Padding(4);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(43, 39);
            this.Button5.TabIndex = 344;
            this.Button5.UseVisualStyleBackColor = true;
            // 
            // dtpManufacturingDate
            // 
            this.dtpManufacturingDate.CustomFormat = "dd/MM/yyyy";
            this.dtpManufacturingDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpManufacturingDate.Location = new System.Drawing.Point(382, 369);
            this.dtpManufacturingDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpManufacturingDate.Name = "dtpManufacturingDate";
            this.dtpManufacturingDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpManufacturingDate.RightToLeftLayout = true;
            this.dtpManufacturingDate.Size = new System.Drawing.Size(153, 22);
            this.dtpManufacturingDate.TabIndex = 346;
            // 
            // dtpExpiryDate
            // 
            this.dtpExpiryDate.CustomFormat = "dd/MM/yyyy";
            this.dtpExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpExpiryDate.Location = new System.Drawing.Point(382, 408);
            this.dtpExpiryDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpExpiryDate.Name = "dtpExpiryDate";
            this.dtpExpiryDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpExpiryDate.RightToLeftLayout = true;
            this.dtpExpiryDate.Size = new System.Drawing.Size(153, 22);
            this.dtpExpiryDate.TabIndex = 347;
            // 
            // Button6
            // 
            this.Button6.BackColor = System.Drawing.Color.Goldenrod;
            this.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button6.Location = new System.Drawing.Point(390, 449);
            this.Button6.Margin = new System.Windows.Forms.Padding(4);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(75, 47);
            this.Button6.TabIndex = 352;
            this.Button6.Text = "جديد";
            this.Button6.UseVisualStyleBackColor = false;
            // 
            // Label22
            // 
            this.Label22.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label22.ForeColor = System.Drawing.Color.White;
            this.Label22.Location = new System.Drawing.Point(544, 402);
            this.Label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(176, 32);
            this.Label22.TabIndex = 353;
            this.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label23
            // 
            this.Label23.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label23.ForeColor = System.Drawing.Color.White;
            this.Label23.Location = new System.Drawing.Point(544, 365);
            this.Label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(176, 32);
            this.Label23.TabIndex = 354;
            this.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CheckBox1
            // 
            this.CheckBox1.AutoSize = true;
            this.CheckBox1.Location = new System.Drawing.Point(431, 504);
            this.CheckBox1.Margin = new System.Windows.Forms.Padding(4);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(18, 17);
            this.CheckBox1.TabIndex = 356;
            this.CheckBox1.UseVisualStyleBackColor = true;
            // 
            // txtSellingPrice2
            // 
            this.txtSellingPrice2.BackColor = System.Drawing.Color.White;
            this.txtSellingPrice2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.txtSellingPrice2.Location = new System.Drawing.Point(382, 111);
            this.txtSellingPrice2.Margin = new System.Windows.Forms.Padding(4);
            this.txtSellingPrice2.Name = "txtSellingPrice2";
            this.txtSellingPrice2.Size = new System.Drawing.Size(147, 30);
            this.txtSellingPrice2.TabIndex = 357;
            this.txtSellingPrice2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label24
            // 
            this.Label24.BackColor = System.Drawing.Color.DodgerBlue;
            this.Label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.ForeColor = System.Drawing.Color.White;
            this.Label24.Location = new System.Drawing.Point(544, 111);
            this.Label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(176, 32);
            this.Label24.TabIndex = 358;
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Margin = new System.Windows.Forms.Padding(4);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(1395, 77);
            this.toolStripContainer1.Location = new System.Drawing.Point(423, 32);
            this.toolStripContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(1395, 102);
            this.toolStripContainer1.TabIndex = 11;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(420, 9);
            this.lblUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(36, 16);
            this.lblUser.TabIndex = 313;
            this.lblUser.Text = "User";
            this.lblUser.Visible = false;
            // 
            // lblUserType
            // 
            this.lblUserType.AutoSize = true;
            this.lblUserType.Location = new System.Drawing.Point(352, 9);
            this.lblUserType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserType.Name = "lblUserType";
            this.lblUserType.Size = new System.Drawing.Size(71, 16);
            this.lblUserType.TabIndex = 314;
            this.lblUserType.Text = "User Type";
            this.lblUserType.Visible = false;
            // 
            // gunaPanel16
            // 
            this.gunaPanel16.Controls.Add(this.gunaButton11);
            this.gunaPanel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel16.Location = new System.Drawing.Point(-4, 813);
            this.gunaPanel16.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel16.Name = "gunaPanel16";
            this.gunaPanel16.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel16.TabIndex = 14;
            // 
            // gunaPanel15
            // 
            this.gunaPanel15.Controls.Add(this.gunaButton10);
            this.gunaPanel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel15.Location = new System.Drawing.Point(-4, 755);
            this.gunaPanel15.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel15.Name = "gunaPanel15";
            this.gunaPanel15.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel15.TabIndex = 13;
            // 
            // gunaPanel13
            // 
            this.gunaPanel13.Controls.Add(this.gunaButton4);
            this.gunaPanel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gunaPanel13.Location = new System.Drawing.Point(-4, 697);
            this.gunaPanel13.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel13.Name = "gunaPanel13";
            this.gunaPanel13.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel13.TabIndex = 11;
            // 
            // gunaPanel12
            // 
            this.gunaPanel12.Controls.Add(this.gunaButton7);
            this.gunaPanel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel12.Location = new System.Drawing.Point(-4, 639);
            this.gunaPanel12.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel12.Name = "gunaPanel12";
            this.gunaPanel12.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel12.TabIndex = 10;
            // 
            // gunaPanel14
            // 
            this.gunaPanel14.Controls.Add(this.gunaButton3);
            this.gunaPanel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel14.Location = new System.Drawing.Point(-4, 581);
            this.gunaPanel14.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel14.Name = "gunaPanel14";
            this.gunaPanel14.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel14.TabIndex = 12;
            // 
            // gunaPanel10
            // 
            this.gunaPanel10.Controls.Add(this.gunaButton14);
            this.gunaPanel10.Controls.Add(this.gunaButton15);
            this.gunaPanel10.Controls.Add(this.gunaButton6);
            this.gunaPanel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel10.Location = new System.Drawing.Point(-4, 519);
            this.gunaPanel10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel10.MaximumSize = new System.Drawing.Size(287, 170);
            this.gunaPanel10.MinimumSize = new System.Drawing.Size(278, 54);
            this.gunaPanel10.Name = "gunaPanel10";
            this.gunaPanel10.Size = new System.Drawing.Size(287, 54);
            this.gunaPanel10.TabIndex = 9;
            // 
            // gunaPanel11
            // 
            this.gunaPanel11.Controls.Add(this.gunaButton13);
            this.gunaPanel11.Controls.Add(this.gunaButton12);
            this.gunaPanel11.Controls.Add(this.gunaButton5);
            this.gunaPanel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel11.Location = new System.Drawing.Point(-4, 457);
            this.gunaPanel11.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel11.MaximumSize = new System.Drawing.Size(287, 170);
            this.gunaPanel11.MinimumSize = new System.Drawing.Size(278, 54);
            this.gunaPanel11.Name = "gunaPanel11";
            this.gunaPanel11.Size = new System.Drawing.Size(287, 54);
            this.gunaPanel11.TabIndex = 8;
            // 
            // gunaPanel7
            // 
            this.gunaPanel7.Controls.Add(this.gunaButton43);
            this.gunaPanel7.Controls.Add(this.gunaButton44);
            this.gunaPanel7.Controls.Add(this.gunaButton45);
            this.gunaPanel7.Controls.Add(this.gunaButton46);
            this.gunaPanel7.Controls.Add(this.gunaButton29);
            this.gunaPanel7.Controls.Add(this.gunaButton30);
            this.gunaPanel7.Controls.Add(this.gunaButton31);
            this.gunaPanel7.Controls.Add(this.gunaButton32);
            this.gunaPanel7.Controls.Add(this.gunaButton33);
            this.gunaPanel7.Controls.Add(this.gunaButton34);
            this.gunaPanel7.Controls.Add(this.gunaButton35);
            this.gunaPanel7.Controls.Add(this.gunaButton36);
            this.gunaPanel7.Controls.Add(this.gunaButton37);
            this.gunaPanel7.Controls.Add(this.gunaButton38);
            this.gunaPanel7.Controls.Add(this.gunaButton39);
            this.gunaPanel7.Controls.Add(this.gunaButton40);
            this.gunaPanel7.Controls.Add(this.gunaButton41);
            this.gunaPanel7.Controls.Add(this.gunaButton8);
            this.gunaPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel7.Location = new System.Drawing.Point(-4, 395);
            this.gunaPanel7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel7.MaximumSize = new System.Drawing.Size(278, 520);
            this.gunaPanel7.MinimumSize = new System.Drawing.Size(278, 54);
            this.gunaPanel7.Name = "gunaPanel7";
            this.gunaPanel7.Size = new System.Drawing.Size(278, 54);
            this.gunaPanel7.TabIndex = 6;
            // 
            // gunaPanel6
            // 
            this.gunaPanel6.Controls.Add(this.gunaButton28);
            this.gunaPanel6.Controls.Add(this.gunaButton22);
            this.gunaPanel6.Controls.Add(this.gunaButton23);
            this.gunaPanel6.Controls.Add(this.gunaButton24);
            this.gunaPanel6.Controls.Add(this.gunaButton25);
            this.gunaPanel6.Controls.Add(this.gunaButton26);
            this.gunaPanel6.Controls.Add(this.gunaButton27);
            this.gunaPanel6.Controls.Add(this.gunaButton19);
            this.gunaPanel6.Controls.Add(this.gunaButton20);
            this.gunaPanel6.Controls.Add(this.gunaButton21);
            this.gunaPanel6.Controls.Add(this.gunaButton18);
            this.gunaPanel6.Controls.Add(this.gunaButton17);
            this.gunaPanel6.Controls.Add(this.gunaButton16);
            this.gunaPanel6.Controls.Add(this.gunaButton9);
            this.gunaPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel6.Location = new System.Drawing.Point(-4, 337);
            this.gunaPanel6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel6.MaximumSize = new System.Drawing.Size(280, 410);
            this.gunaPanel6.MinimumSize = new System.Drawing.Size(280, 50);
            this.gunaPanel6.Name = "gunaPanel6";
            this.gunaPanel6.Size = new System.Drawing.Size(280, 50);
            this.gunaPanel6.TabIndex = 4;
            // 
            // gunaPanel5
            // 
            this.gunaPanel5.Controls.Add(this.gunaButton2);
            this.gunaPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel5.Location = new System.Drawing.Point(-4, 279);
            this.gunaPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel5.Name = "gunaPanel5";
            this.gunaPanel5.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel5.TabIndex = 3;
            // 
            // gunaPanel8
            // 
            this.gunaPanel8.Controls.Add(this.gunaButton1);
            this.gunaPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel8.Location = new System.Drawing.Point(-4, 221);
            this.gunaPanel8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel8.Name = "gunaPanel8";
            this.gunaPanel8.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel8.TabIndex = 5;
            // 
            // gunaPanel4
            // 
            this.gunaPanel4.Controls.Add(this.Orders_Button);
            this.gunaPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel4.Location = new System.Drawing.Point(-4, 163);
            this.gunaPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel4.Name = "gunaPanel4";
            this.gunaPanel4.Size = new System.Drawing.Size(287, 50);
            this.gunaPanel4.TabIndex = 2;
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.Controls.Add(this.Home_Button);
            this.gunaPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel3.Location = new System.Drawing.Point(-4, 101);
            this.gunaPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(287, 54);
            this.gunaPanel3.TabIndex = 1;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.Controls.Add(this.gunaPanel9);
            this.gunaPanel2.Location = new System.Drawing.Point(-4, 4);
            this.gunaPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(287, 89);
            this.gunaPanel2.TabIndex = 0;
            // 
            // gunaPanel9
            // 
            this.gunaPanel9.Controls.Add(this.pictureBox1);
            this.gunaPanel9.Controls.Add(this.Menu_Button);
            this.gunaPanel9.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel9.Name = "gunaPanel9";
            this.gunaPanel9.Size = new System.Drawing.Size(287, 70);
            this.gunaPanel9.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.gunaPanel1);
            this.panel1.Location = new System.Drawing.Point(298, 130);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1614, 1025);
            this.panel1.TabIndex = 0;
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.Controls.Add(this.btnSalesmanMaster);
            this.gunaPanel1.Controls.Add(this.btnProductMaster);
            this.gunaPanel1.Controls.Add(this.btnSupplier);
            this.gunaPanel1.Controls.Add(this.btnCreditCustomer);
            this.gunaPanel1.Controls.Add(this.btnPurchaseReturn);
            this.gunaPanel1.Controls.Add(this.btnWallet);
            this.gunaPanel1.Controls.Add(this.btnSalesReturn);
            this.gunaPanel1.Controls.Add(this.btnPurchase);
            this.gunaPanel1.Controls.Add(this.btnBarcodeLabelPrinting);
            this.gunaPanel1.Controls.Add(this.BtnVoucher);
            this.gunaPanel1.Controls.Add(this.btnBankReconciliation);
            this.gunaPanel1.Controls.Add(this.btnPayroll);
            this.gunaPanel1.Controls.Add(this.btnAccountingReports);
            this.gunaPanel1.Controls.Add(this.btnStockAdjustment);
            this.gunaPanel1.Controls.Add(this.btnStockTransfer_Issue);
            this.gunaPanel1.Controls.Add(this.btnPayment);
            this.gunaPanel1.Controls.Add(this.btnPOSRecord);
            this.gunaPanel1.Controls.Add(this.btnPOSReport);
            this.gunaPanel1.Controls.Add(this.btnWorkPeriod);
            this.gunaPanel1.Controls.Add(this.btnPurchaseOrder);
            this.gunaPanel1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaPanel1.Location = new System.Drawing.Point(232, 76);
            this.gunaPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(1092, 656);
            this.gunaPanel1.TabIndex = 2;
            this.gunaPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.gunaPanel1_Paint_1);
            // 
            // Timer_Sidebar_Menu
            // 
            this.Timer_Sidebar_Menu.Tick += new System.EventHandler(this.Timer_Sidebar_Menu_Tick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // btnSalesmanMaster
            // 
            this.btnSalesmanMaster.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalesmanMaster.AutoSize = true;
            this.btnSalesmanMaster.BackColor = System.Drawing.Color.Goldenrod;
            this.btnSalesmanMaster.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesmanMaster.BackgroundImage")));
            this.btnSalesmanMaster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesmanMaster.FlatAppearance.BorderSize = 0;
            this.btnSalesmanMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalesmanMaster.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesmanMaster.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSalesmanMaster.Image = ((System.Drawing.Image)(resources.GetObject("btnSalesmanMaster.Image")));
            this.btnSalesmanMaster.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSalesmanMaster.Location = new System.Drawing.Point(0, 1);
            this.btnSalesmanMaster.Margin = new System.Windows.Forms.Padding(4);
            this.btnSalesmanMaster.Name = "btnSalesmanMaster";
            this.btnSalesmanMaster.Size = new System.Drawing.Size(271, 127);
            this.btnSalesmanMaster.TabIndex = 77;
            this.btnSalesmanMaster.Text = "مناديب المبيعات";
            this.btnSalesmanMaster.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalesmanMaster.UseVisualStyleBackColor = false;
            this.btnSalesmanMaster.Click += new System.EventHandler(this.btnSalesmanMaster_Click);
            // 
            // btnProductMaster
            // 
            this.btnProductMaster.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProductMaster.AutoSize = true;
            this.btnProductMaster.BackColor = System.Drawing.Color.Crimson;
            this.btnProductMaster.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProductMaster.BackgroundImage")));
            this.btnProductMaster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProductMaster.FlatAppearance.BorderSize = 0;
            this.btnProductMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductMaster.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductMaster.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnProductMaster.Image = ((System.Drawing.Image)(resources.GetObject("btnProductMaster.Image")));
            this.btnProductMaster.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnProductMaster.Location = new System.Drawing.Point(824, 1);
            this.btnProductMaster.Margin = new System.Windows.Forms.Padding(4);
            this.btnProductMaster.Name = "btnProductMaster";
            this.btnProductMaster.Size = new System.Drawing.Size(267, 126);
            this.btnProductMaster.TabIndex = 69;
            this.btnProductMaster.Text = "الأصناف";
            this.btnProductMaster.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProductMaster.UseVisualStyleBackColor = false;
            this.btnProductMaster.Click += new System.EventHandler(this.btnProductMaster_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSupplier.AutoSize = true;
            this.btnSupplier.BackColor = System.Drawing.Color.DarkViolet;
            this.btnSupplier.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSupplier.BackgroundImage")));
            this.btnSupplier.FlatAppearance.BorderSize = 0;
            this.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplier.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupplier.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSupplier.Image = ((System.Drawing.Image)(resources.GetObject("btnSupplier.Image")));
            this.btnSupplier.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSupplier.Location = new System.Drawing.Point(276, 1);
            this.btnSupplier.Margin = new System.Windows.Forms.Padding(4);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(267, 127);
            this.btnSupplier.TabIndex = 72;
            this.btnSupplier.Text = "الموردين";
            this.btnSupplier.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSupplier.UseVisualStyleBackColor = false;
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // btnCreditCustomer
            // 
            this.btnCreditCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreditCustomer.AutoSize = true;
            this.btnCreditCustomer.BackColor = System.Drawing.Color.DeepPink;
            this.btnCreditCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCreditCustomer.BackgroundImage")));
            this.btnCreditCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCreditCustomer.FlatAppearance.BorderSize = 0;
            this.btnCreditCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreditCustomer.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreditCustomer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCreditCustomer.Image = ((System.Drawing.Image)(resources.GetObject("btnCreditCustomer.Image")));
            this.btnCreditCustomer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCreditCustomer.Location = new System.Drawing.Point(551, 1);
            this.btnCreditCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreditCustomer.Name = "btnCreditCustomer";
            this.btnCreditCustomer.Size = new System.Drawing.Size(267, 127);
            this.btnCreditCustomer.TabIndex = 83;
            this.btnCreditCustomer.Text = "العملاء";
            this.btnCreditCustomer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCreditCustomer.UseVisualStyleBackColor = false;
            this.btnCreditCustomer.Click += new System.EventHandler(this.btnCreditCustomer_Click);
            // 
            // btnPurchaseReturn
            // 
            this.btnPurchaseReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPurchaseReturn.AutoSize = true;
            this.btnPurchaseReturn.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnPurchaseReturn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPurchaseReturn.BackgroundImage")));
            this.btnPurchaseReturn.FlatAppearance.BorderSize = 0;
            this.btnPurchaseReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchaseReturn.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchaseReturn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPurchaseReturn.Image = ((System.Drawing.Image)(resources.GetObject("btnPurchaseReturn.Image")));
            this.btnPurchaseReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPurchaseReturn.Location = new System.Drawing.Point(1, 133);
            this.btnPurchaseReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnPurchaseReturn.Name = "btnPurchaseReturn";
            this.btnPurchaseReturn.Size = new System.Drawing.Size(267, 126);
            this.btnPurchaseReturn.TabIndex = 70;
            this.btnPurchaseReturn.Text = "مرتجع المشتريات";
            this.btnPurchaseReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPurchaseReturn.UseVisualStyleBackColor = false;
            this.btnPurchaseReturn.Click += new System.EventHandler(this.btnPurchaseReturn_Click);
            // 
            // btnWallet
            // 
            this.btnWallet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWallet.AutoSize = true;
            this.btnWallet.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnWallet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWallet.BackgroundImage")));
            this.btnWallet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWallet.FlatAppearance.BorderSize = 0;
            this.btnWallet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWallet.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWallet.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWallet.Image = ((System.Drawing.Image)(resources.GetObject("btnWallet.Image")));
            this.btnWallet.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnWallet.Location = new System.Drawing.Point(824, 130);
            this.btnWallet.Margin = new System.Windows.Forms.Padding(4);
            this.btnWallet.Name = "btnWallet";
            this.btnWallet.Size = new System.Drawing.Size(267, 126);
            this.btnWallet.TabIndex = 86;
            this.btnWallet.Text = "فاتورة مبيعات";
            this.btnWallet.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnWallet.UseVisualStyleBackColor = false;
            this.btnWallet.Click += new System.EventHandler(this.btnWallet_Click);
            // 
            // btnSalesReturn
            // 
            this.btnSalesReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalesReturn.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnSalesReturn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesReturn.BackgroundImage")));
            this.btnSalesReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesReturn.FlatAppearance.BorderSize = 0;
            this.btnSalesReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalesReturn.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesReturn.ForeColor = System.Drawing.Color.White;
            this.btnSalesReturn.Image = ((System.Drawing.Image)(resources.GetObject("btnSalesReturn.Image")));
            this.btnSalesReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSalesReturn.Location = new System.Drawing.Point(275, 133);
            this.btnSalesReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnSalesReturn.Name = "btnSalesReturn";
            this.btnSalesReturn.Size = new System.Drawing.Size(267, 126);
            this.btnSalesReturn.TabIndex = 84;
            this.btnSalesReturn.Text = "مرتجع المبيعات";
            this.btnSalesReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalesReturn.UseVisualStyleBackColor = false;
            this.btnSalesReturn.Click += new System.EventHandler(this.btnSalesReturn_Click);
            // 
            // btnPurchase
            // 
            this.btnPurchase.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPurchase.AutoSize = true;
            this.btnPurchase.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btnPurchase.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPurchase.BackgroundImage")));
            this.btnPurchase.FlatAppearance.BorderSize = 0;
            this.btnPurchase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchase.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchase.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPurchase.Image = ((System.Drawing.Image)(resources.GetObject("btnPurchase.Image")));
            this.btnPurchase.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPurchase.Location = new System.Drawing.Point(551, 132);
            this.btnPurchase.Margin = new System.Windows.Forms.Padding(4);
            this.btnPurchase.Name = "btnPurchase";
            this.btnPurchase.Size = new System.Drawing.Size(267, 126);
            this.btnPurchase.TabIndex = 73;
            this.btnPurchase.Text = "فاتورة مشتريات";
            this.btnPurchase.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPurchase.UseVisualStyleBackColor = false;
            this.btnPurchase.Click += new System.EventHandler(this.btnPurchase_Click);
            // 
            // btnBarcodeLabelPrinting
            // 
            this.btnBarcodeLabelPrinting.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBarcodeLabelPrinting.AutoSize = true;
            this.btnBarcodeLabelPrinting.BackColor = System.Drawing.Color.Gold;
            this.btnBarcodeLabelPrinting.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBarcodeLabelPrinting.BackgroundImage")));
            this.btnBarcodeLabelPrinting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBarcodeLabelPrinting.FlatAppearance.BorderSize = 0;
            this.btnBarcodeLabelPrinting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBarcodeLabelPrinting.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBarcodeLabelPrinting.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBarcodeLabelPrinting.Image = ((System.Drawing.Image)(resources.GetObject("btnBarcodeLabelPrinting.Image")));
            this.btnBarcodeLabelPrinting.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBarcodeLabelPrinting.Location = new System.Drawing.Point(1, 263);
            this.btnBarcodeLabelPrinting.Margin = new System.Windows.Forms.Padding(4);
            this.btnBarcodeLabelPrinting.Name = "btnBarcodeLabelPrinting";
            this.btnBarcodeLabelPrinting.Size = new System.Drawing.Size(267, 126);
            this.btnBarcodeLabelPrinting.TabIndex = 82;
            this.btnBarcodeLabelPrinting.Text = "طباعة الباركود";
            this.btnBarcodeLabelPrinting.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBarcodeLabelPrinting.UseVisualStyleBackColor = false;
            this.btnBarcodeLabelPrinting.Click += new System.EventHandler(this.btnBarcodeLabelPrinting_Click);
            // 
            // BtnVoucher
            // 
            this.BtnVoucher.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnVoucher.AutoSize = true;
            this.BtnVoucher.BackColor = System.Drawing.Color.DarkTurquoise;
            this.BtnVoucher.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnVoucher.BackgroundImage")));
            this.BtnVoucher.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnVoucher.FlatAppearance.BorderSize = 0;
            this.BtnVoucher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnVoucher.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVoucher.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnVoucher.Image = ((System.Drawing.Image)(resources.GetObject("BtnVoucher.Image")));
            this.BtnVoucher.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnVoucher.Location = new System.Drawing.Point(824, 263);
            this.BtnVoucher.Margin = new System.Windows.Forms.Padding(4);
            this.BtnVoucher.Name = "BtnVoucher";
            this.BtnVoucher.Size = new System.Drawing.Size(267, 126);
            this.BtnVoucher.TabIndex = 76;
            this.BtnVoucher.Text = "سند صرف";
            this.BtnVoucher.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnVoucher.UseVisualStyleBackColor = false;
            this.BtnVoucher.Click += new System.EventHandler(this.BtnVoucher_Click);
            // 
            // btnBankReconciliation
            // 
            this.btnBankReconciliation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBankReconciliation.AutoSize = true;
            this.btnBankReconciliation.BackColor = System.Drawing.Color.Teal;
            this.btnBankReconciliation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBankReconciliation.BackgroundImage")));
            this.btnBankReconciliation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBankReconciliation.FlatAppearance.BorderSize = 0;
            this.btnBankReconciliation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBankReconciliation.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBankReconciliation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBankReconciliation.Image = ((System.Drawing.Image)(resources.GetObject("btnBankReconciliation.Image")));
            this.btnBankReconciliation.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBankReconciliation.Location = new System.Drawing.Point(276, 263);
            this.btnBankReconciliation.Margin = new System.Windows.Forms.Padding(4);
            this.btnBankReconciliation.Name = "btnBankReconciliation";
            this.btnBankReconciliation.Size = new System.Drawing.Size(267, 126);
            this.btnBankReconciliation.TabIndex = 85;
            this.btnBankReconciliation.Text = "دفعات الموردين";
            this.btnBankReconciliation.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBankReconciliation.UseVisualStyleBackColor = false;
            this.btnBankReconciliation.Click += new System.EventHandler(this.btnBankReconciliation_Click);
            // 
            // btnPayroll
            // 
            this.btnPayroll.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPayroll.AutoSize = true;
            this.btnPayroll.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnPayroll.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPayroll.BackgroundImage")));
            this.btnPayroll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPayroll.FlatAppearance.BorderSize = 0;
            this.btnPayroll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPayroll.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayroll.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPayroll.Image = ((System.Drawing.Image)(resources.GetObject("btnPayroll.Image")));
            this.btnPayroll.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPayroll.Location = new System.Drawing.Point(551, 263);
            this.btnPayroll.Margin = new System.Windows.Forms.Padding(4);
            this.btnPayroll.Name = "btnPayroll";
            this.btnPayroll.Size = new System.Drawing.Size(267, 126);
            this.btnPayroll.TabIndex = 79;
            this.btnPayroll.Text = "دفعات العملاء";
            this.btnPayroll.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPayroll.UseVisualStyleBackColor = false;
            this.btnPayroll.Click += new System.EventHandler(this.btnPayroll_Click);
            // 
            // btnAccountingReports
            // 
            this.btnAccountingReports.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAccountingReports.AutoSize = true;
            this.btnAccountingReports.BackColor = System.Drawing.Color.Crimson;
            this.btnAccountingReports.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAccountingReports.BackgroundImage")));
            this.btnAccountingReports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAccountingReports.FlatAppearance.BorderSize = 0;
            this.btnAccountingReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccountingReports.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountingReports.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAccountingReports.Image = ((System.Drawing.Image)(resources.GetObject("btnAccountingReports.Image")));
            this.btnAccountingReports.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAccountingReports.Location = new System.Drawing.Point(1, 396);
            this.btnAccountingReports.Margin = new System.Windows.Forms.Padding(4);
            this.btnAccountingReports.Name = "btnAccountingReports";
            this.btnAccountingReports.Size = new System.Drawing.Size(267, 126);
            this.btnAccountingReports.TabIndex = 75;
            this.btnAccountingReports.Text = "دفتر الأستاذ العام";
            this.btnAccountingReports.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAccountingReports.UseVisualStyleBackColor = false;
            this.btnAccountingReports.Click += new System.EventHandler(this.btnAccountingReports_Click_1);
            // 
            // btnStockAdjustment
            // 
            this.btnStockAdjustment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStockAdjustment.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnStockAdjustment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStockAdjustment.BackgroundImage")));
            this.btnStockAdjustment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStockAdjustment.FlatAppearance.BorderSize = 0;
            this.btnStockAdjustment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStockAdjustment.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStockAdjustment.ForeColor = System.Drawing.Color.White;
            this.btnStockAdjustment.Image = ((System.Drawing.Image)(resources.GetObject("btnStockAdjustment.Image")));
            this.btnStockAdjustment.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnStockAdjustment.Location = new System.Drawing.Point(824, 396);
            this.btnStockAdjustment.Margin = new System.Windows.Forms.Padding(4);
            this.btnStockAdjustment.Name = "btnStockAdjustment";
            this.btnStockAdjustment.Size = new System.Drawing.Size(267, 126);
            this.btnStockAdjustment.TabIndex = 87;
            this.btnStockAdjustment.Text = "حالة المخزون";
            this.btnStockAdjustment.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnStockAdjustment.UseVisualStyleBackColor = false;
            this.btnStockAdjustment.Click += new System.EventHandler(this.btnStockAdjustment_Click);
            // 
            // btnStockTransfer_Issue
            // 
            this.btnStockTransfer_Issue.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStockTransfer_Issue.AutoSize = true;
            this.btnStockTransfer_Issue.BackColor = System.Drawing.Color.Tomato;
            this.btnStockTransfer_Issue.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStockTransfer_Issue.BackgroundImage")));
            this.btnStockTransfer_Issue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStockTransfer_Issue.FlatAppearance.BorderSize = 0;
            this.btnStockTransfer_Issue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStockTransfer_Issue.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStockTransfer_Issue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnStockTransfer_Issue.Image = ((System.Drawing.Image)(resources.GetObject("btnStockTransfer_Issue.Image")));
            this.btnStockTransfer_Issue.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnStockTransfer_Issue.Location = new System.Drawing.Point(278, 396);
            this.btnStockTransfer_Issue.Margin = new System.Windows.Forms.Padding(4);
            this.btnStockTransfer_Issue.Name = "btnStockTransfer_Issue";
            this.btnStockTransfer_Issue.Size = new System.Drawing.Size(267, 126);
            this.btnStockTransfer_Issue.TabIndex = 80;
            this.btnStockTransfer_Issue.Text = "جرد المخزون";
            this.btnStockTransfer_Issue.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnStockTransfer_Issue.UseVisualStyleBackColor = false;
            this.btnStockTransfer_Issue.Click += new System.EventHandler(this.btnStockTransfer_Issue_Click_1);
            // 
            // btnPayment
            // 
            this.btnPayment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPayment.AutoSize = true;
            this.btnPayment.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.btnPayment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPayment.BackgroundImage")));
            this.btnPayment.FlatAppearance.BorderSize = 0;
            this.btnPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPayment.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPayment.Image = ((System.Drawing.Image)(resources.GetObject("btnPayment.Image")));
            this.btnPayment.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPayment.Location = new System.Drawing.Point(552, 396);
            this.btnPayment.Margin = new System.Windows.Forms.Padding(4);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(267, 126);
            this.btnPayment.TabIndex = 74;
            this.btnPayment.Text = "عمولة المناديب";
            this.btnPayment.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click_1);
            // 
            // btnPOSRecord
            // 
            this.btnPOSRecord.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPOSRecord.BackColor = System.Drawing.Color.Crimson;
            this.btnPOSRecord.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPOSRecord.BackgroundImage")));
            this.btnPOSRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPOSRecord.FlatAppearance.BorderSize = 0;
            this.btnPOSRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPOSRecord.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPOSRecord.ForeColor = System.Drawing.Color.White;
            this.btnPOSRecord.Image = ((System.Drawing.Image)(resources.GetObject("btnPOSRecord.Image")));
            this.btnPOSRecord.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPOSRecord.Location = new System.Drawing.Point(1, 529);
            this.btnPOSRecord.Margin = new System.Windows.Forms.Padding(4);
            this.btnPOSRecord.Name = "btnPOSRecord";
            this.btnPOSRecord.Size = new System.Drawing.Size(267, 126);
            this.btnPOSRecord.TabIndex = 81;
            this.btnPOSRecord.Text = "ارصدة الجميع";
            this.btnPOSRecord.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPOSRecord.UseVisualStyleBackColor = false;
            this.btnPOSRecord.Click += new System.EventHandler(this.btnPOSRecord_Click);
            // 
            // btnPOSReport
            // 
            this.btnPOSReport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPOSReport.AutoSize = true;
            this.btnPOSReport.BackColor = System.Drawing.Color.SandyBrown;
            this.btnPOSReport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPOSReport.BackgroundImage")));
            this.btnPOSReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPOSReport.FlatAppearance.BorderSize = 0;
            this.btnPOSReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPOSReport.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPOSReport.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPOSReport.Image = ((System.Drawing.Image)(resources.GetObject("btnPOSReport.Image")));
            this.btnPOSReport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPOSReport.Location = new System.Drawing.Point(824, 529);
            this.btnPOSReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnPOSReport.Name = "btnPOSReport";
            this.btnPOSReport.Size = new System.Drawing.Size(267, 126);
            this.btnPOSReport.TabIndex = 68;
            this.btnPOSReport.Text = "تقرير مبيعات";
            this.btnPOSReport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPOSReport.UseVisualStyleBackColor = false;
            this.btnPOSReport.Click += new System.EventHandler(this.btnPOSReport_Click_1);
            // 
            // btnWorkPeriod
            // 
            this.btnWorkPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWorkPeriod.AutoSize = true;
            this.btnWorkPeriod.BackColor = System.Drawing.Color.Orange;
            this.btnWorkPeriod.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWorkPeriod.BackgroundImage")));
            this.btnWorkPeriod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWorkPeriod.FlatAppearance.BorderSize = 0;
            this.btnWorkPeriod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWorkPeriod.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWorkPeriod.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWorkPeriod.Image = ((System.Drawing.Image)(resources.GetObject("btnWorkPeriod.Image")));
            this.btnWorkPeriod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnWorkPeriod.Location = new System.Drawing.Point(278, 529);
            this.btnWorkPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.btnWorkPeriod.Name = "btnWorkPeriod";
            this.btnWorkPeriod.Size = new System.Drawing.Size(267, 126);
            this.btnWorkPeriod.TabIndex = 71;
            this.btnWorkPeriod.Text = "الارباح والخسائر";
            this.btnWorkPeriod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnWorkPeriod.UseVisualStyleBackColor = false;
            this.btnWorkPeriod.Click += new System.EventHandler(this.btnWorkPeriod_Click);
            // 
            // btnPurchaseOrder
            // 
            this.btnPurchaseOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPurchaseOrder.AutoSize = true;
            this.btnPurchaseOrder.BackColor = System.Drawing.Color.Indigo;
            this.btnPurchaseOrder.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPurchaseOrder.BackgroundImage")));
            this.btnPurchaseOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPurchaseOrder.FlatAppearance.BorderSize = 0;
            this.btnPurchaseOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchaseOrder.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchaseOrder.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPurchaseOrder.Image = ((System.Drawing.Image)(resources.GetObject("btnPurchaseOrder.Image")));
            this.btnPurchaseOrder.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPurchaseOrder.Location = new System.Drawing.Point(552, 529);
            this.btnPurchaseOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnPurchaseOrder.Name = "btnPurchaseOrder";
            this.btnPurchaseOrder.Size = new System.Drawing.Size(267, 126);
            this.btnPurchaseOrder.TabIndex = 78;
            this.btnPurchaseOrder.Text = "تقرير المشتريات";
            this.btnPurchaseOrder.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPurchaseOrder.UseVisualStyleBackColor = false;
            this.btnPurchaseOrder.Click += new System.EventHandler(this.btnPurchaseOrder_Click);
            // 
            // gunaButton11
            // 
            this.gunaButton11.AnimationHoverSpeed = 0.07F;
            this.gunaButton11.AnimationSpeed = 0.03F;
            this.gunaButton11.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton11.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton11.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton11.ForeColor = System.Drawing.Color.White;
            this.gunaButton11.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton11.Image")));
            this.gunaButton11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton11.ImageOffsetX = 10;
            this.gunaButton11.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton11.Location = new System.Drawing.Point(9, 0);
            this.gunaButton11.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton11.Name = "gunaButton11";
            this.gunaButton11.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton11.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton11.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton11.OnHoverImage = null;
            this.gunaButton11.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton11.Size = new System.Drawing.Size(278, 50);
            this.gunaButton11.TabIndex = 2;
            this.gunaButton11.Text = "اغلاق البرنامج";
            this.gunaButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton11.TextOffsetX = 15;
            // 
            // gunaButton10
            // 
            this.gunaButton10.AnimationHoverSpeed = 0.07F;
            this.gunaButton10.AnimationSpeed = 0.03F;
            this.gunaButton10.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton10.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton10.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton10.ForeColor = System.Drawing.Color.White;
            this.gunaButton10.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton10.Image")));
            this.gunaButton10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton10.ImageOffsetX = 10;
            this.gunaButton10.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton10.Location = new System.Drawing.Point(9, 0);
            this.gunaButton10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton10.Name = "gunaButton10";
            this.gunaButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton10.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton10.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton10.OnHoverImage = null;
            this.gunaButton10.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton10.Size = new System.Drawing.Size(278, 50);
            this.gunaButton10.TabIndex = 2;
            this.gunaButton10.Text = "العمليات الاخيرة";
            this.gunaButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton10.TextOffsetX = 15;
            // 
            // gunaButton4
            // 
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton4.ForeColor = System.Drawing.Color.White;
            this.gunaButton4.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton4.Image")));
            this.gunaButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton4.ImageOffsetX = 10;
            this.gunaButton4.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton4.Location = new System.Drawing.Point(9, 0);
            this.gunaButton4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton4.Size = new System.Drawing.Size(278, 50);
            this.gunaButton4.TabIndex = 3;
            this.gunaButton4.Text = "دفعات الموردين";
            this.gunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton4.TextOffsetX = 15;
            // 
            // gunaButton7
            // 
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton7.ForeColor = System.Drawing.Color.White;
            this.gunaButton7.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton7.Image")));
            this.gunaButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton7.ImageOffsetX = 10;
            this.gunaButton7.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton7.Location = new System.Drawing.Point(9, 0);
            this.gunaButton7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaButton7.Size = new System.Drawing.Size(278, 50);
            this.gunaButton7.TabIndex = 2;
            this.gunaButton7.Text = "دفعات العميل";
            this.gunaButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton7.TextOffsetX = 20;
            // 
            // gunaButton3
            // 
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton3.ForeColor = System.Drawing.Color.White;
            this.gunaButton3.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton3.Image")));
            this.gunaButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton3.ImageOffsetX = 10;
            this.gunaButton3.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton3.Location = new System.Drawing.Point(9, 0);
            this.gunaButton3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton3.Size = new System.Drawing.Size(278, 50);
            this.gunaButton3.TabIndex = 2;
            this.gunaButton3.Text = "الموردين";
            this.gunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton14
            // 
            this.gunaButton14.AnimationHoverSpeed = 0.07F;
            this.gunaButton14.AnimationSpeed = 0.03F;
            this.gunaButton14.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton14.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton14.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton14.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton14.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.gunaButton14.ForeColor = System.Drawing.Color.White;
            this.gunaButton14.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton14.Image")));
            this.gunaButton14.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton14.ImageOffsetX = 10;
            this.gunaButton14.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton14.Location = new System.Drawing.Point(9, 114);
            this.gunaButton14.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton14.Name = "gunaButton14";
            this.gunaButton14.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton14.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton14.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton14.OnHoverImage = null;
            this.gunaButton14.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton14.Size = new System.Drawing.Size(242, 44);
            this.gunaButton14.TabIndex = 6;
            this.gunaButton14.Text = "قائمة العملاء";
            this.gunaButton14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton15
            // 
            this.gunaButton15.AnimationHoverSpeed = 0.07F;
            this.gunaButton15.AnimationSpeed = 0.03F;
            this.gunaButton15.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton15.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton15.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton15.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton15.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.gunaButton15.ForeColor = System.Drawing.Color.White;
            this.gunaButton15.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton15.Image")));
            this.gunaButton15.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton15.ImageOffsetX = 10;
            this.gunaButton15.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton15.Location = new System.Drawing.Point(8, 53);
            this.gunaButton15.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton15.Name = "gunaButton15";
            this.gunaButton15.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton15.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton15.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton15.OnHoverImage = null;
            this.gunaButton15.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton15.Size = new System.Drawing.Size(243, 44);
            this.gunaButton15.TabIndex = 5;
            this.gunaButton15.Text = "اضافة عملاء";
            this.gunaButton15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton6
            // 
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton6.ForeColor = System.Drawing.Color.White;
            this.gunaButton6.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton6.Image")));
            this.gunaButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton6.ImageOffsetX = 10;
            this.gunaButton6.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton6.Location = new System.Drawing.Point(7, 4);
            this.gunaButton6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton6.Size = new System.Drawing.Size(278, 50);
            this.gunaButton6.TabIndex = 2;
            this.gunaButton6.Text = "العملاء";
            this.gunaButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton6.TextOffsetX = 15;
            this.gunaButton6.Click += new System.EventHandler(this.gunaButton6_Click);
            // 
            // gunaButton13
            // 
            this.gunaButton13.AnimationHoverSpeed = 0.07F;
            this.gunaButton13.AnimationSpeed = 0.03F;
            this.gunaButton13.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton13.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton13.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton13.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton13.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.gunaButton13.ForeColor = System.Drawing.Color.White;
            this.gunaButton13.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton13.Image")));
            this.gunaButton13.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton13.ImageOffsetX = 10;
            this.gunaButton13.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton13.Location = new System.Drawing.Point(9, 116);
            this.gunaButton13.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton13.Name = "gunaButton13";
            this.gunaButton13.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton13.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton13.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton13.OnHoverImage = null;
            this.gunaButton13.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton13.Size = new System.Drawing.Size(242, 44);
            this.gunaButton13.TabIndex = 4;
            this.gunaButton13.Text = "مرتجع مبيعات";
            this.gunaButton13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton12
            // 
            this.gunaButton12.AnimationHoverSpeed = 0.07F;
            this.gunaButton12.AnimationSpeed = 0.03F;
            this.gunaButton12.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton12.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton12.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton12.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.gunaButton12.ForeColor = System.Drawing.Color.White;
            this.gunaButton12.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton12.Image")));
            this.gunaButton12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton12.ImageOffsetX = 10;
            this.gunaButton12.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton12.Location = new System.Drawing.Point(8, 58);
            this.gunaButton12.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton12.Name = "gunaButton12";
            this.gunaButton12.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton12.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton12.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton12.OnHoverImage = null;
            this.gunaButton12.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton12.Size = new System.Drawing.Size(243, 44);
            this.gunaButton12.TabIndex = 3;
            this.gunaButton12.Text = "فاتورة مبيعات";
            this.gunaButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton5
            // 
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton5.ForeColor = System.Drawing.Color.White;
            this.gunaButton5.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton5.Image")));
            this.gunaButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton5.ImageOffsetX = 10;
            this.gunaButton5.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton5.Location = new System.Drawing.Point(9, 3);
            this.gunaButton5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton5.Size = new System.Drawing.Size(278, 50);
            this.gunaButton5.TabIndex = 2;
            this.gunaButton5.Text = "المبيعات";
            this.gunaButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton5.TextOffsetX = 15;
            this.gunaButton5.Click += new System.EventHandler(this.gunaButton5_Click);
            // 
            // gunaButton8
            // 
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton8.ForeColor = System.Drawing.Color.White;
            this.gunaButton8.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton8.Image")));
            this.gunaButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton8.ImageOffsetX = 10;
            this.gunaButton8.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton8.Location = new System.Drawing.Point(8, 7);
            this.gunaButton8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton8.Size = new System.Drawing.Size(278, 50);
            this.gunaButton8.TabIndex = 3;
            this.gunaButton8.Text = "التقارير";
            this.gunaButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton8.Click += new System.EventHandler(this.gunaButton8_Click);
            // 
            // gunaButton28
            // 
            this.gunaButton28.AnimationHoverSpeed = 0.07F;
            this.gunaButton28.AnimationSpeed = 0.03F;
            this.gunaButton28.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton28.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton28.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton28.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton28.ForeColor = System.Drawing.Color.White;
            this.gunaButton28.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton28.Image")));
            this.gunaButton28.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton28.ImageOffsetX = 10;
            this.gunaButton28.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton28.Location = new System.Drawing.Point(4, 380);
            this.gunaButton28.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton28.Name = "gunaButton28";
            this.gunaButton28.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton28.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton28.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton28.OnHoverImage = null;
            this.gunaButton28.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton28.Size = new System.Drawing.Size(243, 20);
            this.gunaButton28.TabIndex = 18;
            this.gunaButton28.Text = "احصائيات عامة";
            this.gunaButton28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton22
            // 
            this.gunaButton22.AnimationHoverSpeed = 0.07F;
            this.gunaButton22.AnimationSpeed = 0.03F;
            this.gunaButton22.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton22.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton22.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton22.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton22.ForeColor = System.Drawing.Color.White;
            this.gunaButton22.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton22.Image")));
            this.gunaButton22.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton22.ImageOffsetX = 10;
            this.gunaButton22.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton22.Location = new System.Drawing.Point(4, 353);
            this.gunaButton22.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton22.Name = "gunaButton22";
            this.gunaButton22.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton22.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton22.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton22.OnHoverImage = null;
            this.gunaButton22.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton22.Size = new System.Drawing.Size(243, 20);
            this.gunaButton22.TabIndex = 17;
            this.gunaButton22.Text = "مبيعات كل صنف";
            this.gunaButton22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton23
            // 
            this.gunaButton23.AnimationHoverSpeed = 0.07F;
            this.gunaButton23.AnimationSpeed = 0.03F;
            this.gunaButton23.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton23.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton23.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton23.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton23.ForeColor = System.Drawing.Color.White;
            this.gunaButton23.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton23.Image")));
            this.gunaButton23.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton23.ImageOffsetX = 10;
            this.gunaButton23.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton23.Location = new System.Drawing.Point(4, 325);
            this.gunaButton23.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton23.Name = "gunaButton23";
            this.gunaButton23.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton23.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton23.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton23.OnHoverImage = null;
            this.gunaButton23.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton23.Size = new System.Drawing.Size(243, 20);
            this.gunaButton23.TabIndex = 16;
            this.gunaButton23.Text = "قائمة فواتير البيع";
            this.gunaButton23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton24
            // 
            this.gunaButton24.AnimationHoverSpeed = 0.07F;
            this.gunaButton24.AnimationSpeed = 0.03F;
            this.gunaButton24.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton24.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton24.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton24.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton24.ForeColor = System.Drawing.Color.White;
            this.gunaButton24.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton24.Image")));
            this.gunaButton24.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton24.ImageOffsetX = 10;
            this.gunaButton24.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton24.Location = new System.Drawing.Point(4, 299);
            this.gunaButton24.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton24.Name = "gunaButton24";
            this.gunaButton24.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton24.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton24.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton24.OnHoverImage = null;
            this.gunaButton24.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton24.Size = new System.Drawing.Size(243, 20);
            this.gunaButton24.TabIndex = 15;
            this.gunaButton24.Text = "قائمة الرسائل";
            this.gunaButton24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton25
            // 
            this.gunaButton25.AnimationHoverSpeed = 0.07F;
            this.gunaButton25.AnimationSpeed = 0.03F;
            this.gunaButton25.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton25.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton25.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton25.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton25.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton25.ForeColor = System.Drawing.Color.White;
            this.gunaButton25.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton25.Image")));
            this.gunaButton25.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton25.ImageOffsetX = 10;
            this.gunaButton25.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton25.Location = new System.Drawing.Point(4, 271);
            this.gunaButton25.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton25.Name = "gunaButton25";
            this.gunaButton25.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton25.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton25.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton25.OnHoverImage = null;
            this.gunaButton25.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton25.Size = new System.Drawing.Size(243, 20);
            this.gunaButton25.TabIndex = 14;
            this.gunaButton25.Text = "قائمة عروض الاسعار";
            this.gunaButton25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton26
            // 
            this.gunaButton26.AnimationHoverSpeed = 0.07F;
            this.gunaButton26.AnimationSpeed = 0.03F;
            this.gunaButton26.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton26.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton26.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton26.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton26.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton26.ForeColor = System.Drawing.Color.White;
            this.gunaButton26.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton26.Image")));
            this.gunaButton26.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton26.ImageOffsetX = 10;
            this.gunaButton26.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton26.Location = new System.Drawing.Point(4, 243);
            this.gunaButton26.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton26.Name = "gunaButton26";
            this.gunaButton26.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton26.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton26.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton26.OnHoverImage = null;
            this.gunaButton26.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton26.Size = new System.Drawing.Size(243, 20);
            this.gunaButton26.TabIndex = 13;
            this.gunaButton26.Text = "قائمة فواتير الخدمات";
            this.gunaButton26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton27
            // 
            this.gunaButton27.AnimationHoverSpeed = 0.07F;
            this.gunaButton27.AnimationSpeed = 0.03F;
            this.gunaButton27.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton27.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton27.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton27.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton27.ForeColor = System.Drawing.Color.White;
            this.gunaButton27.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton27.Image")));
            this.gunaButton27.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton27.ImageOffsetX = 10;
            this.gunaButton27.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton27.Location = new System.Drawing.Point(4, 217);
            this.gunaButton27.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton27.Name = "gunaButton27";
            this.gunaButton27.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton27.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton27.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton27.OnHoverImage = null;
            this.gunaButton27.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton27.Size = new System.Drawing.Size(243, 20);
            this.gunaButton27.TabIndex = 12;
            this.gunaButton27.Text = "قائمة الخدمات";
            this.gunaButton27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton19
            // 
            this.gunaButton19.AnimationHoverSpeed = 0.07F;
            this.gunaButton19.AnimationSpeed = 0.03F;
            this.gunaButton19.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton19.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton19.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton19.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton19.ForeColor = System.Drawing.Color.White;
            this.gunaButton19.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton19.Image")));
            this.gunaButton19.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton19.ImageOffsetX = 10;
            this.gunaButton19.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton19.Location = new System.Drawing.Point(4, 190);
            this.gunaButton19.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton19.Name = "gunaButton19";
            this.gunaButton19.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton19.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton19.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton19.OnHoverImage = null;
            this.gunaButton19.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton19.Size = new System.Drawing.Size(243, 20);
            this.gunaButton19.TabIndex = 11;
            this.gunaButton19.Text = "قائمة فواتير الشراء";
            this.gunaButton19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton20
            // 
            this.gunaButton20.AnimationHoverSpeed = 0.07F;
            this.gunaButton20.AnimationSpeed = 0.03F;
            this.gunaButton20.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton20.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton20.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton20.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton20.ForeColor = System.Drawing.Color.White;
            this.gunaButton20.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton20.Image")));
            this.gunaButton20.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton20.ImageOffsetX = 10;
            this.gunaButton20.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton20.Location = new System.Drawing.Point(4, 162);
            this.gunaButton20.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton20.Name = "gunaButton20";
            this.gunaButton20.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton20.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton20.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton20.OnHoverImage = null;
            this.gunaButton20.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton20.Size = new System.Drawing.Size(243, 20);
            this.gunaButton20.TabIndex = 10;
            this.gunaButton20.Text = "قائمة دفعات الموردين";
            this.gunaButton20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton21
            // 
            this.gunaButton21.AnimationHoverSpeed = 0.07F;
            this.gunaButton21.AnimationSpeed = 0.03F;
            this.gunaButton21.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton21.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton21.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton21.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton21.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton21.ForeColor = System.Drawing.Color.White;
            this.gunaButton21.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton21.Image")));
            this.gunaButton21.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton21.ImageOffsetX = 10;
            this.gunaButton21.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton21.Location = new System.Drawing.Point(4, 136);
            this.gunaButton21.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton21.Name = "gunaButton21";
            this.gunaButton21.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton21.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton21.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton21.OnHoverImage = null;
            this.gunaButton21.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton21.Size = new System.Drawing.Size(243, 20);
            this.gunaButton21.TabIndex = 9;
            this.gunaButton21.Text = "قائمة الموردين";
            this.gunaButton21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton18
            // 
            this.gunaButton18.AnimationHoverSpeed = 0.07F;
            this.gunaButton18.AnimationSpeed = 0.03F;
            this.gunaButton18.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton18.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton18.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton18.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton18.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton18.ForeColor = System.Drawing.Color.White;
            this.gunaButton18.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton18.Image")));
            this.gunaButton18.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton18.ImageOffsetX = 10;
            this.gunaButton18.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton18.Location = new System.Drawing.Point(4, 108);
            this.gunaButton18.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton18.Name = "gunaButton18";
            this.gunaButton18.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton18.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton18.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton18.OnHoverImage = null;
            this.gunaButton18.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton18.Size = new System.Drawing.Size(243, 20);
            this.gunaButton18.TabIndex = 8;
            this.gunaButton18.Text = "قائمة الاصناف ";
            this.gunaButton18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton18.Click += new System.EventHandler(this.gunaButton18_Click);
            // 
            // gunaButton17
            // 
            this.gunaButton17.AnimationHoverSpeed = 0.07F;
            this.gunaButton17.AnimationSpeed = 0.03F;
            this.gunaButton17.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton17.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton17.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton17.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton17.ForeColor = System.Drawing.Color.White;
            this.gunaButton17.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton17.Image")));
            this.gunaButton17.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton17.ImageOffsetX = 10;
            this.gunaButton17.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton17.Location = new System.Drawing.Point(4, 80);
            this.gunaButton17.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton17.Name = "gunaButton17";
            this.gunaButton17.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton17.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton17.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton17.OnHoverImage = null;
            this.gunaButton17.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton17.Size = new System.Drawing.Size(243, 20);
            this.gunaButton17.TabIndex = 7;
            this.gunaButton17.Text = "قائمة مناديب المبيعات";
            this.gunaButton17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton16
            // 
            this.gunaButton16.AnimationHoverSpeed = 0.07F;
            this.gunaButton16.AnimationSpeed = 0.03F;
            this.gunaButton16.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton16.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton16.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton16.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton16.ForeColor = System.Drawing.Color.White;
            this.gunaButton16.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton16.Image")));
            this.gunaButton16.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton16.ImageOffsetX = 10;
            this.gunaButton16.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton16.Location = new System.Drawing.Point(4, 54);
            this.gunaButton16.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton16.Name = "gunaButton16";
            this.gunaButton16.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton16.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton16.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton16.OnHoverImage = null;
            this.gunaButton16.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton16.Size = new System.Drawing.Size(243, 20);
            this.gunaButton16.TabIndex = 6;
            this.gunaButton16.Text = "قائمة العملاء";
            this.gunaButton16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton16.Click += new System.EventHandler(this.gunaButton16_Click);
            // 
            // gunaButton9
            // 
            this.gunaButton9.AnimationHoverSpeed = 0.07F;
            this.gunaButton9.AnimationSpeed = 0.03F;
            this.gunaButton9.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton9.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton9.ForeColor = System.Drawing.Color.White;
            this.gunaButton9.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton9.Image")));
            this.gunaButton9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton9.ImageOffsetX = 10;
            this.gunaButton9.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton9.Location = new System.Drawing.Point(8, 4);
            this.gunaButton9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton9.Name = "gunaButton9";
            this.gunaButton9.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton9.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton9.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton9.OnHoverImage = null;
            this.gunaButton9.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton9.Size = new System.Drawing.Size(278, 50);
            this.gunaButton9.TabIndex = 2;
            this.gunaButton9.Text = "الجداول";
            this.gunaButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton9.TextOffsetX = 15;
            this.gunaButton9.Click += new System.EventHandler(this.gunaButton9_Click);
            // 
            // gunaButton2
            // 
            this.gunaButton2.Animated = true;
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton2.Image")));
            this.gunaButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton2.ImageOffsetX = 10;
            this.gunaButton2.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton2.Location = new System.Drawing.Point(9, 0);
            this.gunaButton2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton2.Size = new System.Drawing.Size(278, 50);
            this.gunaButton2.TabIndex = 2;
            this.gunaButton2.Text = "سند صرف";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.Dock = System.Windows.Forms.DockStyle.Right;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton1.Image")));
            this.gunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton1.ImageOffsetX = 10;
            this.gunaButton1.ImageSize = new System.Drawing.Size(25, 25);
            this.gunaButton1.Location = new System.Drawing.Point(9, 0);
            this.gunaButton1.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton1.Size = new System.Drawing.Size(278, 50);
            this.gunaButton1.TabIndex = 2;
            this.gunaButton1.Text = "عرض سعر";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // Orders_Button
            // 
            this.Orders_Button.AnimationHoverSpeed = 0.07F;
            this.Orders_Button.AnimationSpeed = 0.03F;
            this.Orders_Button.BaseColor = System.Drawing.Color.Transparent;
            this.Orders_Button.BorderColor = System.Drawing.Color.Transparent;
            this.Orders_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Orders_Button.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Orders_Button.Dock = System.Windows.Forms.DockStyle.Right;
            this.Orders_Button.FocusedColor = System.Drawing.Color.Empty;
            this.Orders_Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.Orders_Button.ForeColor = System.Drawing.Color.White;
            this.Orders_Button.Image = ((System.Drawing.Image)(resources.GetObject("Orders_Button.Image")));
            this.Orders_Button.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Orders_Button.ImageOffsetX = 10;
            this.Orders_Button.ImageSize = new System.Drawing.Size(25, 25);
            this.Orders_Button.Location = new System.Drawing.Point(9, 0);
            this.Orders_Button.Margin = new System.Windows.Forms.Padding(4);
            this.Orders_Button.Name = "Orders_Button";
            this.Orders_Button.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Orders_Button.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Orders_Button.OnHoverForeColor = System.Drawing.Color.White;
            this.Orders_Button.OnHoverImage = null;
            this.Orders_Button.OnPressedColor = System.Drawing.Color.White;
            this.Orders_Button.Size = new System.Drawing.Size(278, 50);
            this.Orders_Button.TabIndex = 1;
            this.Orders_Button.Text = "المخزون";
            this.Orders_Button.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Orders_Button.Click += new System.EventHandler(this.Orders_Button_Click);
            // 
            // Home_Button
            // 
            this.Home_Button.AnimationHoverSpeed = 0.07F;
            this.Home_Button.AnimationSpeed = 0.03F;
            this.Home_Button.BaseColor = System.Drawing.Color.Transparent;
            this.Home_Button.BorderColor = System.Drawing.Color.Transparent;
            this.Home_Button.BorderSize = 1;
            this.Home_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home_Button.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Home_Button.Dock = System.Windows.Forms.DockStyle.Right;
            this.Home_Button.FocusedColor = System.Drawing.Color.Empty;
            this.Home_Button.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home_Button.ForeColor = System.Drawing.Color.White;
            this.Home_Button.Image = ((System.Drawing.Image)(resources.GetObject("Home_Button.Image")));
            this.Home_Button.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Home_Button.ImageOffsetX = -2;
            this.Home_Button.ImageSize = new System.Drawing.Size(45, 45);
            this.Home_Button.Location = new System.Drawing.Point(9, 0);
            this.Home_Button.Margin = new System.Windows.Forms.Padding(4);
            this.Home_Button.Name = "Home_Button";
            this.Home_Button.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Home_Button.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Home_Button.OnHoverForeColor = System.Drawing.Color.White;
            this.Home_Button.OnHoverImage = null;
            this.Home_Button.OnPressedColor = System.Drawing.Color.White;
            this.Home_Button.Size = new System.Drawing.Size(278, 54);
            this.Home_Button.TabIndex = 1;
            this.Home_Button.Text = "الرئيسية";
            this.Home_Button.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Home_Button.Click += new System.EventHandler(this.Home_Button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Accounting_System.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(21, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(51, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Menu_Button
            // 
            this.Menu_Button.AnimationHoverSpeed = 0.07F;
            this.Menu_Button.AnimationSpeed = 0.03F;
            this.Menu_Button.BaseColor = System.Drawing.Color.Transparent;
            this.Menu_Button.BorderColor = System.Drawing.Color.Transparent;
            this.Menu_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Menu_Button.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Menu_Button.FocusedColor = System.Drawing.Color.Empty;
            this.Menu_Button.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Menu_Button.ForeColor = System.Drawing.Color.White;
            this.Menu_Button.Image = ((System.Drawing.Image)(resources.GetObject("Menu_Button.Image")));
            this.Menu_Button.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Menu_Button.ImageOffsetX = 5;
            this.Menu_Button.ImageSize = new System.Drawing.Size(30, 30);
            this.Menu_Button.Location = new System.Drawing.Point(16, 0);
            this.Menu_Button.Margin = new System.Windows.Forms.Padding(4);
            this.Menu_Button.Name = "Menu_Button";
            this.Menu_Button.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Menu_Button.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Menu_Button.OnHoverForeColor = System.Drawing.Color.Silver;
            this.Menu_Button.OnHoverImage = null;
            this.Menu_Button.OnPressedColor = System.Drawing.Color.White;
            this.Menu_Button.Size = new System.Drawing.Size(271, 66);
            this.Menu_Button.TabIndex = 1;
            this.Menu_Button.Text = "URTECH";
            this.Menu_Button.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Menu_Button.Click += new System.EventHandler(this.Menu_Button_Click);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem27.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem27.Image")));
            this.toolStripMenuItem27.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(79, 76);
            this.toolStripMenuItem27.Text = "الرئيسية";
            this.toolStripMenuItem27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem27.Click += new System.EventHandler(this.toolStripMenuItem27_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem33.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem33.Image")));
            this.toolStripMenuItem33.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(72, 76);
            this.toolStripMenuItem33.Text = "المخزون";
            this.toolStripMenuItem33.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem25.Image")));
            this.toolStripMenuItem25.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(102, 76);
            this.toolStripMenuItem25.Text = "عرض سعر";
            this.toolStripMenuItem25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem25.Click += new System.EventHandler(this.toolStripMenuItem25_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem29.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem29.Image")));
            this.toolStripMenuItem29.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(95, 76);
            this.toolStripMenuItem29.Text = "سند صرف";
            this.toolStripMenuItem29.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem23.Image")));
            this.toolStripMenuItem23.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(90, 76);
            this.toolStripMenuItem23.Text = "الموردين";
            this.toolStripMenuItem23.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem23.Click += new System.EventHandler(this.toolStripMenuItem23_Click);
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem21.Image")));
            this.toolStripMenuItem21.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(130, 76);
            this.toolStripMenuItem21.Text = "دفعات الموردين";
            this.toolStripMenuItem21.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem21.Click += new System.EventHandler(this.toolStripMenuItem21_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.toolStripMenuItem19.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem20,
            this.مرتجعمبيعاتToolStripMenuItem});
            this.toolStripMenuItem19.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem19.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem19.Image")));
            this.toolStripMenuItem19.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(79, 76);
            this.toolStripMenuItem19.Text = "المبيعات";
            this.toolStripMenuItem19.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem20.Text = "فاتورة مبيعات";
            this.toolStripMenuItem20.Click += new System.EventHandler(this.toolStripMenuItem20_Click);
            // 
            // مرتجعمبيعاتToolStripMenuItem
            // 
            this.مرتجعمبيعاتToolStripMenuItem.Name = "مرتجعمبيعاتToolStripMenuItem";
            this.مرتجعمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.مرتجعمبيعاتToolStripMenuItem.Text = "مرتجع مبيعات";
            this.مرتجعمبيعاتToolStripMenuItem.Click += new System.EventHandler(this.مرتجعمبيعاتToolStripMenuItem_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem18,
            this.قائمةالعملاءToolStripMenuItem,
            this.ToolStripSeparator11});
            this.toolStripMenuItem17.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.toolStripMenuItem17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem17.Image")));
            this.toolStripMenuItem17.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(70, 76);
            this.toolStripMenuItem17.Text = "العملاء";
            this.toolStripMenuItem17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem18.Text = "اضافة عملاء";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // قائمةالعملاءToolStripMenuItem
            // 
            this.قائمةالعملاءToolStripMenuItem.Name = "قائمةالعملاءToolStripMenuItem";
            this.قائمةالعملاءToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.قائمةالعملاءToolStripMenuItem.Text = "قائمة العملاء";
            this.قائمةالعملاءToolStripMenuItem.Click += new System.EventHandler(this.قائمةالعملاءToolStripMenuItem_Click);
            // 
            // ToolStripSeparator11
            // 
            this.ToolStripSeparator11.Name = "ToolStripSeparator11";
            this.ToolStripSeparator11.Size = new System.Drawing.Size(176, 6);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem15.Image")));
            this.toolStripMenuItem15.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(111, 76);
            this.toolStripMenuItem15.Text = "دفعات العميل";
            this.toolStripMenuItem15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem10,
            this.قائمةمناديبالمبيعاتToolStripMenuItem,
            this.ToolStripSeparator12,
            this.قائمةالاصنافToolStripMenuItem,
            this.قائمةالموردينToolStripMenuItem,
            this.قائمةدفعاتالموردينToolStripMenuItem,
            this.قائمةفواتيرالشراءToolStripMenuItem,
            this.toolStripSeparator1,
            this.قائمةالخدماتToolStripMenuItem,
            this.قائمةفواتيرالخدماتToolStripMenuItem,
            this.قائمةعروضالاسعارToolStripMenuItem,
            this.قائمةالرسائلToolStripMenuItem,
            this.toolStripSeparator2,
            this.قائمةفواتيرالبيعToolStripMenuItem,
            this.مبيعاتكلصنفToolStripMenuItem,
            this.احصائياتعامةToolStripMenuItem});
            this.toolStripMenuItem9.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem9.Image")));
            this.toolStripMenuItem9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(76, 76);
            this.toolStripMenuItem9.Text = "الجداول";
            this.toolStripMenuItem9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem10.Text = "قائمة العملاء";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // قائمةمناديبالمبيعاتToolStripMenuItem
            // 
            this.قائمةمناديبالمبيعاتToolStripMenuItem.Name = "قائمةمناديبالمبيعاتToolStripMenuItem";
            this.قائمةمناديبالمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةمناديبالمبيعاتToolStripMenuItem.Text = "قائمة مناديب المبيعات";
            this.قائمةمناديبالمبيعاتToolStripMenuItem.Click += new System.EventHandler(this.قائمةمناديبالمبيعاتToolStripMenuItem_Click);
            // 
            // ToolStripSeparator12
            // 
            this.ToolStripSeparator12.Name = "ToolStripSeparator12";
            this.ToolStripSeparator12.Size = new System.Drawing.Size(237, 6);
            // 
            // قائمةالاصنافToolStripMenuItem
            // 
            this.قائمةالاصنافToolStripMenuItem.Name = "قائمةالاصنافToolStripMenuItem";
            this.قائمةالاصنافToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةالاصنافToolStripMenuItem.Text = "قائمة الاصناف ";
            this.قائمةالاصنافToolStripMenuItem.Click += new System.EventHandler(this.قائمةالاصنافToolStripMenuItem_Click);
            // 
            // قائمةالموردينToolStripMenuItem
            // 
            this.قائمةالموردينToolStripMenuItem.Name = "قائمةالموردينToolStripMenuItem";
            this.قائمةالموردينToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةالموردينToolStripMenuItem.Text = "قائمة الموردين";
            this.قائمةالموردينToolStripMenuItem.Click += new System.EventHandler(this.قائمةالموردينToolStripMenuItem_Click);
            // 
            // قائمةدفعاتالموردينToolStripMenuItem
            // 
            this.قائمةدفعاتالموردينToolStripMenuItem.Name = "قائمةدفعاتالموردينToolStripMenuItem";
            this.قائمةدفعاتالموردينToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةدفعاتالموردينToolStripMenuItem.Text = "قائمة دفعات الموردين";
            this.قائمةدفعاتالموردينToolStripMenuItem.Click += new System.EventHandler(this.قائمةدفعاتالموردينToolStripMenuItem_Click);
            // 
            // قائمةفواتيرالشراءToolStripMenuItem
            // 
            this.قائمةفواتيرالشراءToolStripMenuItem.Name = "قائمةفواتيرالشراءToolStripMenuItem";
            this.قائمةفواتيرالشراءToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةفواتيرالشراءToolStripMenuItem.Text = "قائمة فواتير الشراء";
            this.قائمةفواتيرالشراءToolStripMenuItem.Click += new System.EventHandler(this.قائمةفواتيرالشراءToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(237, 6);
            // 
            // قائمةالخدماتToolStripMenuItem
            // 
            this.قائمةالخدماتToolStripMenuItem.Name = "قائمةالخدماتToolStripMenuItem";
            this.قائمةالخدماتToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةالخدماتToolStripMenuItem.Text = "قائمة الخدمات";
            this.قائمةالخدماتToolStripMenuItem.Visible = false;
            // 
            // قائمةفواتيرالخدماتToolStripMenuItem
            // 
            this.قائمةفواتيرالخدماتToolStripMenuItem.Name = "قائمةفواتيرالخدماتToolStripMenuItem";
            this.قائمةفواتيرالخدماتToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةفواتيرالخدماتToolStripMenuItem.Text = "قائمة فواتير الخدمات";
            this.قائمةفواتيرالخدماتToolStripMenuItem.Visible = false;
            // 
            // قائمةعروضالاسعارToolStripMenuItem
            // 
            this.قائمةعروضالاسعارToolStripMenuItem.Name = "قائمةعروضالاسعارToolStripMenuItem";
            this.قائمةعروضالاسعارToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةعروضالاسعارToolStripMenuItem.Text = "قائمة عروض الاسعار";
            this.قائمةعروضالاسعارToolStripMenuItem.Click += new System.EventHandler(this.قائمةعروضالاسعارToolStripMenuItem_Click);
            // 
            // قائمةالرسائلToolStripMenuItem
            // 
            this.قائمةالرسائلToolStripMenuItem.Name = "قائمةالرسائلToolStripMenuItem";
            this.قائمةالرسائلToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةالرسائلToolStripMenuItem.Text = "قائمة الرسائل";
            this.قائمةالرسائلToolStripMenuItem.Visible = false;
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(237, 6);
            // 
            // قائمةفواتيرالبيعToolStripMenuItem
            // 
            this.قائمةفواتيرالبيعToolStripMenuItem.Name = "قائمةفواتيرالبيعToolStripMenuItem";
            this.قائمةفواتيرالبيعToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.قائمةفواتيرالبيعToolStripMenuItem.Text = "قائمة فواتير البيع";
            this.قائمةفواتيرالبيعToolStripMenuItem.Click += new System.EventHandler(this.قائمةفواتيرالبيعToolStripMenuItem_Click);
            // 
            // مبيعاتكلصنفToolStripMenuItem
            // 
            this.مبيعاتكلصنفToolStripMenuItem.Name = "مبيعاتكلصنفToolStripMenuItem";
            this.مبيعاتكلصنفToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.مبيعاتكلصنفToolStripMenuItem.Text = "مبيعات كل صنف";
            this.مبيعاتكلصنفToolStripMenuItem.Click += new System.EventHandler(this.مبيعاتكلصنفToolStripMenuItem_Click);
            // 
            // احصائياتعامةToolStripMenuItem
            // 
            this.احصائياتعامةToolStripMenuItem.Name = "احصائياتعامةToolStripMenuItem";
            this.احصائياتعامةToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.احصائياتعامةToolStripMenuItem.Text = "احصائيات عامة";
            this.احصائياتعامةToolStripMenuItem.Click += new System.EventHandler(this.احصائياتعامةToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.حالةالمخزونToolStripMenuItem,
            this.المشترياتToolStripMenuItem,
            this.المصروفاتToolStripMenuItem,
            this.الأرباحToolStripMenuItem,
            this.دفتراليوميةToolStripMenuItem,
            this.كشفحسابتاجرToolStripMenuItem,
            this.كشفحسابعميلToolStripMenuItem,
            this.ارصدةالزبائنالجميعToolStripMenuItem,
            this.كشفحسابمندوبToolStripMenuItem,
            this.كشفمبيعاتToolStripMenuItem,
            this.عمولةمبيعاتToolStripMenuItem,
            this.ميزاالمراجعةToolStripMenuItem,
            this.شروطالائتمانللزبائنToolStripMenuItem,
            this.بياناتشروطالائتمانللزبائنToolStripMenuItem,
            this.الضرائبToolStripMenuItem,
            this.التقريرالعامToolStripMenuItem});
            this.toolStripMenuItem7.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem7.Image")));
            this.toolStripMenuItem7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(75, 76);
            this.toolStripMenuItem7.Text = "التقارير";
            this.toolStripMenuItem7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(289, 26);
            this.toolStripMenuItem8.Text = "المبيعات";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // حالةالمخزونToolStripMenuItem
            // 
            this.حالةالمخزونToolStripMenuItem.Name = "حالةالمخزونToolStripMenuItem";
            this.حالةالمخزونToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.حالةالمخزونToolStripMenuItem.Text = "حالة المخزون";
            this.حالةالمخزونToolStripMenuItem.Click += new System.EventHandler(this.حالةالمخزونToolStripMenuItem_Click);
            // 
            // المشترياتToolStripMenuItem
            // 
            this.المشترياتToolStripMenuItem.Name = "المشترياتToolStripMenuItem";
            this.المشترياتToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.المشترياتToolStripMenuItem.Text = "المشتريات ";
            this.المشترياتToolStripMenuItem.Click += new System.EventHandler(this.المشترياتToolStripMenuItem_Click);
            // 
            // المصروفاتToolStripMenuItem
            // 
            this.المصروفاتToolStripMenuItem.Name = "المصروفاتToolStripMenuItem";
            this.المصروفاتToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.المصروفاتToolStripMenuItem.Text = "المصروفات";
            this.المصروفاتToolStripMenuItem.Click += new System.EventHandler(this.المصروفاتToolStripMenuItem_Click);
            // 
            // الأرباحToolStripMenuItem
            // 
            this.الأرباحToolStripMenuItem.Name = "الأرباحToolStripMenuItem";
            this.الأرباحToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.الأرباحToolStripMenuItem.Text = "الأرباح والخسائر";
            this.الأرباحToolStripMenuItem.Click += new System.EventHandler(this.الأرباحToolStripMenuItem_Click);
            // 
            // دفتراليوميةToolStripMenuItem
            // 
            this.دفتراليوميةToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.يوميةالمشترياتToolStripMenuItem,
            this.اليوميةالعامةToolStripMenuItem});
            this.دفتراليوميةToolStripMenuItem.Name = "دفتراليوميةToolStripMenuItem";
            this.دفتراليوميةToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.دفتراليوميةToolStripMenuItem.Text = "دفتر اليومية";
            this.دفتراليوميةToolStripMenuItem.Visible = false;
            // 
            // يوميةالمشترياتToolStripMenuItem
            // 
            this.يوميةالمشترياتToolStripMenuItem.Name = "يوميةالمشترياتToolStripMenuItem";
            this.يوميةالمشترياتToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.يوميةالمشترياتToolStripMenuItem.Text = "يومية المشتريات ";
            this.يوميةالمشترياتToolStripMenuItem.Click += new System.EventHandler(this.يوميةالمشترياتToolStripMenuItem_Click);
            // 
            // اليوميةالعامةToolStripMenuItem
            // 
            this.اليوميةالعامةToolStripMenuItem.Name = "اليوميةالعامةToolStripMenuItem";
            this.اليوميةالعامةToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.اليوميةالعامةToolStripMenuItem.Text = "اليومية العامة";
            // 
            // كشفحسابتاجرToolStripMenuItem
            // 
            this.كشفحسابتاجرToolStripMenuItem.Name = "كشفحسابتاجرToolStripMenuItem";
            this.كشفحسابتاجرToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.كشفحسابتاجرToolStripMenuItem.Text = "كشف حساب مورد";
            this.كشفحسابتاجرToolStripMenuItem.Click += new System.EventHandler(this.كشفحسابتاجرToolStripMenuItem_Click);
            // 
            // كشفحسابعميلToolStripMenuItem
            // 
            this.كشفحسابعميلToolStripMenuItem.Name = "كشفحسابعميلToolStripMenuItem";
            this.كشفحسابعميلToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.كشفحسابعميلToolStripMenuItem.Text = "كشف حساب عميل";
            this.كشفحسابعميلToolStripMenuItem.Click += new System.EventHandler(this.كشفحسابعميلToolStripMenuItem_Click);
            // 
            // ارصدةالزبائنالجميعToolStripMenuItem
            // 
            this.ارصدةالزبائنالجميعToolStripMenuItem.Name = "ارصدةالزبائنالجميعToolStripMenuItem";
            this.ارصدةالزبائنالجميعToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.ارصدةالزبائنالجميعToolStripMenuItem.Text = "ارصدة الزبائن (الجميع)";
            this.ارصدةالزبائنالجميعToolStripMenuItem.Click += new System.EventHandler(this.ارصدةالزبائنالجميعToolStripMenuItem_Click);
            // 
            // كشفحسابمندوبToolStripMenuItem
            // 
            this.كشفحسابمندوبToolStripMenuItem.Name = "كشفحسابمندوبToolStripMenuItem";
            this.كشفحسابمندوبToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.كشفحسابمندوبToolStripMenuItem.Text = "كشف حساب مندوب";
            this.كشفحسابمندوبToolStripMenuItem.Visible = false;
            this.كشفحسابمندوبToolStripMenuItem.Click += new System.EventHandler(this.كشفحسابمندوبToolStripMenuItem_Click);
            // 
            // كشفمبيعاتToolStripMenuItem
            // 
            this.كشفمبيعاتToolStripMenuItem.Name = "كشفمبيعاتToolStripMenuItem";
            this.كشفمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.كشفمبيعاتToolStripMenuItem.Text = "كشف مبيعات";
            this.كشفمبيعاتToolStripMenuItem.Click += new System.EventHandler(this.كشفمبيعاتToolStripMenuItem_Click);
            // 
            // عمولةمبيعاتToolStripMenuItem
            // 
            this.عمولةمبيعاتToolStripMenuItem.Name = "عمولةمبيعاتToolStripMenuItem";
            this.عمولةمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.عمولةمبيعاتToolStripMenuItem.Text = "عمولة مناديب المبيعات";
            this.عمولةمبيعاتToolStripMenuItem.Visible = false;
            // 
            // ميزاالمراجعةToolStripMenuItem
            // 
            this.ميزاالمراجعةToolStripMenuItem.Name = "ميزاالمراجعةToolStripMenuItem";
            this.ميزاالمراجعةToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.ميزاالمراجعةToolStripMenuItem.Text = "ميزا المراجعة";
            this.ميزاالمراجعةToolStripMenuItem.Visible = false;
            // 
            // شروطالائتمانللزبائنToolStripMenuItem
            // 
            this.شروطالائتمانللزبائنToolStripMenuItem.Name = "شروطالائتمانللزبائنToolStripMenuItem";
            this.شروطالائتمانللزبائنToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.شروطالائتمانللزبائنToolStripMenuItem.Text = "شروط الائتمان للزبائن";
            this.شروطالائتمانللزبائنToolStripMenuItem.Visible = false;
            // 
            // بياناتشروطالائتمانللزبائنToolStripMenuItem
            // 
            this.بياناتشروطالائتمانللزبائنToolStripMenuItem.Name = "بياناتشروطالائتمانللزبائنToolStripMenuItem";
            this.بياناتشروطالائتمانللزبائنToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.بياناتشروطالائتمانللزبائنToolStripMenuItem.Text = "بيانات شروط الائتمان للزبائن";
            this.بياناتشروطالائتمانللزبائنToolStripMenuItem.Visible = false;
            // 
            // الضرائبToolStripMenuItem
            // 
            this.الضرائبToolStripMenuItem.Name = "الضرائبToolStripMenuItem";
            this.الضرائبToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.الضرائبToolStripMenuItem.Text = "الضرائب";
            this.الضرائبToolStripMenuItem.Visible = false;
            // 
            // التقريرالعامToolStripMenuItem
            // 
            this.التقريرالعامToolStripMenuItem.Name = "التقريرالعامToolStripMenuItem";
            this.التقريرالعامToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.التقريرالعامToolStripMenuItem.Text = "التقرير العام";
            this.التقريرالعامToolStripMenuItem.Click += new System.EventHandler(this.التقريرالعامToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Font = new System.Drawing.Font("Segoe UI Emoji", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem5.Image")));
            this.toolStripMenuItem5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(134, 76);
            this.toolStripMenuItem5.Text = "العمليات الاخيرة";
            this.toolStripMenuItem5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(123, 76);
            this.toolStripMenuItem1.Text = "اغلاق البرنامج";
            this.toolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(175)))), ((int)(((byte)(92)))));
            this.btnExportExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportExcel.FlatAppearance.BorderColor = System.Drawing.Color.SandyBrown;
            this.btnExportExcel.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.btnExportExcel.ForeColor = System.Drawing.Color.Black;
            this.btnExportExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnExportExcel.Image")));
            this.btnExportExcel.Location = new System.Drawing.Point(1177, 419);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(4);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(148, 95);
            this.btnExportExcel.TabIndex = 328;
            this.btnExportExcel.Text = "تصدير واستيراد من الأكسل";
            this.btnExportExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExportExcel.UseVisualStyleBackColor = true;
            // 
            // Picture
            // 
            this.Picture.Location = new System.Drawing.Point(8, 12);
            this.Picture.Margin = new System.Windows.Forms.Padding(4);
            this.Picture.Name = "Picture";
            this.Picture.Size = new System.Drawing.Size(283, 236);
            this.Picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Picture.TabIndex = 297;
            this.Picture.TabStop = false;
            // 
            // Button4
            // 
            this.Button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Button4.BackColor = System.Drawing.Color.White;
            this.Button4.Image = ((System.Drawing.Image)(resources.GetObject("Button4.Image")));
            this.Button4.Location = new System.Drawing.Point(752, 215);
            this.Button4.Margin = new System.Windows.Forms.Padding(4);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(55, 48);
            this.Button4.TabIndex = 342;
            this.Button4.UseVisualStyleBackColor = false;
            // 
            // Button3
            // 
            this.Button3.BackColor = System.Drawing.Color.White;
            this.Button3.Image = ((System.Drawing.Image)(resources.GetObject("Button3.Image")));
            this.Button3.Location = new System.Drawing.Point(752, 271);
            this.Button3.Margin = new System.Windows.Forms.Padding(4);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(55, 48);
            this.Button3.TabIndex = 340;
            this.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Button3.UseVisualStyleBackColor = false;
            // 
            // Button2
            // 
            this.Button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Button2.Image = ((System.Drawing.Image)(resources.GetObject("Button2.Image")));
            this.Button2.Location = new System.Drawing.Point(754, 122);
            this.Button2.Margin = new System.Windows.Forms.Padding(4);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(53, 37);
            this.Button2.TabIndex = 341;
            this.Button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Button2.UseVisualStyleBackColor = true;
            // 
            // SideBar
            // 
            this.SideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(45)))));
            this.SideBar.Controls.Add(this.gunaPanel2);
            this.SideBar.Controls.Add(this.gunaPanel3);
            this.SideBar.Controls.Add(this.gunaPanel4);
            this.SideBar.Controls.Add(this.gunaPanel8);
            this.SideBar.Controls.Add(this.gunaPanel5);
            this.SideBar.Controls.Add(this.gunaPanel6);
            this.SideBar.Controls.Add(this.gunaPanel7);
            this.SideBar.Controls.Add(this.gunaPanel11);
            this.SideBar.Controls.Add(this.gunaPanel10);
            this.SideBar.Controls.Add(this.gunaPanel14);
            this.SideBar.Controls.Add(this.gunaPanel12);
            this.SideBar.Controls.Add(this.gunaPanel13);
            this.SideBar.Controls.Add(this.gunaPanel15);
            this.SideBar.Controls.Add(this.gunaPanel16);
            this.SideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.SideBar.Location = new System.Drawing.Point(0, 28);
            this.SideBar.Margin = new System.Windows.Forms.Padding(0);
            this.SideBar.MaximumSize = new System.Drawing.Size(287, 2500);
            this.SideBar.MinimumSize = new System.Drawing.Size(90, 1012);
            this.SideBar.Name = "SideBar";
            this.SideBar.Size = new System.Drawing.Size(287, 1012);
            this.SideBar.TabIndex = 0;
            // 
            // gunaButton29
            // 
            this.gunaButton29.AnimationHoverSpeed = 0.07F;
            this.gunaButton29.AnimationSpeed = 0.03F;
            this.gunaButton29.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton29.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton29.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton29.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton29.ForeColor = System.Drawing.Color.White;
            this.gunaButton29.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton29.Image")));
            this.gunaButton29.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton29.ImageOffsetX = 10;
            this.gunaButton29.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton29.Location = new System.Drawing.Point(9, 390);
            this.gunaButton29.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton29.Name = "gunaButton29";
            this.gunaButton29.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton29.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton29.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton29.OnHoverImage = null;
            this.gunaButton29.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton29.Size = new System.Drawing.Size(243, 20);
            this.gunaButton29.TabIndex = 31;
            this.gunaButton29.Text = "ميزا المراجعة";
            this.gunaButton29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton30
            // 
            this.gunaButton30.AnimationHoverSpeed = 0.07F;
            this.gunaButton30.AnimationSpeed = 0.03F;
            this.gunaButton30.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton30.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton30.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton30.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton30.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton30.ForeColor = System.Drawing.Color.White;
            this.gunaButton30.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton30.Image")));
            this.gunaButton30.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton30.ImageOffsetX = 10;
            this.gunaButton30.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton30.Location = new System.Drawing.Point(9, 363);
            this.gunaButton30.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton30.Name = "gunaButton30";
            this.gunaButton30.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton30.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton30.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton30.OnHoverImage = null;
            this.gunaButton30.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton30.Size = new System.Drawing.Size(243, 20);
            this.gunaButton30.TabIndex = 30;
            this.gunaButton30.Text = "عمولة مناديب المبيعات";
            this.gunaButton30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton31
            // 
            this.gunaButton31.AnimationHoverSpeed = 0.07F;
            this.gunaButton31.AnimationSpeed = 0.03F;
            this.gunaButton31.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton31.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton31.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton31.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton31.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton31.ForeColor = System.Drawing.Color.White;
            this.gunaButton31.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton31.Image")));
            this.gunaButton31.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton31.ImageOffsetX = 10;
            this.gunaButton31.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton31.Location = new System.Drawing.Point(9, 335);
            this.gunaButton31.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton31.Name = "gunaButton31";
            this.gunaButton31.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton31.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton31.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton31.OnHoverImage = null;
            this.gunaButton31.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton31.Size = new System.Drawing.Size(243, 20);
            this.gunaButton31.TabIndex = 29;
            this.gunaButton31.Text = "كشف مبيعات";
            this.gunaButton31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton32
            // 
            this.gunaButton32.AnimationHoverSpeed = 0.07F;
            this.gunaButton32.AnimationSpeed = 0.03F;
            this.gunaButton32.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton32.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton32.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton32.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton32.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton32.ForeColor = System.Drawing.Color.White;
            this.gunaButton32.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton32.Image")));
            this.gunaButton32.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton32.ImageOffsetX = 10;
            this.gunaButton32.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton32.Location = new System.Drawing.Point(9, 309);
            this.gunaButton32.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton32.Name = "gunaButton32";
            this.gunaButton32.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton32.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton32.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton32.OnHoverImage = null;
            this.gunaButton32.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton32.Size = new System.Drawing.Size(243, 20);
            this.gunaButton32.TabIndex = 28;
            this.gunaButton32.Text = "كشف حساب مندوب";
            this.gunaButton32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton33
            // 
            this.gunaButton33.AnimationHoverSpeed = 0.07F;
            this.gunaButton33.AnimationSpeed = 0.03F;
            this.gunaButton33.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton33.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton33.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton33.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton33.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton33.ForeColor = System.Drawing.Color.White;
            this.gunaButton33.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton33.Image")));
            this.gunaButton33.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton33.ImageOffsetX = 10;
            this.gunaButton33.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton33.Location = new System.Drawing.Point(9, 281);
            this.gunaButton33.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton33.Name = "gunaButton33";
            this.gunaButton33.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton33.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton33.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton33.OnHoverImage = null;
            this.gunaButton33.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton33.Size = new System.Drawing.Size(243, 20);
            this.gunaButton33.TabIndex = 27;
            this.gunaButton33.Text = "ارصدة الزبائن ";
            this.gunaButton33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton34
            // 
            this.gunaButton34.AnimationHoverSpeed = 0.07F;
            this.gunaButton34.AnimationSpeed = 0.03F;
            this.gunaButton34.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton34.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton34.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton34.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton34.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton34.ForeColor = System.Drawing.Color.White;
            this.gunaButton34.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton34.Image")));
            this.gunaButton34.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton34.ImageOffsetX = 10;
            this.gunaButton34.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton34.Location = new System.Drawing.Point(9, 253);
            this.gunaButton34.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton34.Name = "gunaButton34";
            this.gunaButton34.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton34.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton34.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton34.OnHoverImage = null;
            this.gunaButton34.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton34.Size = new System.Drawing.Size(243, 20);
            this.gunaButton34.TabIndex = 26;
            this.gunaButton34.Text = "كشف حساب عميل";
            this.gunaButton34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton35
            // 
            this.gunaButton35.AnimationHoverSpeed = 0.07F;
            this.gunaButton35.AnimationSpeed = 0.03F;
            this.gunaButton35.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton35.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton35.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton35.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton35.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton35.ForeColor = System.Drawing.Color.White;
            this.gunaButton35.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton35.Image")));
            this.gunaButton35.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton35.ImageOffsetX = 10;
            this.gunaButton35.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton35.Location = new System.Drawing.Point(9, 227);
            this.gunaButton35.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton35.Name = "gunaButton35";
            this.gunaButton35.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton35.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton35.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton35.OnHoverImage = null;
            this.gunaButton35.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton35.Size = new System.Drawing.Size(243, 20);
            this.gunaButton35.TabIndex = 25;
            this.gunaButton35.Text = "كشف حساب مورد";
            this.gunaButton35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton36
            // 
            this.gunaButton36.AnimationHoverSpeed = 0.07F;
            this.gunaButton36.AnimationSpeed = 0.03F;
            this.gunaButton36.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton36.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton36.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton36.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton36.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton36.ForeColor = System.Drawing.Color.White;
            this.gunaButton36.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton36.Image")));
            this.gunaButton36.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton36.ImageOffsetX = 10;
            this.gunaButton36.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton36.Location = new System.Drawing.Point(9, 200);
            this.gunaButton36.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton36.Name = "gunaButton36";
            this.gunaButton36.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton36.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton36.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton36.OnHoverImage = null;
            this.gunaButton36.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton36.Size = new System.Drawing.Size(243, 20);
            this.gunaButton36.TabIndex = 24;
            this.gunaButton36.Text = "دفتر اليومية";
            this.gunaButton36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton37
            // 
            this.gunaButton37.AnimationHoverSpeed = 0.07F;
            this.gunaButton37.AnimationSpeed = 0.03F;
            this.gunaButton37.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton37.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton37.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton37.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton37.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton37.ForeColor = System.Drawing.Color.White;
            this.gunaButton37.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton37.Image")));
            this.gunaButton37.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton37.ImageOffsetX = 10;
            this.gunaButton37.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton37.Location = new System.Drawing.Point(9, 172);
            this.gunaButton37.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton37.Name = "gunaButton37";
            this.gunaButton37.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton37.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton37.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton37.OnHoverImage = null;
            this.gunaButton37.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton37.Size = new System.Drawing.Size(243, 20);
            this.gunaButton37.TabIndex = 23;
            this.gunaButton37.Text = "الأرباح والخسائر";
            this.gunaButton37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton38
            // 
            this.gunaButton38.AnimationHoverSpeed = 0.07F;
            this.gunaButton38.AnimationSpeed = 0.03F;
            this.gunaButton38.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton38.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton38.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton38.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton38.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton38.ForeColor = System.Drawing.Color.White;
            this.gunaButton38.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton38.Image")));
            this.gunaButton38.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton38.ImageOffsetX = 10;
            this.gunaButton38.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton38.Location = new System.Drawing.Point(9, 146);
            this.gunaButton38.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton38.Name = "gunaButton38";
            this.gunaButton38.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton38.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton38.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton38.OnHoverImage = null;
            this.gunaButton38.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton38.Size = new System.Drawing.Size(243, 20);
            this.gunaButton38.TabIndex = 22;
            this.gunaButton38.Text = "المصروفات";
            this.gunaButton38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton39
            // 
            this.gunaButton39.AnimationHoverSpeed = 0.07F;
            this.gunaButton39.AnimationSpeed = 0.03F;
            this.gunaButton39.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton39.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton39.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton39.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton39.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton39.ForeColor = System.Drawing.Color.White;
            this.gunaButton39.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton39.Image")));
            this.gunaButton39.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton39.ImageOffsetX = 10;
            this.gunaButton39.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton39.Location = new System.Drawing.Point(9, 118);
            this.gunaButton39.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton39.Name = "gunaButton39";
            this.gunaButton39.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton39.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton39.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton39.OnHoverImage = null;
            this.gunaButton39.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton39.Size = new System.Drawing.Size(243, 20);
            this.gunaButton39.TabIndex = 21;
            this.gunaButton39.Text = "المشتريات ";
            this.gunaButton39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton40
            // 
            this.gunaButton40.AnimationHoverSpeed = 0.07F;
            this.gunaButton40.AnimationSpeed = 0.03F;
            this.gunaButton40.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton40.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton40.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton40.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton40.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton40.ForeColor = System.Drawing.Color.White;
            this.gunaButton40.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton40.Image")));
            this.gunaButton40.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton40.ImageOffsetX = 10;
            this.gunaButton40.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton40.Location = new System.Drawing.Point(9, 90);
            this.gunaButton40.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton40.Name = "gunaButton40";
            this.gunaButton40.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton40.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton40.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton40.OnHoverImage = null;
            this.gunaButton40.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton40.Size = new System.Drawing.Size(243, 20);
            this.gunaButton40.TabIndex = 20;
            this.gunaButton40.Text = "حالة المخزون";
            this.gunaButton40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton41
            // 
            this.gunaButton41.AnimationHoverSpeed = 0.07F;
            this.gunaButton41.AnimationSpeed = 0.03F;
            this.gunaButton41.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton41.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton41.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton41.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton41.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton41.ForeColor = System.Drawing.Color.White;
            this.gunaButton41.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton41.Image")));
            this.gunaButton41.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton41.ImageOffsetX = 10;
            this.gunaButton41.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton41.Location = new System.Drawing.Point(9, 64);
            this.gunaButton41.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton41.Name = "gunaButton41";
            this.gunaButton41.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton41.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton41.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton41.OnHoverImage = null;
            this.gunaButton41.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton41.Size = new System.Drawing.Size(243, 20);
            this.gunaButton41.TabIndex = 19;
            this.gunaButton41.Text = "المبيعات";
            this.gunaButton41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton43
            // 
            this.gunaButton43.AnimationHoverSpeed = 0.07F;
            this.gunaButton43.AnimationSpeed = 0.03F;
            this.gunaButton43.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton43.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton43.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton43.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton43.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton43.ForeColor = System.Drawing.Color.White;
            this.gunaButton43.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton43.Image")));
            this.gunaButton43.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton43.ImageOffsetX = 10;
            this.gunaButton43.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton43.Location = new System.Drawing.Point(12, 493);
            this.gunaButton43.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton43.Name = "gunaButton43";
            this.gunaButton43.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton43.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton43.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton43.OnHoverImage = null;
            this.gunaButton43.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton43.Size = new System.Drawing.Size(243, 20);
            this.gunaButton43.TabIndex = 35;
            this.gunaButton43.Text = "التقرير العام";
            this.gunaButton43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton44
            // 
            this.gunaButton44.AnimationHoverSpeed = 0.07F;
            this.gunaButton44.AnimationSpeed = 0.03F;
            this.gunaButton44.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton44.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton44.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton44.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton44.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton44.ForeColor = System.Drawing.Color.White;
            this.gunaButton44.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton44.Image")));
            this.gunaButton44.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton44.ImageOffsetX = 10;
            this.gunaButton44.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton44.Location = new System.Drawing.Point(9, 469);
            this.gunaButton44.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton44.Name = "gunaButton44";
            this.gunaButton44.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton44.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton44.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton44.OnHoverImage = null;
            this.gunaButton44.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton44.Size = new System.Drawing.Size(243, 20);
            this.gunaButton44.TabIndex = 34;
            this.gunaButton44.Text = "الضرائب";
            this.gunaButton44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton45
            // 
            this.gunaButton45.AnimationHoverSpeed = 0.07F;
            this.gunaButton45.AnimationSpeed = 0.03F;
            this.gunaButton45.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton45.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton45.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton45.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton45.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton45.ForeColor = System.Drawing.Color.White;
            this.gunaButton45.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton45.Image")));
            this.gunaButton45.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton45.ImageOffsetX = 10;
            this.gunaButton45.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton45.Location = new System.Drawing.Point(9, 443);
            this.gunaButton45.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton45.Name = "gunaButton45";
            this.gunaButton45.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton45.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton45.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton45.OnHoverImage = null;
            this.gunaButton45.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton45.Size = new System.Drawing.Size(243, 20);
            this.gunaButton45.TabIndex = 33;
            this.gunaButton45.Text = "بيانات شروط الائتمان للزبائن";
            this.gunaButton45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gunaButton46
            // 
            this.gunaButton46.AnimationHoverSpeed = 0.07F;
            this.gunaButton46.AnimationSpeed = 0.03F;
            this.gunaButton46.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton46.BorderColor = System.Drawing.Color.Transparent;
            this.gunaButton46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton46.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton46.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton46.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.gunaButton46.ForeColor = System.Drawing.Color.White;
            this.gunaButton46.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton46.Image")));
            this.gunaButton46.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton46.ImageOffsetX = 10;
            this.gunaButton46.ImageSize = new System.Drawing.Size(15, 15);
            this.gunaButton46.Location = new System.Drawing.Point(9, 415);
            this.gunaButton46.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.gunaButton46.Name = "gunaButton46";
            this.gunaButton46.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton46.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.gunaButton46.OnHoverForeColor = System.Drawing.Color.Silver;
            this.gunaButton46.OnHoverImage = null;
            this.gunaButton46.OnPressedColor = System.Drawing.Color.White;
            this.gunaButton46.Size = new System.Drawing.Size(243, 20);
            this.gunaButton46.TabIndex = 32;
            this.gunaButton46.Text = "شروط الائتمان للزبائن";
            this.gunaButton46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // basic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1040);
            this.Controls.Add(this.SideBar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblUserType);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.toolStripContainer1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "basic";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "الواجهة الرئيسية";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.basic_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgw)).EndInit();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.gunaPanel16.ResumeLayout(false);
            this.gunaPanel15.ResumeLayout(false);
            this.gunaPanel13.ResumeLayout(false);
            this.gunaPanel12.ResumeLayout(false);
            this.gunaPanel14.ResumeLayout(false);
            this.gunaPanel10.ResumeLayout(false);
            this.gunaPanel11.ResumeLayout(false);
            this.gunaPanel7.ResumeLayout(false);
            this.gunaPanel6.ResumeLayout(false);
            this.gunaPanel5.ResumeLayout(false);
            this.gunaPanel8.ResumeLayout(false);
            this.gunaPanel4.ResumeLayout(false);
            this.gunaPanel3.ResumeLayout(false);
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel9.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picture)).EndInit();
            this.SideBar.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem الاداواتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الالهالحاسبةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المزكرةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem محررالنصوصToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اوفيسToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مديرالمهامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معلوماتالنظامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عنالشركهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        internal System.Windows.Forms.OpenFileDialog OpenFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem قائمةالعملاءToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem قائمةمناديبالمبيعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةالاصنافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةالموردينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةدفعاتالموردينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةفواتيرالشراءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةالخدماتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةفواتيرالخدماتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةعروضالاسعارToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةالرسائلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قائمةفواتيرالبيعToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مبيعاتكلصنفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem احصائياتعامةToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator12;
        internal System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        internal System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem حالةالمخزونToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المشترياتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المصروفاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الأرباحToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دفتراليوميةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem يوميةالمشترياتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اليوميةالعامةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كشفحسابتاجرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كشفحسابعميلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ارصدةالزبائنالجميعToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem التقريرالعامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كشفحسابمندوبToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كشفمبيعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عمولةمبيعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ميزاالمراجعةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem شروطالائتمانللزبائنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بياناتشروطالائتمانللزبائنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الضرائبToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الشركىToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المبرمجينToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        internal System.Windows.Forms.Button btnExportExcel;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.Button btnNew;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button btnUpdate;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnGetData;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox txtReorderPoint;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtFeatures;
        internal System.Windows.Forms.TextBox txtProductCode;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Button Browse;
        internal System.Windows.Forms.ComboBox cmbSubCategory;
        private System.Windows.Forms.Button BRemove;
        internal System.Windows.Forms.TextBox txtCostPrice;
        public System.Windows.Forms.PictureBox Picture;
        internal System.Windows.Forms.TextBox txtProductName;
        internal System.Windows.Forms.TextBox txtSellingPrice;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox txtDiscount;
        internal System.Windows.Forms.TextBox txtVAT;
        internal System.Windows.Forms.DataGridView dgw;
        internal System.Windows.Forms.DataGridViewImageColumn Column1;
        public System.Windows.Forms.Button btnAdd;
        public System.Windows.Forms.Button btnRemove;
        internal System.Windows.Forms.TextBox txtOpeningStock;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.TextBox txtBarcode;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.DateTimePicker dtpManufacturingDate;
        internal System.Windows.Forms.DateTimePicker dtpExpiryDate;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.TextBox txtSellingPrice2;
        internal System.Windows.Forms.Label Label24;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        public System.Windows.Forms.ToolStripMenuItem اToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem جهاتالاتصالToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem منادToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem جهاتالاتصالToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem اعداداتالايميلToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem نسخاحطياتيToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem نسخToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem المستخدمينToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem اعداداتالرسائلToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem اعداداتToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        public System.Windows.Forms.ToolStripMenuItem مرتجعمبيعاتToolStripMenuItem;
        internal System.Windows.Forms.Label lblUserType;
        internal System.Windows.Forms.Label lblUser;
        private Guna.UI.WinForms.GunaPanel gunaPanel16;
        private Guna.UI.WinForms.GunaButton gunaButton11;
        private Guna.UI.WinForms.GunaPanel gunaPanel15;
        private Guna.UI.WinForms.GunaButton gunaButton10;
        private Guna.UI.WinForms.GunaPanel gunaPanel13;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaPanel gunaPanel12;
        private Guna.UI.WinForms.GunaButton gunaButton7;
        private Guna.UI.WinForms.GunaPanel gunaPanel14;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private Guna.UI.WinForms.GunaPanel gunaPanel10;
        private Guna.UI.WinForms.GunaButton gunaButton14;
        private Guna.UI.WinForms.GunaButton gunaButton15;
        private Guna.UI.WinForms.GunaButton gunaButton6;
        private Guna.UI.WinForms.GunaPanel gunaPanel11;
        private Guna.UI.WinForms.GunaButton gunaButton13;
        private Guna.UI.WinForms.GunaButton gunaButton12;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private Guna.UI.WinForms.GunaPanel gunaPanel7;
        private Guna.UI.WinForms.GunaButton gunaButton8;
        private Guna.UI.WinForms.GunaPanel gunaPanel6;
        private Guna.UI.WinForms.GunaButton gunaButton9;
        private Guna.UI.WinForms.GunaPanel gunaPanel5;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private Guna.UI.WinForms.GunaPanel gunaPanel8;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private Guna.UI.WinForms.GunaPanel gunaPanel4;
        private Guna.UI.WinForms.GunaButton Orders_Button;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaButton Home_Button;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaPanel gunaPanel9;
        private Guna.UI.WinForms.GunaButton Menu_Button;
        public System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        internal System.Windows.Forms.Button btnSalesmanMaster;
        internal System.Windows.Forms.Button btnProductMaster;
        internal System.Windows.Forms.Button btnSupplier;
        internal System.Windows.Forms.Button btnCreditCustomer;
        internal System.Windows.Forms.Button btnPurchaseReturn;
        internal System.Windows.Forms.Button btnWallet;
        internal System.Windows.Forms.Button btnSalesReturn;
        internal System.Windows.Forms.Button btnPurchase;
        internal System.Windows.Forms.Button btnBarcodeLabelPrinting;
        internal System.Windows.Forms.Button BtnVoucher;
        internal System.Windows.Forms.Button btnBankReconciliation;
        internal System.Windows.Forms.Button btnPayroll;
        internal System.Windows.Forms.Button btnAccountingReports;
        internal System.Windows.Forms.Button btnStockAdjustment;
        internal System.Windows.Forms.Button btnStockTransfer_Issue;
        internal System.Windows.Forms.Button btnPayment;
        internal System.Windows.Forms.Button btnPOSRecord;
        internal System.Windows.Forms.Button btnPOSReport;
        internal System.Windows.Forms.Button btnWorkPeriod;
        internal System.Windows.Forms.Button btnPurchaseOrder;
        private System.Windows.Forms.Timer Timer_Sidebar_Menu;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private Guna.UI.WinForms.GunaButton gunaButton18;
        private Guna.UI.WinForms.GunaButton gunaButton22;
        private Guna.UI.WinForms.GunaButton gunaButton23;
        private Guna.UI.WinForms.GunaButton gunaButton24;
        private Guna.UI.WinForms.GunaButton gunaButton25;
        private Guna.UI.WinForms.GunaButton gunaButton26;
        private Guna.UI.WinForms.GunaButton gunaButton27;
        private Guna.UI.WinForms.GunaButton gunaButton19;
        private Guna.UI.WinForms.GunaButton gunaButton20;
        private Guna.UI.WinForms.GunaButton gunaButton21;
        private Guna.UI.WinForms.GunaButton gunaButton28;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.ToolStripMenuItem الاشعاراتToolStripMenuItem;
        private Guna.UI.WinForms.GunaButton gunaButton17;
        private Guna.UI.WinForms.GunaButton gunaButton16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.FlowLayoutPanel SideBar;
        private Guna.UI.WinForms.GunaButton gunaButton29;
        private Guna.UI.WinForms.GunaButton gunaButton30;
        private Guna.UI.WinForms.GunaButton gunaButton31;
        private Guna.UI.WinForms.GunaButton gunaButton32;
        private Guna.UI.WinForms.GunaButton gunaButton33;
        private Guna.UI.WinForms.GunaButton gunaButton34;
        private Guna.UI.WinForms.GunaButton gunaButton35;
        private Guna.UI.WinForms.GunaButton gunaButton36;
        private Guna.UI.WinForms.GunaButton gunaButton37;
        private Guna.UI.WinForms.GunaButton gunaButton38;
        private Guna.UI.WinForms.GunaButton gunaButton39;
        private Guna.UI.WinForms.GunaButton gunaButton40;
        private Guna.UI.WinForms.GunaButton gunaButton41;
        private Guna.UI.WinForms.GunaButton gunaButton43;
        private Guna.UI.WinForms.GunaButton gunaButton44;
        private Guna.UI.WinForms.GunaButton gunaButton45;
        private Guna.UI.WinForms.GunaButton gunaButton46;
    }
}

